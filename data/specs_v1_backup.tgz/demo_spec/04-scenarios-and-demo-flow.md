# 04 Scenarios and demo flow

Deliverables 7 and 8. Binding on this file: `00-decisions.md` (ids, states, buttons, endpoints, tables) and `WORLD_SPEC.md` (amounts, evidence text, ids). All amounts below are recomputed here, not copied blind; each matches `00-decisions.md` section 4 where that section already gives the row.

Shared notation. `CONTROLLER` = E001 Dana Whitfield. `REVIEWER` = E002 Marcus Oyelaran. Tolerance = `max($500.00, 0.02 x accrued amount)`. Accrual is `Dr <expense> / Cr 2100`, dated the last day of the service month, reversed day 1 of next month. Invoice posts `Dr <expense> / Cr 2000`; true-up posts `Dr <expense> / Cr 2000` for the variance only. Guard G1 blocks a candidate whose predicates leave the section 1.7 whitelist or cite a post-cutoff fact. Guard G2 blocks a candidate with `regressed > 0` or no drop in absolute error.

## 1. SCN-A: learnable failure (DataForge, V001)

**Judge action.** Scenario Lab, vendor V001, control `CTL-ESCALATOR-PCT`, parameter `escalator_pct`. Options 0 / 5 / 8 / 12. 5 is the untouched baseline (`PS-001` CY2 is already $52,500.00), so it produces no visible diff; this walkthrough uses **8**, a genuine judge edit. Judge clicks `btn-apply-mutation`.

**Document diff.** `contracts/pricing_schedules/PS-001.txt`, CY2 row:
```
CY2 | 2026-12-01 | 2027-11-30 | $52,500.00  ->  $54,000.00
```
Hidden records re-derived: `INV-V001-008` amount $52,500.00 -> $54,000.00; `INV-V001-009` (2027-01, not used by this scenario) also re-derived. `world_hash` changes; regeneration budget under 2s.

**What TrueUp sees at close** (`btn-run-close`, period 2026-12, clock 2027-01-04T09:00 to 2027-01-05T15:30). Under policy 1.0 `FIXED_CONTRACT_FEE` requires only `contract, service_period`; `PS-001` is never opened.
Evidence used: `CTR-001` order form ("$50,000.00 per month (Contract Year 1)"), `PO-1029`, `SA-DATAFORGE-2026-12` (service confirmed), `INV-V001-001..007` (seven priors at $50,000.00), `erp/accrual_schedule_prior.csv` (no V001 rows).

**ActionProposal and verifier result:**
```json
{"proposal_id":"PRP-V001-2026-12-01","obligation_id":"OBL-V001-2026-12","action_type":"POST_ACCRUAL","amount":50000.00,
 "accounts":{"debit":"6100","credit":"2100"},"entry_date":"2026-12-31","reversal_date":"2027-01-01",
 "calculation_method":"FIXED_CONTRACT_FEE","evidence_ids":["CTR-001","PO-1029","SA-DATAFORGE-2026-12"],"confidence":0.91,"policy_version":"1.0"}
{"evaluation_id":"PE-V001-2026-12-01","result":"REVIEW_REQUIRED","required_approval_level":"CONTROLLER",
 "checks":[{"invariant":"EVIDENCE_TRACE_COMPLETE","passed":true,"source":"BASE"},{"invariant":"MATERIALITY_APPROVAL","passed":false,"source":"BASE","detail":"50000.00 >= 25000.00"}]}
```

**JE.** `JE-ACR-V001-2026-12` Dr 6100 / Cr 2100 $50,000.00, CC-100, dated 2026-12-31; `JE-REV-V001-2026-12` reversal 2027-01-01. Judge/presenter clicks `btn-approve-accrual` (E001) -> `CLOSE_POSTED`.

**Advance Time.** `btn-advance-time` to 2027-01-12T09:00 releases event `INVOICE_RECEIVED` -> `INV-V001-008`, number DF-2256, dated 2026-12-31, **$54,000.00**.

**Deterministic variance.** $54,000.00 - $50,000.00 = **$4,000.00**. Tolerance = `max($500.00, 0.02 x 50000.00) = $1,000.00`. $4,000.00 > $1,000.00, outside tolerance -> `TRUEUP_COMPUTED`, `btn-investigate` enabled. `JE-INV-V001-008` Dr 6100/Cr 2000 $50,000.00; `JE-TRU-V001-2026-12` Dr 6100/Cr 2000 $4,000.00 dated 2027-01-12.

**Investigation trail** (`btn-investigate`, clock 2027-01-13T09:00, run `RUN-0002`):

| ToolCall | Actor | Call | Quoted source | Locator |
|---|---|---|---|---|
| TC-0002-001 | Reconciliation Agent | `open_document(INV-V001-008)` | "DataForge Platform subscription - December 2026 (Contract Year 2)", $54,000.00 | `line_items[0]` |
| TC-0002-002 | Evidence Agent | `list_contract_documents(CTR-001)` | returns `["CTR-001","PS-001"]` | `contracts/index.json` |
| TC-0002-003 | Evidence Agent | `open_document(PS-001)` | "CY2 \| 2026-12-01 \| 2027-11-30 \| $54,000.00" | table row 2 |
| TC-0002-004 | Evidence Agent | `open_document(CTR-001)` | "$50,000.00 per month (Contract Year 1)" | Order Form |
| TC-0002-005 | Reconciliation Agent | `compute_variance(OBL-V001-2026-12)` | actual 54000.00 - accrued 50000.00 = 4000.00, tolerance 1000.00 | n/a (deterministic) |
| TC-0002-006 | classifier (LLM) | `classify_root_cause([INV-V001-008,PS-001,CTR-001])` | "PS-001 filed_date 2025-11-24, in repository before T0" | PS-001 header |

**Root cause.** `SCHEDULED_PRICE_CHANGE`, `process_cause = PROCEDURE_GAP_REQUIRED_EVIDENCE`. `evidence_existed_at_close = true` -> `CANDIDATE_READY`.

**Candidate policy.** `POL-0001`, `policy_type VERIFY_EFFECTIVE_CONTRACT_PRICE`, scope `{estimator_method: FIXED_CONTRACT_FEE, contract_features.has_scheduled_price_change: true, pricing_structure_in: [SCHEDULED_STEP, ANNIVERSARY_ESCALATOR, VENDOR_NOTIFIED_UPLIFT]}`. No `vendor_id`, vendor name, or `contract_id` anywhere in the record. Guard G1 passes (every field is on the section 1.7 whitelist).

**Replay numbers** (`btn-run-replay`, `RPL-POL-0001`, 35 obligations across 2026-11 and 2026-12): touched = `OBL-V001-2026-12` only, before $50,000.00 / abs_error $4,000.00, after $54,000.00 / abs_error $0.00. `improved = 1, regressed = 0, unchanged = 34`. Guard G2 passes.

**Approve vs Reject.**
- `btn-approve-policy` (judge's second real choice, actor E001): `POLICY_APPROVED`, playbook badge 1.0 -> 1.1 `PROVISIONAL`, `POL-0001.status = ACTIVE_PROVISIONAL`, persisted in `trueup_playbook.db` (survives Reset World). SCN-B's learned arm uses this.
- `btn-reject-policy`: `POLICY_REJECTED`, playbook stays 1.0, `policy_events` row `REJECTED` by E001. SCN-B's learned arm then behaves identically to the frozen arm (no predicate exists to match).

## 2. SCN-B: transfer to an unseen vendor (SignalStack, V018)

Requires SCN-A approved first. Frozen and learned arms fork snapshot `2027-01-open` at 2027-02-01T00:00, so both see one byte-identical visible state.

**Judge action.** Lab, vendor V018 (first time in AP; onboarded 2027-01-08, never handled before), control `CTL-ESCALATOR-PCT`, parameter `production_monthly_fee`. Options 12000 / 24000 / 30000 / 33000; 30000 is baseline. This walkthrough uses **33000**, the judge's own number, so the room cannot mistake the result for a memorized $30,000 slide fact.

**Document diff.** `contracts/pricing_schedules/PS-018.txt`, Production row:
```
Production | 2027-01-01 | 2027-12-31 | $30,000.00  ->  $33,000.00
```
Hidden `INV-V018-001` amount $30,000.00 -> $33,000.00. Pilot months and the two `CARD_EXPENSE` GL rows are untouched.

**What each arm sees at close** (period 2027-01, clock at or after 2027-02-01):
- Frozen (v1.0): reads only `CTR-018` order form ("Pilot Fee $12,000.00 per month") plus `JE-CARD-0001` and `JE-CARD-0002` as corroboration. Never opens `PS-018` (not in the v1.0 required-evidence list).
- Learned (v1.1): same start, then POL-0001 fires because `has_scheduled_price_change = true` for CTR-018.

**Evidence-retrieval trail, learned arm** (run `RUN-0003`):

| ToolCall | Actor | Call | Quoted source | Locator |
|---|---|---|---|---|
| TC-0003-001 | Evidence Agent | `open_document(CTR-018)` | "Pilot Fee $12,000.00 per month" | Order Form |
| TC-0003-002 | Estimation Agent | draft `FIXED_CONTRACT_FEE` $12,000.00 | evidence `[CTR-018, JE-CARD-0001, JE-CARD-0002]` | n/a |
| TC-0003-003 | Verifier Engine | `evaluate(POL-0001)` | result `BLOCK`, "PS-018 exists in contracts/index.json but not attached" | missing_evidence: pricing_schedule_effective |
| TC-0003-004 | Evidence Agent | `list_contract_documents(CTR-018)` | returns `["CTR-018","PS-018"]` | contracts/index.json |
| TC-0003-005 | Evidence Agent | `open_document(PS-018)` | "Production \| 2027-01-01 \| 2027-12-31 \| $33,000.00" | table row 2 |
| TC-0003-006 | Estimation Agent | re-propose `FIXED_CONTRACT_FEE` $33,000.00 | evidence `+= [PS-018]` | n/a |
| TC-0003-007 | Verifier Engine | `evaluate(POL-0001)` | result `REVIEW_REQUIRED`, `required_approval_level CONTROLLER` | source POL-0001 |

Frozen arm makes 1 tool call (`open_document(CTR-018)`) and stops there, by design of v1.0's required-evidence list.

**Frozen Agent vs Learned TrueUp:**

| | Frozen (v1.0) | Learned (v1.1) |
|---|---|---|
| Accrual amount | $12,000.00 | $33,000.00 |
| Price evidence | CTR-018 order form + 2 card charges | PS-018 Production row |
| Verifier result / approval | REVIEW_REQUIRED / REVIEWER (E002) | BLOCK -> REVIEW_REQUIRED / CONTROLLER (E001) |
| JE | Dr 6120 / Cr 2100 $12,000.00, CC-190, 2027-01-31 | Dr 6120 / Cr 2100 $33,000.00, CC-190, 2027-01-31 |
| Hidden `INV-V018-001` | $33,000.00 | $33,000.00 |
| True-up ($33,000.00 - accrual) | $21,000.00 (tolerance max($500,0.02x12000=$240)=$500.00; outside) | $0.00 |

**Predicate-match panel** (`#transfer-panel`): `estimator_method = FIXED_CONTRACT_FEE` matched; `has_scheduled_price_change = true` matched; `pricing_structure = SCHEDULED_STEP` in `pricing_structure_in`; line: "POL-0001 contains no vendor_id, vendor name, or contract_id" next to the serialized policy record.

**Root cause, candidate policy, replay.** No new classification or candidate runs here; this beat consumes `POL-0001` from SCN-A. The frozen arm's miss carries the same `SCHEDULED_PRICE_CHANGE` shape already learned. `forward_scope_preview` from the SCN-A replay report already listed `OBL-V018-2027-01` before this run happened, holding no amount.

**Approve vs Reject (inherited).** If SCN-A was approved, the table above holds. If SCN-A was rejected, the learned arm's verifier never fires POL-0001; both arms read $12,000.00 and both miss by $21,000.00 against a $33,000.00 invoice — the presenter can show this on request to prove the policy, not luck, produced the fix.

Bonus proof of "not memorized" (time permitting): control `CTL-ESCALATOR-DATE`, `production_effective_date = 2027-02-01`. January is then still the **pilot** month. Frozen: $12,000.00 accrued, invoice $12,000.00, variance $0.00. Learned: reads the PS-018 row covering 2027-01-01..2027-01-31 (still Pilot at that date) and books $12,000.00, variance $0.00 too — same predicate match, opposite direction, proving the rule reads the schedule rather than always inflating the number.

## 3. SCN-C: refuse to learn (Brightwork, V006)

**Judge action.** Lab, vendor V006, control `CTL-SURCHARGE`, parameter `surcharge_amount`. Options 0.00 / 900.00 / 2,400.00 / 6,000.00. This walkthrough uses **2,400.00**.

**Document diff.** None, by design of this control. The Lab shows: "This control changes only the hidden invoice; nothing in the visible repository changes before cutoff." `INV-V006-003` total (hidden) becomes $28,670.00; `release_at` is unchanged (2027-01-15).

**What TrueUp sees at close** (`OBL-V006-2026-12`): `evidence/timesheets.csv` shows 68 hours `APPROVED`, 74 hours `PENDING` (weeks ending 2026-12-18 and 2026-12-25, 38 + 36). Verifier returns `OUTREACH_REQUIRED`, fact `SERVICE_RECEIVED`, target E014 (owner). Reply after 20h confirms all 142 hours. `USAGE_X_RATE`: 142 x $185.00 = **$26,270.00**.

**ActionProposal and verifier result:**
```json
{"proposal_id":"PRP-V006-2026-12-01","action_type":"POST_ACCRUAL","amount":26270.00,"accounts":{"debit":"6200","credit":"2100"},
 "entry_date":"2026-12-31","reversal_date":"2027-01-01","calculation_method":"USAGE_X_RATE",
 "evidence_ids":["CTR-006","PO-1042","TS-V006-2026-12-18","TS-V006-2026-12-25"],"policy_version":"1.0"}
{"evaluation_id":"PE-V006-2026-12-01","result":"REVIEW_REQUIRED","required_approval_level":"CONTROLLER"}
```

**JE.** `JE-ACR-V006-2026-12` Dr 6200 / Cr 2100 $26,270.00, CC-140, 2026-12-31; reversal 2027-01-01. Approved by E001.

**Advance Time.** Release to 2027-01-15T09:00 materializes `INV-V006-003`, BW-2221, total **$28,670.00** (two line items: $26,270.00 services, $2,400.00 "Year end expedite premium").

**Deterministic variance.** $28,670.00 - $26,270.00 = **$2,400.00**. Tolerance = `max($500.00, 0.02 x 26270.00 = $525.40) = $525.40`. $2,400.00 > $525.40, outside tolerance -> `btn-investigate` enabled.

**Investigation trail.** SCN-C is run from a fresh `btn-reset-world`, which wipes `agent_runs` and `tool_calls`, so ids restart: the close is `RUN-0001` and the investigation is `RUN-0002`. The rows below belong to this world, not to SCN-A's.

| ToolCall | Actor | Call | Quoted source | Locator |
|---|---|---|---|---|
| TC-0002-001 | Reconciliation Agent | `open_document(INV-V006-003)` | "Year end expedite premium", $2,400.00 | `line_items[1]` |
| TC-0002-002 | Evidence Agent | `list_contract_documents(CTR-006)` | returns `["CTR-006"]`, no pricing exhibit | contracts/index.json |
| TC-0002-003 | Evidence Agent | `open_document(CTR-006)` | "Consultant shall bill actual hours worked at $185.00 per hour. No additional fees apply absent a signed change order." | Fees clause |
| TC-0002-004 | Evidence Agent | `search_change_orders(contract_id=CTR-006)` | none found for December | change_orders.json |
| TC-0002-005 | Evidence Agent | `search_inbox(obligation_id=OBL-V006-2026-12, missing_fact=SCOPE_OR_RATE_CHANGE)` | no thread exists | inbox/messages.jsonl |
| TC-0002-006 | classifier (LLM) | `classify_root_cause([INV-V006-003,CTR-006])` | "no clause, change order, or correspondence supports $2,400.00" | n/a |

**Root cause.** No contractual basis and no pre-cutoff observable feature -> `root_cause = UNKNOWN`, `process_cause = NO_CONTRACTUAL_BASIS` -> `ROOT_CAUSE_UNKNOWN` -> automatic -> `ESCALATED`.

**Why no policy is proposed.** The state machine only reaches `CANDIDATE_READY` from `ROOT_CAUSE_FOUND`. `UNKNOWN` never visits that state, so the Learning Agent is never invoked; there is nothing to scope a predicate against, since no observable pre-cutoff feature explains the $2,400.00. (Contrast: V007 Meridian's baseline miss is `ESTIMATE_JUDGMENT` with `evidence_existed_at_close = false` — evidence exists nowhere, a Controller judgment call, not a procedure gap either — also escalates, also no candidate, for a different reason worth citing if a judge asks for a second example.)

**EscalationNote:**
```json
{"escalation_id":"ESC-V006-2026-12-01","obligation_id":"OBL-V006-2026-12","raised_at":"2027-01-15T12:00:00","raised_by":"TRUEUP",
 "reason_code":"NO_CONTRACTUAL_BASIS","variance_amount":2400.00,"tolerance_amount":525.40,
 "evidence_ids":["INV-V006-003","CTR-006"],"routed_to":"E001","routed_role":"CONTROLLER",
 "summary":"Invoice carries a $2,400.00 line, 'Year end expedite premium', with no supporting clause, change order, or correspondence.",
 "status":"OPEN","controller_decision":null}
```
No scripted inbox reply exists for this note (it is a judge-created fact, not a seeded case), so it stays `OPEN` for the rest of the demo; only `Reset World` / `Reset Demo` clear it.

**Candidate policy / replay / Approve-Reject.** None of the three apply. `btn-approve-policy` and `btn-reject-policy` are never rendered for this obligation; `ESCALATED`'s only enabled buttons are `Reset World` and `Reset Demo`. This absence is the deliverable: TrueUp declines to generalize from one unexplained dollar.

## 4. The three-minute judge-facing flow

Backbone is SCN-A end to end, closing with the SCN-B transfer proof. SCN-C is not in the timed path (its payoff is silence, not a state change) but is one click away if a judge asks "what if it can't explain it" during the wrap.

**GPF (Golden Path Fallback).** Per the Live-LLM risk rule, a mutated world never gets a cached answer. If any live call in a beat below stalls past 5 seconds or errors, the presenter says the fallback line, clicks `btn-reset-world`, and reruns `Run Close` on the override-free baseline world, the one whose `fixture_hash == BASELINE_FIXTURE_HASH` (escalator_pct 5 = baseline, still misses by $2,500.00). That world always has a recording at `runtime/recorded/REC-<hash12>.jsonl`, keyed by the first 12 hex of its `world_hash`; the rest of the table below plays unchanged, just under the `RECORDED` badge instead of `LIVE`.

| # | Sec | Actor | Click | Screen shows | Spoken line | Fallback |
|---|---|---|---|---|---|---|
| 1 | 0-8 | presenter | none | `#clock-bar`: clock 2027-01-04T09:00, `fixture_hash` matches `BASELINE_FIXTURE_HASH`, playbook 1.0 | "Northstar Analytics, reset to a pinned hash. Nothing here is scripted." | none |
| 2 | 8-15 | presenter | hands over laptop | `#lab-panel` open | "Pick a vendor, change one real fact about their contract." | none |
| 3 | 15-30 | judge | select V001, `CTL-ESCALATOR-PCT`, pick a percent | staged `PS-001` diff, no world change yet | "Your number changes the contract, not the invoice." | preset chips for 5/8/12 if free entry is slow |
| 4 | 30-38 | judge | `btn-apply-mutation` | new `world_hash`, "regenerated in 1.4s" | "That just rebuilt a real PDF and the hidden invoice behind it." | GPF |
| 5 | 38-50 | presenter | `btn-run-close` | `#evidence-trail` streaming tool calls; S2 filling in | "Watch it pull the contract, the PO, seven prior invoices, live." | GPF |
| 6 | 50-62 | presenter | none | S2: `PRP-V001-2026-12-01` $50,000.00, `REVIEW_REQUIRED`, routed to Controller | "Fifty thousand, straight off the Year One line. The rule never asked for the price schedule." | GPF |
| 7 | 62-70 | presenter | `btn-approve-accrual` | `JE-ACR-V001-2026-12` posted | "A human signs off only because fifty thousand clears the threshold." | none |
| 8 | 70-80 | presenter | `btn-advance-time` | S4: `INV-V001-008` PDF, amount in red vs accrual | "One click forward, and the real bill lands. Not fifty thousand." | none |
| 9 | 80-85 | (auto) | none | variance card, over tolerance | "That gap is math, not a guess." | none |
| 10 | 85-100 | presenter | `btn-investigate` | `#evidence-trail`: quoted CY2 row, PS-001 locator | "It opens the pricing schedule that was sitting there the whole time." | GPF |
| 11 | 100-108 | (auto) | none | S5: `POL-0001` scope JSON, no vendor id highlighted | "Its fix names a contract feature. It never says DataForge." | GPF |
| 12 | 108-118 | presenter | `btn-run-replay` | replay table: 35 obligations, improved 1, regressed 0 | "Thirty-five past obligations, replayed live, right now. Nothing else moved." | none |
| 13 | 118-128 | judge | `btn-approve-policy` or `btn-reject-policy` | playbook badge 1.0 -> 1.1 | "Your call: approve it, or reject it and it forgets this happened." | none |
| 14 | 128-140 | presenter | `btn-advance-time` then `btn-run-transfer` | fork banner: one visible state, two arms | "Now a vendor it has never touched, a different pricing shape entirely." | GPF (learned arm only) |
| 15 | 140-165 | (auto) | none | `#transfer-panel` split table + predicate-match panel | "Same rule, new vendor: it blocks the guess and gets the right number." | GPF |
| 16 | 165-178 | presenter | open `#audit-panel` | evidence ids, policy version, approver for `OBL-V018-2027-01` | "Every dollar traces to evidence, a policy version, a name." | none |
| 17 | 178-180 | presenter | none | (wrap) | "Reject instead, and it misses by twenty-one thousand, same as today." | none |

Both required judge choices land on screen: the mutation value at beat 3, Approve/Reject at beat 13.

## 5. Sixty-second pairwise expo variant

SCN-A only, compressed, preset buttons instead of free entry, results revealed rather than narrated step by step. Same GPF rule; pre-armed at a 3-second timeout since there is no slack to wait.

| # | Sec | Actor | Click | Screen shows | Spoken line |
|---|---|---|---|---|---|
| 1 | 0-6 | presenter | none | clock-bar, hash pinned | "Live agent, real contract data, one pinned hash." |
| 2 | 6-16 | judge | preset chip "8% escalator" then `btn-apply-mutation` | diff + new hash | "Pick the miss size." |
| 3 | 16-28 | presenter | `btn-run-close` then `btn-approve-accrual` | S2 accrual $50,000.00, `CONTROLLER` | "It accrues fifty thousand off the order form." |
| 4 | 28-38 | presenter | `btn-advance-time` | invoice $54,000.00, variance card | "Real bill: fifty-four. A four-thousand-dollar miss." |
| 5 | 38-48 | presenter | `btn-investigate` (result pre-warmed) | root cause card, `POL-0001` scope | "It finds the missed pricing schedule and drafts a fix, no vendor name." |
| 6 | 48-58 | judge | `btn-approve-policy` | badge 1.0 -> 1.1 | "You approve it; it becomes company memory." |
| 7 | 58-60 | presenter | none | (wrap) | "Next vendor, same rule, no retraining." |

## 6. Pre-demo checklist

1. `POST /sim/reset/demo`; confirm response `fixture_hash == BASELINE_FIXTURE_HASH`.
2. `GET /sim/hash` and `GET /api/state`: confirm `world_hash` matches, playbook version `1.0`, badge `LIVE`.
3. Warm the LLM path once: run SCN-A live at baseline (escalator_pct 5, no Apply Change needed) end to end through `Run Transfer Compare`, so `runtime/recorded/REC-<hash12>.jsonl` exists for `BASELINE_FIXTURE_HASH`. This file is the GPF safety net and is not cleared by `Reset World` or `Reset Demo`.
4. `POST /sim/reset/demo` again to return to `IDLE_BASELINE` with a clean `trueup_state.db` (the recording from step 3 survives; the run itself does not).
5. Stage a dry-run override for each of the three demo-path controls (`CTL-ESCALATOR-PCT`, `CTL-ESCALATOR-DATE`, `CTL-SURCHARGE`) with `POST /sim/overrides/stage`, confirm the diff preview renders in under 2s, then `DELETE /sim/overrides` to clear them unapplied.
6. One throwaway live model call (any beat-02-style evidence citation) to confirm API reachability before judges arrive.
7. Open `GET /` once, confirm `#clock-bar` shows the 12-hex `world_hash` / `BASELINE_FIXTURE_HASH` pair and the `LIVE`/`RECORDED` badge toggles correctly when `TRUEUP_DEMO_MODE` is flipped.
8. Confirm all twelve buttons in `00-decisions.md` section 1.3 render with the correct enabled/disabled state for `IDLE_BASELINE` per the state table in `02-state-machine-and-time.md`.
9. Leave `TRUEUP_DEMO_MODE=live` for the judge session; only flip to `cached` deliberately if GPF is invoked.
