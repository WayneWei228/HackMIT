# 00 Decisions: shared contract for the interactive judge demo

Scope: names, control catalogue, state machine, the three judge scenarios, endpoint and table lists, section ownership.
Binding on sections 01 to 05. Product spec and `data/WORLD_SPEC.md` are frozen. Every id, amount and date below is reused from WORLD_SPEC or derived from it by the arithmetic shown.

**Declared departure from WORLD_SPEC, stated once.** `WORLD_SPEC.md` line 263 sets PO-1063 `authorized_amount` to $360,000.00, and `360000.00 / 12 = 30000.00` is exactly the held-out answer, so the PO back-solves the price the agent is supposed to earn. This specification pins PO-1063 at `authorized_amount = 415000.00`, a not-to-exceed blanket PO for 2027 that authorises spend and states no price. `415000.00 / 12 = 34583.33`; the nearest offered monthly fee is $33,000.00, a gap of $1,583.33, wider than the $500.00 tolerance on any V018 accrual. The baseline production fee of $30,000.00 per month is stated only by PS-018. Every judge parameter must satisfy `12 x monthly_fee <= 415000.00`. This is the only value this specification changes in the frozen world; leakage test LK11 (`02-state-machine-and-time.md` section 5) asserts the property for every offered parameter value.

## 1. Glossary

### 1.1 Services and roots

| Name | Process | Owns | Never sees |
|---|---|---|---|
| Simulator (`sim`) | FastAPI, port 8100 | `world/seed`, `world/private`, the clock, the Scenario Lab, ScenarioOverrides, regeneration, `runtime/mutation_log.jsonl` | TrueUp state and the playbook database |
| TrueUp (`trueup`) | FastAPI, port 8000 | agents, deterministic estimator, verifier, `trueup_state.db`, `trueup_playbook.db`, the web page | `world/`, `sim_state.json`, `mutation_log.jsonl`, any event with `release_at` later than the clock |

The Lab belongs to `sim`. TrueUp tools receive `runtime/visible/` only (WORLD_SPEC 3.7 L3).
`trueup` exposes `/api/lab/*` as a byte passthrough proxy to `sim`, so the browser has one origin. The proxy module imports nothing from `data/gen`.

### 1.2 UI panels (one web page, `GET /`)

`#clock-bar` "Clock and World" (header: simulated clock, period statuses, playbook version badge, 12 hex world hash, `LIVE` or `RECORDED` badge); `#lab-panel` "Scenario Lab"; `#diff-panel` "What Changed"; `#close-board` "Close Command Center" (S1); `#workpaper` "Vendor Obligation Workpaper" (S2); `#outreach-queue` "Outreach and Resolution" (S3); `#trueup-panel` "Invoice and True-Up" (S4); `#evidence-trail` "Evidence Trail" (live tool-call stream); `#learning-panel` "Learning and Controls" (S5); `#transfer-panel` "Frozen vs Learned"; `#audit-panel` "Audit Packet" (S6).

### 1.3 Buttons

`btn-apply-mutation` "Apply Change"; `btn-undo-mutation` "Undo Change"; `btn-run-close` "Run Close"; `btn-approve-accrual` "Approve Accrual"; `btn-advance-time` "Advance Time"; `btn-investigate` "Investigate Variance"; `btn-run-replay` "Run Replay"; `btn-approve-policy` "Approve Policy"; `btn-reject-policy` "Reject Policy"; `btn-run-transfer` "Run Transfer Compare"; `btn-reset-world` "Reset World"; `btn-reset-demo` "Reset Demo".

### 1.4 ScenarioOverride

One JSON object per judge change. Lives only in `runtime/mutation_log.jsonl` and `sim_state.json.overrides`. Never written under `runtime/visible/`.

```json
{"override_id":"OVR-0001","control_id":"CTL-ESCALATOR-PCT","validator":"VAL-ESCALATOR-PCT",
 "target":{"kind":"PRICING_SCHEDULE","doc_id":"PS-001","vendor_id":"V001","contract_id":"CTR-001"},
 "param":{"escalator_pct":8.0},"baseline_param":{"escalator_pct":5.0},
 "visible_doc_changed":"contracts/pricing_schedules/PS-001.txt",
 "hidden_records_rederived":["INV-V001-008","INV-V001-009"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"9f2c41ab77d0"}
```

Rules. One override per run by default; `POST /sim/overrides/apply` rejects a second staged override unless `allow_multi=true`. A control parameter never edits a truth file. The simulator re-runs `world.py` pricing functions with the override applied, then rebuilds `world/seed`, `world/private/events.jsonl` and `world/private/truth/`, so a contract schedule and its hidden invoice can never disagree. Regeneration renders a PDF only for `visible_doc_changed`; all other PDFs are copied from `world/pdf_cache/`. Budget: under 2 seconds.

### 1.5 Hashes

- `world_hash` = sha256 over the newline joined sorted list of `"<relative path> <sha256 of file bytes>"` for every file under `runtime/visible/` (WORLD_SPEC 3.6).
- `fixture_hash` = the same function over `world/seed/`, `world/private/events.jsonl` and `world/private/truth/`.
- `BASELINE_FIXTURE_HASH` = the `fixture_hash` of an override free build. Pinned in `data/demo_spec/BASELINE_HASH.txt`, printed in `#clock-bar`, re-verified by Reset Demo.
- The UI shows the first 12 hex characters of each hash.

### 1.6 Additive deltas to frozen schemas

Only these. Nothing else in the product spec or WORLD_SPEC changes.
`VendorObligation.root_cause` gains `UNKNOWN`. VarianceExplanation `process_cause` gains `NO_OBSERVABLE_FEATURE` and `NO_CONTRACTUAL_BASIS`. The policy status enum is `CANDIDATE`, `BLOCKED`, `ACTIVE_PROVISIONAL`, `ACTIVE`, `REJECTED`, `REVOKED`. New record types: ScenarioOverride, AgentRun, ToolCall, EscalationNote.

### 1.7 Policy scope whitelist

A candidate policy predicate may reference only `estimator_method` and these ContractFeatures fields: `contract_type`, `pricing_structure`, `billing_cadence`, `has_scheduled_price_change`, `has_pricing_exhibit`, `has_usage_component`, `termination_notice_on_file`, `auto_renews`, `notice_days`.
Banned anywhere in a policy record: `vendor_id`, vendor name, `contract_id`, `category`, `cost_center`, `po_id`, and any post cutoff fact (`invoice_id`, `true_up_amount`, `actual_invoice_total`, `root_cause`).

## 2. Control catalogue

Whitelist matrix: a control is offered only for the vendors listed. Every row has one validator that keeps the world internally consistent after regeneration.

| control_id | Eligible vendors | Parameter enum | Visible document diff | Hidden records re-derived | v1.0 behaviour | Learned behaviour | Flag |
|---|---|---|---|---|---|---|---|
| `CTL-ESCALATOR-PCT` | V001, V004, V018 | V001 `escalator_pct` 0 / 5 / 8 / 12 (on $50,000.00); V004 `escalator_pct` 0 / 4 / 6 / 10 (on $18,000.00); V018 `production_monthly_fee` 12000 / 24000 / 30000 / 33000 | `contracts/pricing_schedules/PS-001.txt`, `contracts/CTR-004.txt` footnote, `contracts/pricing_schedules/PS-018.txt` | INV-V001-008, INV-V001-009, INV-V004-009, INV-V018-001 | accrues the order form fee, misses by the uplift | attaches `pricing_schedule_effective`, accrues the effective fee | demo-path |
| `CTL-ESCALATOR-DATE` | V001, V018 | V001 `cy2_effective_date` 2026-12-01 / 2027-01-01 / 2027-02-01; V018 `production_effective_date` 2027-01-01 / 2027-02-01 | same PS files, Start and End cells | same invoices | accrues the order form fee regardless of date | reads the row covering the service period, so a later date correctly yields the old price | demo-path |
| `CTL-SURCHARGE` | V006, V007 | `surcharge_amount` 0.00 / 900.00 / 2400.00 / 6000.00 | none by design | INV-V006-003, INV-V007-006 (amount plus one line item) | accrues from timesheets or the Controller decision | identical: no predicate matches, root cause `UNKNOWN`, `ESCALATED`, no candidate | demo-path |
| `CTL-INVOICE-DELAY` | V001, V002, V019 | `delay_days` 0 / 7 / 21 / 35 | none | `release_at` of the INVOICE_RECEIVED event | accrues at cutoff, trues up when the invoice lands | same | lab extra 1 |
| `CTL-SVC-CONFIRM` | V001, V006 | `service_evidence` CONFIRMED / PENDING / ABSENT | `evidence/timesheets.csv` `approval_status`, `evidence/service_activity.csv` row | scripted reply availability, timesheet patch event | PENDING triggers `OUTREACH_REQUIRED`; ABSENT triggers `ESCALATE`, never a silent accrual | same | lab extra 2 |
| `CTL-USAGE-SPIKE` | V002, V013 | `spike_multiplier` 1.0 / 1.25 / 1.5 / 2.0 on December daily rows | `evidence/usage_daily.csv` December rows | INV-V002-008, INV-V013-008 | `USAGE_X_RATE` over the full rate card, correct at any multiplier | same | lab extra 3 |
| `CTL-DUP-INVOICE` | V008, V012 | `duplicate` NONE / EXACT_COPY / NEW_NUMBER | `invoices/invoices.json`, `ap_queue.csv` | the duplicate INVOICE_RECEIVED event | `DUPLICATE_SUSPECTED`, verifier `BLOCK`, `HOLD_DO_NOT_POST`, notify E003 | same | lab extra 4 |
| `CTL-TERMINATE` | V005, V019 | `termination_effective` NONE / 2026-11-30 / 2026-12-15 / 2026-12-31 | `contracts/notices/TN-019.txt` effective line, or new `TN-005` | final prorated invoice, later invoices deleted, `service_activity` last activity date | `PRORATED_FEE` for the served days, `NO_ACCRUAL_DOCUMENTED` afterwards | same | lab extra 5 |
| `CTL-CADENCE` | V008, V014 | `billing_cadence` MONTHLY_ARREARS / MONTHLY_ADVANCE / QUARTERLY_ARREARS | `contracts/CTR-008.txt`, `contracts/CTR-014.txt` billing clause | invoice service periods and release dates | cadence changes which months need an accrual, amounts unchanged | same | lab extra 6 |

Cut order if time runs out: drop `CTL-CADENCE` first, then `CTL-TERMINATE`, `CTL-DUP-INVOICE`, `CTL-USAGE-SPIKE`, `CTL-SVC-CONFIRM`, `CTL-INVOICE-DELAY`. The three demo-path controls are never cut.

Validators, one per control, except `CTL-ESCALATOR-PCT`, which uses `VAL-ESCALATOR-PCT` for V001 and V004 and `VAL-PRODUCTION-FEE` for V018: `VAL-ESCALATOR-PCT` (new fee > 0; every invoice on or after the effective date re-derived from the same pricing function; PO amounts untouched), `VAL-PRODUCTION-FEE` (`12 x fee <= 415000.00`), `VAL-ESCALATOR-DATE` (first of a month; V001 not earlier than 2026-12-01 so no closed period changes; V018 not earlier than 2027-01-01 because V018 is not in the vendor master before 2027-01-08), `VAL-SURCHARGE` (a new invoice line, no contract text change, no pre-cutoff evidence change), `VAL-INVOICE-DELAY` (`release_at <= 2027-02-15T23:59:59`, invoice still matches its obligation), `VAL-SVC-CONFIRM` (either another source still evidences the period or the expected outcome becomes outreach or escalation), `VAL-USAGE-SPIKE` (daily rows scale, monthly total equals the sum, invoice re-derived from the rate card), `VAL-DUP-INVOICE` (same PO, amount and service period, distinct `invoice_id`, still one goods receipt), `VAL-TERMINATE` (effective date inside the term and not earlier than 2026-12-01; final fee `= monthly_fee x days_served / days_in_month`, half-up to 2 decimals), `VAL-CADENCE` (annual fee constant; service periods tile the term with no gap or overlap).

The Lab shows a diff for `PS-018` and `TN-005` with the label "not visible to the agent until <release timestamp>". Showing the judge a future document is not a leak: it never enters `runtime/visible/` before its event releases.

## 3. Demo state machine

States are UPPER_SNAKE and stored in `demo_state.state`. The clock column is the simulator clock on entry.

| State | Clock on entry | Enabled buttons |
|---|---|---|
| `IDLE_BASELINE` | 2027-01-04T09:00:00 | Apply Change (after staging), Run Close, Reset World, Reset Demo |
| `MUTATION_STAGED` | 2027-01-04T09:00:00 | Apply Change, Undo Change |
| `MUTATION_APPLIED` | 2027-01-04T09:00:00 | Run Close, Undo Change |
| `CLOSE_RUNNING` | 2027-01-04T09:00:00 to 2027-01-05T15:30:00 | none |
| `CLOSE_AWAITING_APPROVAL` | 2027-01-05T16:00:00 | Approve Accrual |
| `CLOSE_POSTED` | 2027-01-05T23:59:59 | Advance Time |
| `TRUEUP_COMPUTED` | 2027-01-12T09:00:00 (SCN-A), 2027-01-15T09:00:00 (SCN-C) | Investigate Variance |
| `NO_MISS` | same | Advance Time, Reset World, Reset Demo |
| `INVESTIGATING` | 2027-01-13T09:00:00 (SCN-A), 2027-01-15T11:00:00 (SCN-C) | none |
| `ROOT_CAUSE_FOUND` | 2027-01-13T09:00:00 | Run Replay |
| `ROOT_CAUSE_UNKNOWN` | 2027-01-15T11:00:00 | none |
| `ESCALATED` | 2027-01-15T12:00:00 | Reset World, Reset Demo |
| `CANDIDATE_READY` | 2027-01-13T09:30:00 | Run Replay |
| `CANDIDATE_BLOCKED` | 2027-01-13T09:30:00 (guard G1) or 2027-01-13T11:00:00 (guard G2) | Reject Policy, Reset World |
| `REPLAY_REPORT_READY` | 2027-01-13T11:00:00 | Approve Policy, Reject Policy |
| `POLICY_APPROVED` | 2027-01-15T10:00:00 | Advance Time, Run Transfer Compare |
| `POLICY_REJECTED` | 2027-01-15T10:00:00 | Advance Time, Run Transfer Compare |
| `TRANSFER_RUNNING` | 2027-02-05T09:00:00 | none |
| `TRANSFER_COMPARED` | 2027-02-12T09:00:00 | Reset World, Reset Demo |

Transitions.

| From | Event | Guard | To |
|---|---|---|---|
| `IDLE_BASELINE` | Lab selection changed | control, vendor and parameter all set | `MUTATION_STAGED` |
| `MUTATION_STAGED` | `btn-apply-mutation` | validator passes | `MUTATION_APPLIED` |
| `MUTATION_STAGED` / `MUTATION_APPLIED` | `btn-undo-mutation` | - | `IDLE_BASELINE` |
| `IDLE_BASELINE` / `MUTATION_APPLIED` | `btn-run-close` | period 2026-12 status is OPEN | `CLOSE_RUNNING` |
| `CLOSE_RUNNING` | agent emits `POST_ACCRUAL` proposal | verifier `required_approval_level != NONE` | `CLOSE_AWAITING_APPROVAL` |
| `CLOSE_RUNNING` | verifier result `ESCALATE` | conflicting or absent evidence | `ESCALATED` |
| `CLOSE_AWAITING_APPROVAL` | `btn-approve-accrual` | actor E001 for `CONTROLLER`, E002 for `REVIEWER` | `CLOSE_POSTED` |
| `CLOSE_POSTED` | `btn-advance-time` | target clock greater than current clock | `TRUEUP_COMPUTED` |
| `TRUEUP_COMPUTED` | automatic | `abs(variance) <= tolerance` | `NO_MISS` |
| `TRUEUP_COMPUTED` | `btn-investigate` | `abs(variance) > tolerance` | `INVESTIGATING` |
| `INVESTIGATING` | classifier returns a root cause in the enum | a pre cutoff observable feature supports it | `ROOT_CAUSE_FOUND` |
| `INVESTIGATING` | classifier returns `UNKNOWN` | no contractual basis and no pre cutoff observable feature | `ROOT_CAUSE_UNKNOWN` |
| `ROOT_CAUSE_UNKNOWN` | automatic | - | `ESCALATED` (EscalationNote to E001, no candidate policy) |
| `ROOT_CAUSE_FOUND` | `POST /api/policy/candidate`, guard G1 | `evidence_existed_at_close` is true and every predicate is on the 1.7 whitelist | `CANDIDATE_READY` |
| `ROOT_CAUSE_FOUND` | automatic | `evidence_existed_at_close` is false (Controller judgement) | `ESCALATED` |
| `ROOT_CAUSE_FOUND` | `POST /api/policy/candidate`, guard G1 | any predicate outside the 1.7 whitelist, or a post cutoff field | `CANDIDATE_BLOCKED` |
| `CANDIDATE_READY` | `btn-run-replay` | G1 passed | `REPLAY_REPORT_READY` |
| `REPLAY_REPORT_READY` | guard G2 | `regressed > 0` or `abs_error_after >= abs_error_before` | `CANDIDATE_BLOCKED` |
| `REPLAY_REPORT_READY` | `btn-approve-policy` | G1 and G2 passed, actor E001 | `POLICY_APPROVED` |
| `REPLAY_REPORT_READY` / `CANDIDATE_BLOCKED` | `btn-reject-policy` | - | `POLICY_REJECTED` |
| `POLICY_APPROVED` / `POLICY_REJECTED` / `NO_MISS` | `btn-run-transfer` | clock at or after 2027-02-01T00:00:00 | `TRANSFER_RUNNING` |
| `TRANSFER_RUNNING` | both arms finish | - | `TRANSFER_COMPARED` |
| any | `btn-reset-world` | - | `IDLE_BASELINE` |
| any | `btn-reset-demo` | `fixture_hash == BASELINE_FIXTURE_HASH` after rebuild | `IDLE_BASELINE` |

`btn-approve-policy` is rendered disabled in `CANDIDATE_BLOCKED`, with the failing guard named on the button.
Reset World clears overrides, rebuilds the baseline world, resets the runtime to T0, fast-forwards to 2027-01-04T09:00:00, wipes `trueup_state.db` and keeps `trueup_playbook.db`. The playbook badge in `#clock-bar` therefore still reads 1.1 after a Reset World that follows an approval.
Reset Demo does all of that and also drops and re-seeds `trueup_playbook.db` at version 1.0, then prints `BASELINE_FIXTURE_HASH`.

## 4. The three judge scenarios

Common accounts: accrual is `Dr <expense> / Cr 2100`, dated the last day of the service month, reversed on day 1 of the next month. The invoice posts `Dr <expense> / Cr 2000` for the accrued amount, and the true-up posts `Dr <expense> / Cr 2000` for the variance. A zero variance produces no `JE-TRU-` row. Tolerance is `max(500.00, 0.02 x accrued amount)`.

### SCN-A learnable failure

Vendor V001 DataForge, obligation `OBL-V001-2026-12`, control `CTL-ESCALATOR-PCT`, accounts Dr 6100 / Cr 2100 and Cr 2000, CC-100, entry 2026-12-31, reversal 2027-01-01, true-up dated 2027-01-12.
Accrual under v1.0 is always the CTR-001 order form Contract Year 1 fee of $50,000.00. Tolerance is `max(500.00, 0.02 x 50000.00) = 1000.00`.
CY2 fee is `50000.00 x (1 + pct/100)`: 0 percent 50,000.00; 5 percent 52,500.00; 8 percent 54,000.00; 12 percent 56,000.00.

| `escalator_pct` | v1.0 accrual (JE-ACR) | Hidden INV-V001-008 | Variance | vs $1,000.00 | JE-TRU amount | Approval | Branch |
|---|---|---|---|---|---|---|---|
| 0 | 50,000.00 | 50,000.00 | 0.00 | inside | none | CONTROLLER E001 | `NO_MISS`, root cause `TIMING_ONLY`, no candidate |
| 5 | 50,000.00 | 52,500.00 | +2,500.00 | outside | 2,500.00 | CONTROLLER E001 | POL-0001 candidate |
| 8 | 50,000.00 | 54,000.00 | +4,000.00 | outside | 4,000.00 | CONTROLLER E001 | POL-0001 candidate |
| 12 | 50,000.00 | 56,000.00 | +6,000.00 | outside | 6,000.00 | CONTROLLER E001 | POL-0001 candidate |

Under the learned playbook the same obligation accrues the CY2 fee and the variance is 0.00 in every row. Replay at 2027-01-13 over the 35 obligations of 2026-11 and 2026-12 touches `OBL-V001-2026-12` only: `abs_error_before` equals the variance above, `abs_error_after` 0.00, improved 1, regressed 0.

### SCN-B transfer to an unseen vendor

Vendor V018 SignalStack, obligation `OBL-V018-2027-01`, accounts Dr 6120 / Cr 2100 and Cr 2000, CC-190, entry 2027-01-31, reversal 2027-02-01, true-up dated 2027-02-12. Frozen and learned arms both fork snapshot `2027-01-open` at 2027-02-01T00:00:00, so the visible state is byte identical.
Frozen v1.0 always accrues the CTR-018 order form pilot fee of $12,000.00, corroborated by `JE-CARD-0001` and `JE-CARD-0002`. Tolerance is `max(500.00, 0.02 x 12000.00 = 240.00) = 500.00`.

Control `CTL-ESCALATOR-PCT`, parameter `production_monthly_fee`:

| Fee | Frozen accrual | Hidden INV-V018-001 | Frozen variance | vs $500.00 | Frozen JE-TRU | Learned accrual | Learned variance | Learned approval |
|---|---|---|---|---|---|---|---|---|
| 12,000.00 | 12,000.00 | 12,000.00 | 0.00 | inside | none | 12,000.00 | 0.00 | REVIEWER E002 |
| 24,000.00 | 12,000.00 | 24,000.00 | +12,000.00 | outside | 12,000.00 | 24,000.00 | 0.00 | REVIEWER E002 |
| 30,000.00 | 12,000.00 | 30,000.00 | +18,000.00 | outside | 18,000.00 | 30,000.00 | 0.00 | CONTROLLER E001 |
| 33,000.00 | 12,000.00 | 33,000.00 | +21,000.00 | outside | 21,000.00 | 33,000.00 | 0.00 | CONTROLLER E001 |

Control `CTL-ESCALATOR-DATE`, parameter `production_effective_date`:

| Date | January is priced as | Frozen accrual | Hidden invoice | Frozen variance | Learned accrual | Learned variance |
|---|---|---|---|---|---|---|
| 2027-01-01 | production | 12,000.00 | 30,000.00 | +18,000.00 | 30,000.00 | 0.00 |
| 2027-02-01 | pilot | 12,000.00 | 12,000.00 | 0.00 | 12,000.00 | 0.00 |

The 2027-02-01 row is the proof that transfer is not memorised: the learned agent reads the PS-018 row covering 2027-01-01 to 2027-01-31 and books the pilot fee.
`#transfer-panel` prints the predicate match for the learned arm: `estimator_method = FIXED_CONTRACT_FEE` matched, `has_scheduled_price_change = true` matched, `pricing_structure = SCHEDULED_STEP` in the allowed list, and a line stating that POL-0001 contains no vendor identifier, with the serialized policy record beside it.

### SCN-C refuse to learn

Control `CTL-SURCHARGE`. The invoice gains one line, "Year end expedite premium", with no clause in CTR-006 or CTR-007 and no pre cutoff observable feature. Root cause `UNKNOWN`, process cause `NO_CONTRACTUAL_BASIS`, outcome `ESCALATED`, `EscalationNote` to E001, no candidate policy.

V006 Brightwork, `OBL-V006-2026-12`, Dr 6200 / Cr 2100 and Cr 2000, CC-140, entry 2026-12-31, reversal 2027-01-01, true-up dated 2027-01-15. Accrual is `142 x 185.00 = 26,270.00` by `USAGE_X_RATE`, approval CONTROLLER. Tolerance is `max(500.00, 0.02 x 26270.00 = 525.40) = 525.40`.

| `surcharge_amount` | v1.0 accrual | Hidden INV-V006-003 | Variance | vs $525.40 | JE-TRU amount | Outcome |
|---|---|---|---|---|---|---|
| 0.00 | 26,270.00 | 26,270.00 | 0.00 | inside | none | RECONCILED, no review |
| 900.00 | 26,270.00 | 27,170.00 | +900.00 | outside | 900.00 | `UNKNOWN`, ESCALATED, no candidate |
| 2,400.00 | 26,270.00 | 28,670.00 | +2,400.00 | outside | 2,400.00 | same |
| 6,000.00 | 26,270.00 | 32,270.00 | +6,000.00 | outside | 6,000.00 | same |

V007 Meridian, `OBL-V007-2026-12`, Dr 6210 / Cr 2100 and Cr 2000, CC-150, entry 2026-12-31, reversal 2027-01-01, true-up dated 2027-01-22. Accrual is the Controller decision of 40,000.00 with `estimator_method = NONE`. Tolerance is `max(500.00, 0.02 x 40000.00 = 800.00) = 800.00`.

| `surcharge_amount` | v1.0 accrual | Hidden INV-V007-006 | Variance | vs $800.00 | JE-TRU amount | Outcome |
|---|---|---|---|---|---|---|
| 0.00 | 40,000.00 | 41,870.00 | +1,870.00 | outside | 1,870.00 | `ESTIMATE_JUDGMENT`, ESCALATED, no candidate |
| 900.00 | 40,000.00 | 42,770.00 | +2,770.00 | outside | 2,770.00 | `UNKNOWN`, ESCALATED, no candidate |
| 2,400.00 | 40,000.00 | 44,270.00 | +4,270.00 | outside | 4,270.00 | same |
| 6,000.00 | 40,000.00 | 47,870.00 | +7,870.00 | outside | 7,870.00 | same |

Second guard, independent of the classifier: guard G1 blocks any candidate whose predicates leave the 1.7 whitelist or reference a post cutoff fact, and guard G2 blocks any candidate with `regressed > 0` or no reduction in absolute error. A blocked candidate never reaches `btn-approve-policy`.

## 5. Endpoints, tables and id formats

Simulator, base `/sim`:

| Method and path | Purpose |
|---|---|
| `GET /sim/health` | liveness and build version |
| `GET /sim/controls` | the whitelist matrix of section 2 |
| `POST /sim/overrides/stage` | validate a ScenarioOverride and return the document diff, no world change |
| `POST /sim/overrides/apply` | regenerate world, reset runtime, fast-forward to `start_clock` |
| `GET /sim/overrides` | active overrides |
| `DELETE /sim/overrides` | clear overrides |
| `GET /sim/clock` | current simulated clock and period statuses |
| `POST /sim/advance` | `advance_to(ts)`, returns released `record_id`s |
| `POST /sim/outreach` | `send_outreach(req)` |
| `POST /sim/snapshot` | `snapshot(label)` |
| `POST /sim/fork` | `fork(label, dest)` for the frozen and learned arms |
| `GET /sim/hash` | `world_hash`, `fixture_hash`, `BASELINE_FIXTURE_HASH` |
| `POST /sim/reset/world` | baseline world, runtime reset, fast-forward |
| `POST /sim/reset/demo` | baseline world plus fixture hash verification |

TrueUp, base `/api`:

| Method and path | Purpose |
|---|---|
| `GET /api/state` | demo state, clock mirror, playbook version, world hash, LIVE or RECORDED |
| `GET /api/obligations` | S1 inventory for a period |
| `GET /api/obligations/{obligation_id}` | S2 workpaper with evidence, trace and verifier checklist |
| `POST /api/close/run` | run the close for a period |
| `POST /api/accrual/approve` | Controller or Reviewer approval, posts the accrual |
| `POST /api/trueup/run` | deterministic match, variance and tolerance test |
| `POST /api/investigate` | root-cause classification |
| `POST /api/policy/candidate` | create the candidate policy, apply guard G1 |
| `POST /api/policy/replay` | run replay, apply guard G2 |
| `POST /api/policy/approve` | approve, write playbook 1.1 |
| `POST /api/policy/reject` | reject, playbook stays 1.0 |
| `GET /api/playbook` | versions, policies and policy events |
| `POST /api/transfer/run` | run the frozen and learned arms from one fork |
| `GET /api/transfer/compare` | split view payload including the predicate match |
| `GET /api/audit/{obligation_id}` | audit packet |
| `GET /api/evidence-trail` | server-sent stream of tool calls for a run |
| `POST /api/reset/world` | proxy Reset World, keep the playbook database |
| `POST /api/reset/demo` | proxy Reset Demo, re-seed the playbook at 1.0 |
| `ANY /api/lab/{path}` | byte passthrough proxy to `sim` |

`trueup_playbook.db`, survives Reset World:

| Table | Columns |
|---|---|
| `playbook_versions` | `version` PK, `parent_version`, `status`, `created_at`, `activated_at`, `policies_json`, `fixture_hash` |
| `policies` | `policy_id` PK, `policy_type`, `trigger`, `scope_json`, `required_evidence_json`, `before_action`, `verifier_result_if_missing_json`, `outreach_if_missing_json`, `behavior_change`, `autonomy_limit`, `derived_from_json`, `status`, `created_at`, `policy_version_target` |
| `policy_events` | `event_id` PK, `policy_id`, `event_type`, `actor`, `decided_at`, `from_status`, `to_status`, `comment`, `replay_id` |
| `replay_reports` | `replay_id` PK, `policy_id`, `run_at`, `periods_json`, `obligations_replayed`, `improved`, `regressed`, `unchanged`, `extra_outreach`, `extra_reviews`, `abs_error_before`, `abs_error_after`, `touched_json`, `feature_matched_json`, `compared_on_action_only_json`, `forward_scope_preview_json`, `recommendation` |

`trueup_state.db`, wiped by both resets: `obligations`, `contract_features`, `evidence_facts`, `proposals`, `evaluations`, `workpapers`, `approvals`, `outreach_tasks`, `journal_entries`, `invoice_matches`, `trueups`, `variance_explanations`, `escalation_notes`, `agent_runs`, `tool_calls`, `demo_state`.

Id formats for new records: `OVR-0001` ScenarioOverride, `MUT-0001` mutation log line, `RUN-0001` AgentRun, `TC-0001-007` ToolCall, `ESC-V006-2026-12-01` EscalationNote, `PEV-0001` policy event, `REC-<first 12 of world_hash>` recorded run, `SCN-A` to `SCN-C` scenarios, `CTL-<SLUG>` controls, `VAL-<SLUG>` validators. Existing formats (`OBL-`, `PRP-`, `PE-`, `WP-`, `APR-`, `OUT-`, `JE-`, `IM-`, `TU-`, `VE-`, `EXC-`, `POL-`, `RPL-`) are unchanged.

Live-LLM risk. Every agent run streams its tool calls to `#evidence-trail` over `GET /api/evidence-trail`. A recorded run exists only for the override-free baseline world, identified by `fixture_hash == BASELINE_FIXTURE_HASH`; it is stored at `runtime/recorded/REC-<hash12>.jsonl` where `hash12` is the first 12 hex characters of that world's `world_hash`, and `#clock-bar` shows the `RECORDED` badge while it plays. Any mutated world runs live only. If a live model call fails, the state machine goes to `ESCALATED` with the error shown; it never substitutes a recorded answer.

## 6. Section ownership

| Section | File | Owns |
|---|---|---|
| 01 | `01-scenario-lab-and-mutations.md` | Scenario Lab layout, control widgets, the per control data mutation detail, diff rendering, regeneration budget; button semantics for `btn-apply-mutation` and `btn-undo-mutation` |
| 02 | `02-state-machine-and-time.md` | state machine detail, clock handling, hidden-data protection; button semantics for `btn-run-close`, `btn-advance-time`, `btn-reset-world`, `btn-reset-demo` |
| 03 | `03-playbook-memory-and-api.md` | playbook memory, policy lifecycle, replay, frozen vs learned arms, API and state change detail; button semantics for `btn-approve-accrual`, `btn-investigate`, `btn-run-replay`, `btn-approve-policy`, `btn-reject-policy`, `btn-run-transfer` |
| 04 | `04-scenarios-and-demo-flow.md` | the three scenarios end to end and the 3 minute judge flow |
| 05 | `05-weaknesses-and-fixes.md` | attacks a Maximor judge could make and the smallest fixes |

The twelve buttons of section 1.3 are covered exactly once across sections 01 to 03.
