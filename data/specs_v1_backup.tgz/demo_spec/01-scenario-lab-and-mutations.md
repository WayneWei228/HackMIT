# 01: Judge Scenario Lab UI and mutations

Scope: deliverables 1 and 2 of BRIEF.md. Binding on this file: `00-decisions.md`. Every id, amount and date below is reused from `WORLD_SPEC.md` or derived from it by the arithmetic shown once.

## 1. Judge Scenario Lab UI (deliverable 1)

### 1.1 Page layout

```
+----------------------------------------------------------------------------+
| #clock-bar  Clock 2027-01-04T09:00:00 | 2026-12 OPEN | Playbook v1.0       |
|             World hash 9f2c41ab77d0 | Fixture hash a10efc9b2d31  [LIVE]    |
+----------------------------------------------------------------------------+
| #lab-panel  SCENARIO LAB                | #diff-panel  WHAT CHANGED        |
| Scenario control  [ dropdown v ]        | contracts/pricing_schedules/     |
| Vendor  [ dropdown v ] (disabled until   |   PS-001.txt                    |
|          control chosen)                | - CY2 ... $52,500.00             |
| Parameter ( radio group ) (disabled     | + CY2 ... $54,000.00             |
|          until vendor chosen)           | Hidden records re-derived        |
| [ Apply Change ]  [ Undo Change ]       | (not shown): 2 -> INV-V001-008,  |
|                                          | INV-V001-009, rel. 01-12 / 02-10 |
+----------------------------------------------------------------------------+
| #close-board  CLOSE COMMAND CENTER (S1)  | #evidence-trail  tool calls     |
| #workpaper  VENDOR OBLIGATION WP (S2)    |                                  |
| #outreach-queue  OUTREACH (S3)           | [ Run Close ] [ Advance Time ]  |
| #trueup-panel  INVOICE / TRUE-UP (S4)    |                                  |
+----------------------------------------------------------------------------+
| #learning-panel  LEARNING (S5)  [Investigate][Run Replay]                  |
|                                  [Approve Policy][Reject Policy]           |
| #transfer-panel  FROZEN vs LEARNED  [ Run Transfer Compare ]               |
+----------------------------------------------------------------------------+
| #audit-panel  AUDIT PACKET (S6)   |  [ Reset World ]  [ Reset Demo ]       |
+----------------------------------------------------------------------------+
```

### 1.2 Lab controls, exactly as rendered

Selecting the control populates the vendor dropdown from the control's whitelist (`00-decisions.md` section 2). Selecting the vendor populates the parameter widget's choice set and default. Any selection change auto-calls `POST /sim/overrides/stage` (debounced 300ms) and repaints `#diff-panel`; nothing under `runtime/visible/` changes until `btn-apply-mutation`.

| control_id | Label text | Widget | Choices | Default |
|---|---|---|---|---|
| `CTL-ESCALATOR-PCT` | "Contract escalator" | radio group | V001: 0% / 5% / 8% / 12%; V004: 0% / 4% / 6% / 10%; V018: $12,000 / $24,000 / $30,000 / $33,000 | V001 5%, V004 4%, V018 $30,000 |
| `CTL-ESCALATOR-DATE` | "Escalator effective date" | radio group | V001: 2026-12-01 / 2027-01-01 / 2027-02-01; V018: 2027-01-01 / 2027-02-01 | V001 2026-12-01, V018 2027-01-01 |
| `CTL-SURCHARGE` | "Year-end surcharge" | radio group | $0.00 / $900.00 / $2,400.00 / $6,000.00 | $0.00 |
| `CTL-INVOICE-DELAY` | "Delay the invoice" | radio group | 0 / 7 / 21 / 35 days | 0 days |
| `CTL-SVC-CONFIRM` | "Service confirmation on file" | radio group | CONFIRMED / PENDING / ABSENT | CONFIRMED |
| `CTL-USAGE-SPIKE` | "December usage spike" | radio group | 1.0x / 1.25x / 1.5x / 2.0x | 1.0x |
| `CTL-DUP-INVOICE` | "Duplicate this invoice" | radio group | NONE / EXACT_COPY / NEW_NUMBER | NONE |
| `CTL-TERMINATE` | "Terminate the contract" | radio group | NONE / 2026-11-30 / 2026-12-15 / 2026-12-31 | V019 2026-12-15, V005 NONE |
| `CTL-CADENCE` | "Billing cadence" | radio group | MONTHLY_ARREARS / MONTHLY_ADVANCE / QUARTERLY_ARREARS | V008 MONTHLY_ADVANCE, V014 QUARTERLY_ARREARS |

Disabled states, exact tooltip text:
- Vendor dropdown: disabled, "Choose a scenario control first" until `control_id` is set.
- Parameter widget: disabled, "Choose a vendor first" until `vendor_id` is set.
- `btn-apply-mutation`: disabled until `POST /sim/overrides/stage` returns `valid: true`; disabled label reason "Validator VAL-... failed: <message>" when the staged parameter fails.
- Whole `#lab-panel`: disabled, "One change per run. Reset World to try another." once `demo_state.state` leaves `IDLE_BASELINE` / `MUTATION_STAGED` (i.e. after Apply), unless `allow_multi=true` was set on the override call.
- `CTL-DUP-INVOICE` for V012: parameter widget disabled, "No December print job on file (V012 has no obligation for 2026-12 in the baseline); duplicate is only offered on an obligation that already has an on-hand invoice" whenever the staged vendor is V012 and no `OBL-V012-2026-12` exists. V008 is unaffected (Dec rent invoice `INV-V008-008` is always on hand).
- `CTL-TERMINATE` choice `2026-11-30` and `CTL-ESCALATOR-DATE` choices before `2026-12-01` for V001: option rendered but disabled, "Would edit a CLOSED period (2026-11)."

### 1.3 What Changed panel

Two blocks, always both present after a stage call:
1. **Visible document diff.** A unified text diff of the one file in `visible_doc_changed` (`00-decisions.md` 1.4), old lines prefixed `-`, new lines `+`. For controls with no visible diff by design (`CTL-SURCHARGE`), the panel reads "No visible document changes. The surcharge only appears on the invoice that has not been released yet."
2. **Hidden records that will be re-derived.** A count and a list of `evidence_id`s only, taken from `hidden_records_rederived`, each annotated with its `release_at` timestamp and the text "not visible to the agent until <timestamp>". No amount, no file content, no diff for these rows. `PS-018` and `TN-005` previews use the same label even though the judge is looking at a document the agent cannot yet see; the label makes clear this is not a leak (`00-decisions.md` section 2, last paragraph).

### 1.4 What the judge can and cannot see

Can see: every file currently under `runtime/visible/`, `world_hash`, `fixture_hash`, `BASELINE_FIXTURE_HASH`, the simulated clock, the staged override's before/after of the one visible document it touches, the list (not content) of hidden records it will touch, and the full `#evidence-trail` of what the agent reads once a close is run.
Cannot see, ever, from the Lab: `world/private/events.jsonl`, `world/private/truth/`, `runtime/mutation_log.jsonl`, `runtime/sim_state.json`, or any file's content dated after the current clock. The hidden invoice for the active mutation (e.g. `INV-V001-008` at $54,000.00) is invisible until `btn-advance-time` releases it; the Lab shows only its id and release timestamp, never its `amount` or `line_items`.

## 2. Control mutation specifications (deliverable 2)

Every row calls `POST /sim/overrides/apply` with the `ScenarioOverride` shape of `00-decisions.md` 1.4. `override_id` and `world_hash` are illustrative 12-hex placeholders. Regeneration re-runs `world.py`'s pricing functions and rebuilds `world/seed`, `world/private/events.jsonl` and `world/private/truth/obligations_truth.csv`; a control parameter never writes a truth file directly.

### 2.1 `CTL-ESCALATOR-PCT`

ScenarioOverride (worked example, V001 5% -> 8%):
```json
{"override_id":"OVR-0001","control_id":"CTL-ESCALATOR-PCT","validator":"VAL-ESCALATOR-PCT",
 "target":{"kind":"PRICING_SCHEDULE","doc_id":"PS-001","vendor_id":"V001","contract_id":"CTR-001"},
 "param":{"escalator_pct":8.0},"baseline_param":{"escalator_pct":5.0},
 "visible_doc_changed":"contracts/pricing_schedules/PS-001.txt",
 "hidden_records_rederived":["INV-V001-008","INV-V001-009"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"7a1c9e0b44d2"}
```
World parameters changed: `world.py` pricing function input `escalator_pct` for `CTR-001` CY2 (was 5.0). Arithmetic: `52500.00 = 50000.00 x 1.05` (unchanged baseline) becomes `50000.00 x 1.08 = 54000.00`.
Derived visible records/files: `contracts/pricing_schedules/PS-001.txt` CY2 row `$52,500.00` -> `$54,000.00`; `contracts/pricing_schedules/PS-001.pdf` re-rendered; `ContractFeatures` for `CTR-001` unchanged (`has_scheduled_price_change` stays true; the exhibit's stated fee is not extracted pre-invoice).
Hidden events/truth re-derived: `events.jsonl` `INVOICE_RECEIVED` payload for `INV-V001-008` amount `52500.00` -> `54000.00`; same event for `INV-V001-009` (Feb, same CY2 rate); `obligations_truth.csv` row `OBL-V001-2026-12`: `true_expense` `52500.00`->`54000.00`, `static_error` `-2500.00`->`-4000.00`, `policy_enabled_estimate` `52500.00`->`54000.00`.
Before/after: JE-ACR-V001-2026-12 (Dr 6100/Cr 2100) stays $50,000.00 under v1.0 either way. `JE-TRU-V001-2026-12` amount `2500.00` -> `4000.00`. Variance vs tolerance $1,000.00 stays outside.

### 2.2 `CTL-ESCALATOR-DATE`

ScenarioOverride (worked example, V018 production effective 2027-01-01 -> 2027-02-01):
```json
{"override_id":"OVR-0002","control_id":"CTL-ESCALATOR-DATE","validator":"VAL-ESCALATOR-DATE",
 "target":{"kind":"PRICING_SCHEDULE","doc_id":"PS-018","vendor_id":"V018","contract_id":"CTR-018"},
 "param":{"production_effective_date":"2027-02-01"},"baseline_param":{"production_effective_date":"2027-01-01"},
 "visible_doc_changed":"contracts/pricing_schedules/PS-018.txt",
 "hidden_records_rederived":["INV-V018-001"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"3f80b6c1a9de"}
```
World parameters changed: `production_effective_date`. The validator moves the Pilot row's End date with it (VAL-ESCALATOR-DATE requires the two rows to tile the term with no gap: Pilot end becomes the day before the new Production start).
Derived visible files: `PS-018.txt` rows `Pilot | 2026-11-01 | 2026-12-31 | $12,000.00` / `Production | 2027-01-01 | ...` become `Pilot | 2026-11-01 | 2027-01-31 | $12,000.00` / `Production | 2027-02-01 | 2027-12-31 | $30,000.00`.
Hidden events/truth re-derived: `INV-V018-001` amount `30000.00` -> `12000.00` (January now falls in the Pilot row); `obligations_truth.csv` `OBL-V018-2027-01`: `true_expense` `30000.00`->`12000.00`, `policy_enabled_estimate` `30000.00`->`12000.00`, `true_contract_features.pricing_structure` stays `SCHEDULED_STEP`.
Before/after: frozen v1.0 accrual is $12,000.00 either way (order form pilot fee, date-blind). Frozen variance goes `+18,000.00` (outside $500.00) -> `0.00` (inside). Learned v1.1 accrual reads the PS-018 row covering the service period, so it also books $12,000.00 after the move; variance `0.00` either way. This is SCN-B's proof row that transfer reads dates, not a memorized number.

### 2.3 `CTL-SURCHARGE`

ScenarioOverride (worked example, V006 $0.00 -> $900.00):
```json
{"override_id":"OVR-0003","control_id":"CTL-SURCHARGE","validator":"VAL-SURCHARGE",
 "target":{"kind":"INVOICE_LINE_ITEM","invoice_id":"INV-V006-003","vendor_id":"V006","contract_id":"CTR-006"},
 "param":{"surcharge_amount":900.00},"baseline_param":{"surcharge_amount":0.00},
 "visible_doc_changed":null,
 "hidden_records_rederived":["INV-V006-003"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"c2d5f19e0a77"}
```
World parameters changed: `surcharge_amount` line item added to the invoice payload only. No contract text, no pricing schedule, no pre-cutoff evidence file changes (VAL-SURCHARGE forbids it), so nothing an agent could inspect before the invoice lands hints at the surcharge.
Derived visible files: none at stage time. `visible_doc_changed` is `null`; `#diff-panel` shows the "no visible document changes" text.
Hidden events/truth re-derived: `events.jsonl` `INVOICE_RECEIVED` payload for `INV-V006-003` gains a line item `{"description":"Year end expedite premium","quantity":1,"unit_price":900.00,"amount":900.00}`, `amount` `26270.00` -> `27170.00`; `obligations_truth.csv` `OBL-V006-2026-12` `true_expense` `26270.00` -> `27170.00`.
Before/after: v1.0 accrual is `142 x 185.00 = 26,270.00` either way (USAGE_X_RATE from timesheets, unaffected). Variance `0.00` -> `+900.00`, outside tolerance `max(500.00, 0.02x26270.00=525.40)=525.40`. `root_cause` stays `UNKNOWN`, outcome `ESCALATED`, no candidate policy (SCN-C).

### 2.4 `CTL-INVOICE-DELAY`

ScenarioOverride (worked example, V001 0 -> 21 days):
```json
{"override_id":"OVR-0004","control_id":"CTL-INVOICE-DELAY","validator":"VAL-INVOICE-DELAY",
 "target":{"kind":"EVENT_RELEASE","record_id":"INV-V001-008","vendor_id":"V001"},
 "param":{"delay_days":21},"baseline_param":{"delay_days":0},
 "visible_doc_changed":null,
 "hidden_records_rederived":["INV-V001-008"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"918d2c4bfa03"}
```
World parameters changed: the `events.jsonl` line's `release_at` for `INV-V001-008` only. Arithmetic: baseline `release_at = 2027-01-12T09:00:00`; `2027-01-12 + 21 days = 2027-02-02` (January has 31 days: day 12 + 21 = day 33 = Feb day 2), so new `release_at = 2027-02-02T09:00:00`. `invoice_date` (2026-12-31, the period end) is untouched; only `received_date` moves with `release_at`.
Derived visible files: none until Advance Time passes the new `release_at`.
Hidden events/truth re-derived: `events.jsonl` `release_at` field only; invoice content (amount, line items) unchanged; `obligations_truth.csv` `invoice_received_dates` `2027-01-12` -> `2027-02-02`.
Consistency: `VAL-INVOICE-DELAY` requires `release_at <= 2027-02-15T23:59:59` (T_END); `2027-02-02` passes. The obligation still resolves in the December close (accrual already posted); the true-up simply computes later, after a second Advance Time.

### 2.5 `CTL-SVC-CONFIRM`

ScenarioOverride (worked example, V001 CONFIRMED -> ABSENT):
```json
{"override_id":"OVR-0005","control_id":"CTL-SVC-CONFIRM","validator":"VAL-SVC-CONFIRM",
 "target":{"kind":"SERVICE_EVIDENCE","vendor_id":"V001","period":"2026-12"},
 "param":{"service_evidence":"ABSENT"},"baseline_param":{"service_evidence":"CONFIRMED"},
 "visible_doc_changed":"evidence/service_activity.csv",
 "hidden_records_rederived":[],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"5b9a0e73dc1f"}
```
World parameters changed: `evidence/service_activity.csv` row `SA-DATAFORGE-2026-12` is removed (not merely zeroed, since a zeroed row is still evidence of *something*); the scripted-inbox entry that would answer a `SERVICE_RECEIVED` outreach for V001/2026-12 is disabled (`response_type` forced to no match).
Derived visible files: before, `evidence/service_activity.csv` has `SA-DATAFORGE-2026-12,2026-12,DataForge Platform,V001,okta-sso+dataforge-admin-api,41,31,1284000,2026-12-01,2026-12-31,ACTIVE`; after, the row is absent from the file.
Hidden events/truth re-derived: no `events.jsonl` row is re-derived, so `hidden_records_rederived` is empty and `#diff-panel` block 2 reads "0 hidden records re-derived". The private scripted-response entry keyed `(V001, 2026-12, OPERATIONAL_OWNER, SERVICE_RECEIVED)` is dropped so `send_outreach` gets no reply; `obligations_truth.csv` `OBL-V001-2026-12` `verifier` `REVIEW_REQUIRED` -> `ESCALATE`, `outcome` `ACCRUED_THEN_RECONCILED` -> `ESCALATED`.
Before/after: with no service evidence and no reply, `PolicyEvaluation` invariant `SERVICE_RECEIPT_SUPPORTED` fails, result `ESCALATE` (control table rule: "ABSENT triggers ESCALATE, never a silent accrual"), routed to E001. `PENDING` (not used in this worked example) instead triggers `OUTREACH_REQUIRED` to the owner, matching the existing Brightwork mechanism.

### 2.6 `CTL-USAGE-SPIKE`

ScenarioOverride (worked example, V002 1.0x -> 1.5x):
```json
{"override_id":"OVR-0006","control_id":"CTL-USAGE-SPIKE","validator":"VAL-USAGE-SPIKE",
 "target":{"kind":"USAGE_DAILY","vendor_id":"V002","period":"2026-12","contract_id":"CTR-002"},
 "param":{"spike_multiplier":1.5},"baseline_param":{"spike_multiplier":1.0},
 "visible_doc_changed":"evidence/usage_daily.csv",
 "hidden_records_rederived":["INV-V002-008"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"a4c0f7e2b615"}
```
World parameters changed: every December `compute_hours` row for V002 multiplied by 1.5, last day absorbing the rounding remainder so the monthly total is exact.
Arithmetic: baseline December total `352,000` hours -> `352,000 x 1.5 = 528,000` hours. CTR-002 rate card: `300,000` included hours in the `$36,000.00` commit, `$0.15`/hour overage. Overage hours `528,000 - 300,000 = 228,000`; overage cost `228,000 x 0.15 = 34,200.00`; total `36,000.00 + 34,200.00 = 70,200.00`.
Derived visible files: `evidence/usage_daily.csv` December rows for V002, each `quantity` scaled (e.g. `2026-12-01` row `11,532` -> `17,298`).
Hidden events/truth re-derived: `INVOICE_RECEIVED` payload for `INV-V002-008` `amount` `43800.00` -> `70200.00`; `obligations_truth.csv` `OBL-V002-2026-12` `true_expense` `43800.00`->`70200.00`, `static_rules_estimate` matches (USAGE_X_RATE is always correct, per section 4.2 note that the deterministic estimator applies the full tiered rate card regardless of spike size); `static_error` stays `0.00`.
Before/after: v1.0 accrual is `USAGE_X_RATE` over the full tiered rate card at either multiplier, so the accrual is always correct and the true-up is always `$0.00`; the control demonstrates that usage-based methods do not miss, unlike the fixed-fee escalator case.

### 2.7 `CTL-DUP-INVOICE`

ScenarioOverride (worked example, V008 NONE -> EXACT_COPY on `INV-V008-008`):
```json
{"override_id":"OVR-0007","control_id":"CTL-DUP-INVOICE","validator":"VAL-DUP-INVOICE",
 "target":{"kind":"INVOICE","invoice_id":"INV-V008-008","vendor_id":"V008","po_id":null},
 "param":{"duplicate":"EXACT_COPY"},"baseline_param":{"duplicate":"NONE"},
 "visible_doc_changed":"invoices/invoices.json",
 "hidden_records_rederived":["INV-V008-008-DUP"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"e6712fbc409a"}
```
World parameters changed: a second `INVOICE_RECEIVED` event is inserted, same PO (none for V008), amount `22500.00`, same service period as `INV-V008-008` (December rent, billed in advance). The original is a seed record (`received_date 2026-11-25`, before T0), so the duplicate cannot be released one day after it without landing in the CLOSED 2026-11 period; its `release_at` is `2027-01-05T09:00:00`, the day after the demo start clock and before the 2026-12 cutoff instant `2027-01-05T23:59:59`, so it arrives inside the open December close.
Derived visible files: `invoices/invoices.json` gains one record; `invoice_id` = `INV-V008-008-DUP` (original id plus suffix, per validator "duplicate gets a new invoice_id with the same number plus suffix"); `invoice_number` stays `ON-2256` for `EXACT_COPY`, or becomes `ON-2256-B` for `NEW_NUMBER`. `ap_queue.csv` gains `AP-V008-008-DUP` with `status = ON_HOLD`.
Hidden events/truth re-derived: `extra_exceptions.json` gains one entry keyed `EXC-INV-V008-008-DUP` (the `EXC-<invoice_id>` form of `EXC-INV-V012-004`); `obligations_truth.csv` is unchanged for `OBL-V008-2026-12` itself (`true_expense` still `22500.00`, one payment) because the duplicate must never post a second time.
Before/after: `PolicyEvaluation` invariant `NO_DUPLICATE_ACCRUAL` fails on the second row, `invoice_status = DUPLICATE_SUSPECTED`, result `BLOCK`, `status = HOLD_DO_NOT_POST`, E003 notified. No second GL entry, no accrual change. `NEW_NUMBER` reaches the same result because `VAL-DUP-INVOICE` matches on PO + amount + service period, not on invoice number.

### 2.8 `CTL-TERMINATE`

ScenarioOverride (worked example, V005 NONE -> 2026-12-15):
```json
{"override_id":"OVR-0008","control_id":"CTL-TERMINATE","validator":"VAL-TERMINATE",
 "target":{"kind":"TERMINATION_NOTICE","doc_id":"TN-005","vendor_id":"V005","contract_id":"CTR-005"},
 "param":{"termination_effective":"2026-12-15"},"baseline_param":{"termination_effective":"NONE"},
 "visible_doc_changed":"contracts/notices/TN-005.txt",
 "hidden_records_rederived":["INV-V005-008-FINAL","INV-V005-009"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"0d4b6a2f8871"}
```
World parameters changed: a new termination notice document `TN-005` is created, `effective_date = 2026-12-15`, filed by the owner E011 with a 30-day notice citation matching the TN-019 pattern.
Arithmetic (final prorated fee): `CTR-005` December fee `$6,400.00`; December has 31 days; days served `1..15 = 15` days. `6400.00 x 15 / 31 = 3096.774...`, half-up to 2 decimals `= 3096.77`.
Derived visible files: `contracts/notices/TN-005.txt` created (new doc, effective line `2026-12-15`); `contracts/index.json` gains one `TERMINATION_NOTICE` row; `evidence/service_activity.csv` V005's `last_activity_date` set to `2026-12-15`, `service_status` `PARTIAL`.
Hidden events/truth re-derived: `INV-V005-008` (December, previously `$6,400.00`) re-derived to `$3,096.77` service `2026-12-01..2026-12-15`; `INV-V005-009` (January, previously `$6,400.00`) deleted from `events.jsonl`; `obligations_truth.csv` `OBL-V005-2026-12` `method` `FIXED_CONTRACT_FEE`->`PRORATED_FEE`, `true_expense` `6400.00`->`3096.77`; `OBL-V005-2027-01` `outcome` `NO_ACCRUAL_DOCUMENTED`, `true_expense` `0.00`.
Before/after: v1.0 books `PRORATED_FEE $3,096.77` for December (contract term and prorated-days basis are both pre-cutoff visible), approval `NONE` (below $10,000.00 with confidence >= 0.85, the same route as Beacon's $1,838.71 proration). January: no invoice expected, classification `NO_INVOICE_SERVICE_NOT_RECEIVED`, cites `TN-005`, outcome `NO_ACCRUAL_DOCUMENTED`.

### 2.9 `CTL-CADENCE`

ScenarioOverride (worked example, V014 QUARTERLY_ARREARS -> MONTHLY_ARREARS):
```json
{"override_id":"OVR-0009","control_id":"CTL-CADENCE","validator":"VAL-CADENCE",
 "target":{"kind":"CONTRACT_CLAUSE","doc_id":"CTR-014","vendor_id":"V014","contract_id":"CTR-014"},
 "param":{"billing_cadence":"MONTHLY_ARREARS"},"baseline_param":{"billing_cadence":"QUARTERLY_ARREARS"},
 "visible_doc_changed":"contracts/CTR-014.txt",
 "hidden_records_rederived":["INV-V014-003-NOV","INV-V014-003-DEC","INV-V014-003-JAN"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"79f13cd0e4a6"}
```
World parameters changed: `billing_cadence` clause text in `CTR-014.txt` (`ANNUAL_FEE = 12 x $4,500.00 = $54,000.00` held constant, per VAL-CADENCE).
Arithmetic: quarterly invoice was `3 x $4,500.00 = $13,500.00` in one document; monthly cadence gives three invoices of `$54,000.00 / 12 = $4,500.00` each, same figure the vendor table already lists ("typical monthly $4,500"), so no rate changes, only the invoicing pattern.
Derived visible files: `contracts/CTR-014.txt` billing clause paragraph replaced; the single quarterly invoice (`INV-V014-003`, `$13,500.00`, `service 2026-11-01..2027-01-31`, `release_at 2027-02-08`) is replaced in `events.jsonl` by three monthly invoices `$4,500.00` each, service periods `2026-11-01..2026-11-30`, `2026-12-01..2026-12-31`, `2027-01-01..2027-01-31`, released on the 8th of the following month at 09:00, the lag the baseline quarterly invoice already uses (`INV-V014-003` releases `2027-02-08T09:00:00`): `2026-12-08`, `2027-01-08`, `2027-02-08`.
Hidden events/truth re-derived: `obligations_truth.csv` `OBL-V014-2026-11`, `OBL-V014-2026-12`, `OBL-V014-2027-01` each keep `true_expense 4500.00`; `actual_invoice_ids` changes from the one shared `INV-V014-003` to one invoice id per period; `invoice_received_dates` changes from the single quarterly date to three separate dates.
Before/after: v1.0 already accrues `$4,500.00` FIXED_CONTRACT_FEE per month under quarterly cadence (case C02). Under monthly cadence the accrual amount and approval (`NONE`, confidence >= 0.85) are unchanged; only the invoice-matching pattern changes from a single three-way split (`InvoiceMatch` rows with `allocated_amount`) to three one-to-one matches.

## 3. Consistency invariants checked after every mutation

`POST /sim/overrides/apply` runs these checks, in order, against the rebuilt world before it is written to `runtime/visible/`. Any failure rejects the apply, leaves the world unchanged, and returns the failing invariant name to `#lab-panel`.

| # | Invariant | Check |
|---|---|---|
| INV-1 | GL balanced | For every regenerated `entry_id`, sum of `debit` == sum of `credit` across its lines; total debits == total credits across `gl_entries.csv`. |
| INV-2 | Invoice equals pricing function | For every hidden invoice tied to a mutated contract, `amount` == the contract's pricing function evaluated at that invoice's `service_period_start`, to the cent. |
| INV-3 | Effective date inside term | Any `effective_date` or `termination_effective` parameter satisfies `term_start <= date <= term_end` from `ContractFeatures`; `CTL-TERMINATE` additionally requires `date >= 2026-12-01` (no edit to a CLOSED period). |
| INV-4 | Cadence tiles without gap or overlap | `CTL-CADENCE` and the date half of `CTL-ESCALATOR-DATE`: consecutive service periods for one vendor have no gap day and no overlap day across the full contract term. |
| INV-5 | Duplicate keeps its key | `CTL-DUP-INVOICE` output has the same `po_id`, `amount` and service period as the source row, a distinct `invoice_id`, and exactly one `goods_receipts.csv` row (unchanged). |
| INV-6 | No leaked future fact | L1 of `WORLD_SPEC.md` 3.7 re-run against the rebuilt `runtime/visible/`: no checked date field exceeds the current clock; the mutated amount does not appear in any visible file before its own event's `release_at`. |
| INV-7 | Truth re-derived, never edited | `obligations_truth.csv`, `future_invoices.csv` and `expected_matches.csv` are fully regenerated from `world.py` given the new parameters; the applier never writes to these files directly, and a diff of the regeneration touches only rows whose `obligation_key` depends on the mutated `vendor_id`/`contract_id`. |
| INV-8 | Policy scope untouched | The mutation never edits `policies.json`, `trueup_playbook.db`, or any `POL-000N` record; only world facts change. |
| INV-9 | One override, one log line | `runtime/mutation_log.jsonl` gains exactly one `MUT-000N` row per apply, `sim_state.json.overrides` holds the same `override_id`; a second apply without `allow_multi=true` is rejected before any file write. |
| INV-10 | Budget | Stage returns in under 300ms; apply (regeneration plus INV-1..INV-9) completes in under 2 seconds, per `00-decisions.md` 1.4. |
