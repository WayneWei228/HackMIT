# 03 Playbook Memory and API

Scope per `00-decisions.md` section 6: playbook memory, policy lifecycle, replay, Approve/Reject semantics, Frozen vs Learned runner, the full API surface (sim and trueup), the evidence-trail SSE stream, backend delta and build checklist. Binding on ids, enums, table and column names in `00-decisions.md` section 5 and `WORLD_SPEC.md` sections 2.3-2.6 and 4.6.

## 1. SQLite DDL

`trueup_playbook.db`, survives Reset World, dropped and re-seeded at version 1.0 only by Reset Demo.

```sql
CREATE TABLE playbook_versions (
  version         TEXT PRIMARY KEY,                 -- '1.0', '1.1'
  parent_version  TEXT REFERENCES playbook_versions(version),
  status          TEXT NOT NULL CHECK (status IN ('FROZEN','PROVISIONAL','ACTIVE')),
  created_at      TEXT NOT NULL,
  activated_at    TEXT,
  policies_json   TEXT NOT NULL,                    -- JSON array of policy_id in force at this version
  fixture_hash    TEXT NOT NULL                     -- fixture_hash this version was built/replayed against
);

CREATE TABLE policies (
  policy_id                       TEXT PRIMARY KEY,          -- 'POL-0001'
  policy_type                     TEXT NOT NULL,
  trigger                         TEXT NOT NULL,
  scope_json                      TEXT NOT NULL,             -- 1.7 whitelist fields only
  required_evidence_json          TEXT NOT NULL,
  before_action                   TEXT NOT NULL,
  verifier_result_if_missing_json TEXT NOT NULL,
  outreach_if_missing_json        TEXT NOT NULL,
  behavior_change                 TEXT NOT NULL,
  autonomy_limit                  TEXT NOT NULL,
  derived_from_json               TEXT NOT NULL,             -- {outcome_id, root_cause_id}
  status                          TEXT NOT NULL CHECK (status IN
                                     ('CANDIDATE','BLOCKED','ACTIVE_PROVISIONAL','ACTIVE','REJECTED','REVOKED')),
  created_at                      TEXT NOT NULL,
  policy_version_target           TEXT NOT NULL REFERENCES playbook_versions(version)
);

CREATE TABLE policy_events (
  event_id     TEXT PRIMARY KEY,               -- 'PEV-0001'
  policy_id    TEXT NOT NULL REFERENCES policies(policy_id),
  event_type   TEXT NOT NULL CHECK (event_type IN
                  ('CANDIDATE_CREATED','GUARD_G1_BLOCKED','REPLAY_RUN','GUARD_G2_BLOCKED',
                   'POLICY_APPROVED','POLICY_REJECTED','POLICY_PROMOTED','POLICY_REVOKED')),
  actor        TEXT NOT NULL,                  -- employee_id or 'SYSTEM'
  decided_at   TEXT NOT NULL,
  from_status  TEXT,
  to_status    TEXT NOT NULL,
  comment      TEXT,
  replay_id    TEXT REFERENCES replay_reports(replay_id)
);

CREATE TABLE replay_reports (
  replay_id                       TEXT PRIMARY KEY,        -- 'RPL-POL-0001'
  policy_id                       TEXT NOT NULL REFERENCES policies(policy_id),
  run_at                          TEXT NOT NULL,
  periods_json                    TEXT NOT NULL,           -- ["2026-11","2026-12"]
  obligations_replayed            INTEGER NOT NULL,
  improved                        INTEGER NOT NULL,
  regressed                       INTEGER NOT NULL,
  unchanged                       INTEGER NOT NULL,
  extra_outreach                  INTEGER NOT NULL,
  extra_reviews                   INTEGER NOT NULL,
  abs_error_before                REAL NOT NULL,
  abs_error_after                 REAL NOT NULL,
  touched_json                    TEXT NOT NULL,           -- [{obligation_key, before, after, result}]
  feature_matched_json            TEXT NOT NULL,
  compared_on_action_only_json    TEXT NOT NULL,
  forward_scope_preview_json      TEXT NOT NULL,
  recommendation                  TEXT NOT NULL CHECK (recommendation IN ('APPROVE_PROVISIONAL','REJECT'))
);
```

`trueup_state.db`, wiped by both Reset World and Reset Demo:

```sql
CREATE TABLE demo_state (
  id                       INTEGER PRIMARY KEY CHECK (id = 1),  -- singleton row
  state                    TEXT NOT NULL,        -- one of the 00-decisions section 3 UPPER_SNAKE states
  scenario_id              TEXT,                 -- 'SCN-A' | 'SCN-B' | 'SCN-C' | NULL
  clock                    TEXT NOT NULL,         -- mirror of sim clock, refreshed on every /api call
  world_hash               TEXT NOT NULL,
  fixture_hash             TEXT NOT NULL,
  playbook_version_loaded  TEXT NOT NULL,         -- app-enforced pointer into trueup_playbook.db.playbook_versions
                                                   -- (no cross-file FK: separate SQLite files)
  run_mode                 TEXT NOT NULL CHECK (run_mode IN ('LIVE','RECORDED')),
  active_override_id       TEXT,
  updated_at               TEXT NOT NULL
);
```

`demo_state` is a single-row table (id=1), upserted, never appended; every state transition in the section-3 machine is one `UPDATE`. `playbook_version_loaded` is written by the close-run loader in section 2 below, not by the UI.

## 2. Typed policy record, in full

`POL-0001`, literal, per `WORLD_SPEC.md` 4.6, unchanged here:

```json
{"policy_id":"POL-0001","policy_type":"VERIFY_EFFECTIVE_CONTRACT_PRICE","trigger":"RECURRING_VENDOR_ACCRUAL",
 "scope":{"estimator_method":"FIXED_CONTRACT_FEE","contract_features":{"has_scheduled_price_change":true,"pricing_structure_in":["SCHEDULED_STEP","ANNIVERSARY_ESCALATOR","VENDOR_NOTIFIED_UPLIFT"]}},
 "required_evidence":[{"evidence_key":"pricing_schedule_effective","must_cover":"service_period","accepted_sources":["PRICING_SCHEDULE","CONTRACT_ESCALATOR_CLAUSE","VENDOR_NOTICE"]}],
 "before_action":"CREATE_DRAFT_ACCRUAL",
 "verifier_result_if_missing":{"in_repository_not_attached":"BLOCK","not_in_repository":"OUTREACH_REQUIRED","no_reply_at_cutoff":"ESCALATE"},
 "outreach_if_missing":{"target_role":"VENDOR_BILLING","missing_fact":"SCOPE_OR_RATE_CHANGE","fallback_target_role":"OPERATIONAL_OWNER"},
 "behavior_change":"retrieve_and_validate_current_rate_before_estimation",
 "autonomy_limit":"controller_review_if_material",
 "derived_from":{"outcome_id":"TU-V001-2026-12","root_cause_id":"VE-V001-2026-12"},
 "status":"CANDIDATE","created_at":"2027-01-13T09:30:00","policy_version_target":"1.1"}
```

The `scope` object may reference only `estimator_method` and the `contract_features.*` keys in the section 1.7 whitelist. No `vendor_id`, vendor name, `contract_id` or `category` appears anywhere in the record; this is a hard field-level check, not a review convention (see G1 below).

## 3. Loading and enforcing the active playbook

Every `POST /api/close/run` starts with a loader, run before any LLM call:

1. `SELECT version FROM playbook_versions WHERE status IN ('ACTIVE','PROVISIONAL') ORDER BY activated_at DESC LIMIT 1` (falls back to `'1.0'` FROZEN if no row). Ties broken by highest semantic version.
2. `SELECT policies_json FROM playbook_versions WHERE version = ?` gives the policy id list; `SELECT * FROM policies WHERE policy_id IN (...) AND status IN ('ACTIVE','ACTIVE_PROVISIONAL')` loads the typed records.
3. The loader writes `demo_state.playbook_version_loaded` and returns a `PolicySet` object: the base `policies.json` rules (section 1.5/2.2 of WORLD_SPEC) plus zero or more typed policy records.
4. The `PolicySet` is handed only to the deterministic verifier (the code that produces `PolicyEvaluation`, invariants `ALLOWED_METHOD`, `EVIDENCE_TRACE_COMPLETE`, `NO_SILENT_POLICY_WEAKENING`). It is never serialized into an LLM system or user message.
5. The LLM (evidence/estimation agent) sees only `ContractFeatures`, the obligation's evidence records and the tool catalogue. It proposes an `ActionProposal` with `calculation_method`, `amount`, `evidence_ids`. It does not see policy predicates and cannot special-case a vendor because no policy text ever enters its context.
6. The verifier evaluates the proposal against the loaded `PolicySet` in code. Each `checks[]` row's `source` field is `"BASE"` or a `policy_id` (e.g. `"POL-0001"`), so the workpaper can show exactly which rule fired, as in `WORLD_SPEC.md` 2.5's `PE-V018-2027-01-01` example (`source: "POL-0001"`).

This is why C04/C12 "transfer" without vendor memorization: the verifier, not the model, applies `has_scheduled_price_change = true` to any `ContractFeatures` row, and the loader step above runs identically for V001 and V018.

## 4. Candidate gate

`POST /api/policy/candidate` runs guard **G1** synchronously before returning:

- Walk `scope.contract_features` keys and `scope.estimator_method`; every key must be in the section 1.7 whitelist (`contract_type`, `pricing_structure`, `billing_cadence`, `has_scheduled_price_change`, `has_pricing_exhibit`, `has_usage_component`, `termination_notice_on_file`, `auto_renews`, `notice_days`, plus `estimator_method` itself).
- Reject any predicate value that is a post-cutoff fact (`invoice_id`, `true_up_amount`, `actual_invoice_total`, `root_cause`) or a banned identifier (`vendor_id`, vendor name, `contract_id`, `category`, `cost_center`, `po_id`).
- All pre-close feature fields fail closed: an unrecognized key is a G1 failure, not a pass-through.

G1 fail: `policies.status = 'BLOCKED'`, `demo_state.state = 'CANDIDATE_BLOCKED'`, `policy_events` row `GUARD_G1_BLOCKED` with `comment` naming the offending field. `btn-run-replay` and `btn-approve-policy` are not reachable; only Reject or Reset are.
G1 pass: `policies.status` stays `'CANDIDATE'`, `demo_state.state = 'CANDIDATE_READY'`, `policy_events` row `CANDIDATE_CREATED`.

`POST /api/policy/replay` runs guard **G2** after computing the `replay_reports` row (procedure in `WORLD_SPEC.md` 4.6.4: rebuild each prior obligation's visible snapshot from `2026-11-cutoff`/`2026-12-cutoff`, run the pipeline under 1.0 and under 1.0+candidate, compare to confirmed outcomes):

- Fail if `regressed > 0` or `abs_error_after >= abs_error_before`.
- Fail if any `touched` row's `approval_level_after` is a lower approval level than `approval_level_before` (no silent weakening).
- Pass sets `recommendation = 'APPROVE_PROVISIONAL'`; fail sets `recommendation = 'REJECT'`.

G2 fail: `demo_state.state = 'CANDIDATE_BLOCKED'`, `policy_events` row `GUARD_G2_BLOCKED`. G2 pass: `demo_state.state = 'REPLAY_REPORT_READY'`, `policy_events` row `REPLAY_RUN`.

**Replay report contents**, shown in `#learning-panel`: `obligations_replayed` (35, all 2026-11 and 2026-12), `feature_matched` (obligations whose `ContractFeatures` satisfy `scope`), `not_triggered` (with reason, e.g. invoice already on hand pre-cutoff so no estimate ran), `touched` (one row per obligation whose action changed, each with `before`/`after` amount, price evidence and `abs_error`), `improved`/`regressed`/`unchanged` counts, `compared_on_action_only` (obligations with no confirmed actual yet), `extra_outreach`/`extra_reviews` (0 required), `abs_error_before`/`abs_error_after`, `forward_scope_preview` (open next-period obligations whose features match `scope`, ids only, no amounts). Signed bias before/after is not a stored column; the UI computes `sum(after.amount - before.amount)` over `touched` on read, which for POL-0001 is `+2,500.00 -> 0.00` (bias eliminated, not just averaged out), and prints it next to `abs_error_before`/`abs_error_after`.

## 5. Approve / Reject

`POST /api/policy/approve`. Precondition: `demo_state.state = 'REPLAY_REPORT_READY'`, actor `E001`, `policies.status = 'CANDIDATE'`, the linked `replay_reports.recommendation = 'APPROVE_PROVISIONAL'`.
1. `UPDATE policies SET status = 'ACTIVE_PROVISIONAL' WHERE policy_id = ?`.
2. `INSERT INTO playbook_versions(version, parent_version, status, created_at, activated_at, policies_json, fixture_hash) VALUES ('1.1','1.0','PROVISIONAL', now, now, '["POL-0001"]', :fixture_hash)`. The policy list is the parent's list plus the newly approved id; nothing else changes (`WORLD_SPEC.md` 1.5: "Version 1.1 = version 1.0 plus POL-0001").
3. `INSERT INTO policy_events(...) VALUES (..., 'POLICY_APPROVED', 'E001', now, 'CANDIDATE', 'ACTIVE_PROVISIONAL', comment, replay_id)`.
4. `demo_state.state = 'POLICY_APPROVED'`; `demo_state.playbook_version_loaded` is refreshed to `'1.1'` on the next close-run loader call, not retroactively rewritten on old runs.

`POST /api/policy/reject`. Precondition: `demo_state.state IN ('REPLAY_REPORT_READY','CANDIDATE_BLOCKED')`. Body carries `{"reason": "..."}` (free text, required, min 10 chars).
1. `UPDATE policies SET status = 'REJECTED' WHERE policy_id = ?`.
2. `INSERT INTO policy_events(...) VALUES (..., 'POLICY_REJECTED', :actor, now, :prior_status, 'REJECTED', :reason, :replay_id_or_null)`.
3. No row is written to `playbook_versions`. The active playbook stays `'1.0'` `FROZEN`.
4. `demo_state.state = 'POLICY_REJECTED'`.

**Rejected path proof.** Because step 3 above never creates version `1.1`, the loader in section 3 keeps returning `'1.0'` for every later run, on both the "Frozen" and "Learned" labels. `POST /api/transfer/run` after a reject pins both arms to `'1.0'`; `GET /api/transfer/compare` returns identical `amount`, `approval_level` and `estimator_method` for both columns and the panel prints `Learned == Frozen (policy rejected 2027-01-15, reason: "<reason>")` instead of a predicate-match line. This is the same code path as an approved-then-unused policy, not a special case: the diff is genuinely empty because both arms loaded the same `playbook_versions` row.

## 6. Frozen vs Learned runner

`POST /api/transfer/run`. Precondition: `demo_state.state IN ('POLICY_APPROVED','POLICY_REJECTED','NO_MISS')` and sim clock `>= 2027-02-01T00:00:00`.
1. Both arms start from the same `sim.fork('2027-01-open', dest)` snapshot (`WORLD_SPEC.md` 3.7 L4): identical `runtime/visible/` bytes, identical `sim_state.json`.
2. Arm `FROZEN` pins `playbook_version = '1.0'` for the whole run regardless of what is active in `trueup_playbook.db`.
3. Arm `LEARNED` pins `playbook_version` to whatever `SELECT version FROM playbook_versions WHERE status IN ('ACTIVE','PROVISIONAL') ORDER BY activated_at DESC LIMIT 1` returns at call time (`'1.1'` if approved, `'1.0'` if rejected).
4. Each arm runs `POST /api/close/run` internally against its own fork and its pinned version (no live re-vote of the loader), then advances its own fork to `2027-02-12T09:00:00`, which releases `INV-V018-001` in that fork only, and runs the deterministic match and tolerance test of `02-state-machine-and-time.md` section 4. The shared demo clock is unaffected; `demo_state.clock` on entry to `TRANSFER_COMPARED` is `2027-02-12T09:00:00`.
5. A `TransferResult` diff record is written per obligation: `{"obligation_id","frozen":{"amount","approval_level","estimator_method","policies_applied"},"learned":{...},"delta":"frozen.amount - learned... == 0 ? 'IDENTICAL' : 'DIFFERENT'","predicate_match":{"has_scheduled_price_change":true,"pricing_structure":"SCHEDULED_STEP","matched_policy_id":"POL-0001"} }`.

`GET /api/transfer/compare` returns the array of `TransferResult` rows plus the literal POL-0001 record (from section 2) so the panel can show "no vendor identifier anywhere in this record" next to the diff, matching `WORLD_SPEC.md` SCN-B.

## 7. API

Error code legend, used by every endpoint below: `400 VALIDATION_ERROR` malformed body or unknown enum; `404 NOT_FOUND` unknown id; `409 STATE_CONFLICT` `demo_state.state` does not allow this call per the section-3 transition table; `422 GUARD_FAILED` G1 or G2 rejected; `423 WORLD_LOCKED` a second override staged without `allow_multi=true`; `502 SIM_UNREACHABLE` the `trueup` to `sim` proxy call failed; `500 LIVE_MODEL_ERROR` the agent call failed, `demo_state.state -> 'ESCALATED'`, no recorded fallback is substituted (`00-decisions.md` section 5, "Live-LLM risk").

### Simulator, base `/sim`

| Endpoint | Precondition | Request | Response (key fields) | Errors |
|---|---|---|---|---|
| `GET /sim/health` | none | - | `{"status":"ok","build":"..."}` | - |
| `GET /sim/controls` | none | - | control catalogue rows, section 2 of `00-decisions.md` | - |
| `POST /sim/overrides/stage` | no staged override, or `allow_multi=true` | `{"control_id":"CTL-ESCALATOR-PCT","vendor_id":"V001","param":{"escalator_pct":5.0}}` | `{"override_id":"OVR-0001","visible_doc_diff":{...},"validator":"VAL-ESCALATOR-PCT","valid":true}` | 400, 423 |
| `POST /sim/overrides/apply` | one staged override exists | `{"override_id":"OVR-0001"}` | `{"world_hash":"9f2c41ab77d0","runtime_reset":true,"clock":"2027-01-04T09:00:00"}` | 404, 400 |
| `GET /sim/overrides` | none | - | `[ScenarioOverride, ...]` | - |
| `DELETE /sim/overrides` | none | - | `{"cleared":1}` | - |
| `GET /sim/clock` | none | - | `{"clock":"...","periods":[{"period":"2026-12","status":"OPEN"}]}` | - |
| `POST /sim/advance` | target `> clock` | `{"to":"2027-01-12T09:00:00"}` | `{"clock":"2027-01-12T09:00:00","released":["INV-V001-008"]}` | 400 (`ClockRegressionError`) |
| `POST /sim/outreach` | obligation exists | `{"obligation_id":"OBL-V001-2026-12","target_role":"VENDOR_BILLING","missing_fact":"INVOICE_WHEREABOUTS"}` | `{"outreach_id":"OUT-V001-2026-12-01","accepted":true}` | 404 |
| `POST /sim/snapshot` | none | `{"label":"2026-12-cutoff"}` | `{"label":"2026-12-cutoff","stored":true}` | - |
| `POST /sim/fork` | snapshot exists | `{"label":"2027-01-open","dest":"learned-run-1"}` | `{"dest":"learned-run-1","world_hash":"..."}` | 404 |
| `GET /sim/hash` | none | - | `{"world_hash":"...","fixture_hash":"...","baseline_fixture_hash":"..."}` | - |
| `POST /sim/reset/world` | none | - | `{"clock":"2027-01-04T09:00:00","world_hash":"..."}` | - |
| `POST /sim/reset/demo` | none | - | `{"clock":"2027-01-04T09:00:00","fixture_hash_matches_baseline":true}` | 500 if hash mismatch after rebuild |

### TrueUp, base `/api`

| Endpoint | Precondition | Request | Response (key fields) | Errors |
|---|---|---|---|---|
| `GET /api/state` | none | - | `{"state":"...","clock":"...","playbook_version":"1.0","world_hash":"...","mode":"LIVE"}` | - |
| `GET /api/obligations` | none | `?period=2026-12` | `[VendorObligation summary, ...]` | 400 |
| `GET /api/obligations/{obligation_id}` | obligation exists | - | full VendorObligation + evidence + verifier checklist | 404 |
| `POST /api/close/run` | `state IN ('IDLE_BASELINE','MUTATION_APPLIED')`, period OPEN | `{"period":"2026-12"}` | `{"run_id":"RUN-0001","state":"CLOSE_RUNNING"}` (async; poll `/api/state`) | 409, 500 |
| `POST /api/accrual/approve` | `state = 'CLOSE_AWAITING_APPROVAL'`, actor matches `required_approval_level` | `{"obligation_id":"OBL-V001-2026-12","actor":"E001"}` | `{"accrual_entry_id":"JE-ACR-V001-2026-12","state":"CLOSE_POSTED"}` | 409, 403 (wrong actor) |
| `POST /api/trueup/run` | `state = 'CLOSE_POSTED'`, invoice now visible | `{"obligation_id":"OBL-V001-2026-12"}` | `{"true_up_amount":2500.00,"within_tolerance":false,"state":"TRUEUP_COMPUTED"}` | 409, 404 |
| `POST /api/investigate` | `state = 'TRUEUP_COMPUTED'`, outside tolerance | `{"obligation_id":"OBL-V001-2026-12"}` | `VarianceExplanation` (`root_cause`, `process_cause`, `evidence_existed_at_close`) | 409 |
| `POST /api/policy/candidate` | `state = 'ROOT_CAUSE_FOUND'` | `{"root_cause_id":"VE-V001-2026-12"}` | `POL-0001` record, `state` `'CANDIDATE_READY'` or `'CANDIDATE_BLOCKED'` | 409, 422 (G1) |
| `POST /api/policy/replay` | `state = 'CANDIDATE_READY'` | `{"policy_id":"POL-0001"}` | `replay_reports` row, `state` `'REPLAY_REPORT_READY'` or `'CANDIDATE_BLOCKED'` | 409, 422 (G2) |
| `POST /api/policy/approve` | section 5 | `{"policy_id":"POL-0001","actor":"E001"}` | `{"policy_version":"1.1","status":"ACTIVE_PROVISIONAL","state":"POLICY_APPROVED"}` | 409, 403 |
| `POST /api/policy/reject` | section 5 | `{"policy_id":"POL-0001","actor":"E001","reason":"..."}` | `{"status":"REJECTED","playbook_version_unchanged":"1.0","state":"POLICY_REJECTED"}` | 409, 400 (missing reason) |
| `GET /api/playbook` | none | - | `{"versions":[...],"policies":[...],"events":[...]}` | - |
| `POST /api/transfer/run` | section 6 | `{}` | `{"run_id":"RUN-0003","state":"TRANSFER_RUNNING"}` (learned arm; the frozen arm is `RUN-0004`) | 409 |
| `GET /api/transfer/compare` | `state = 'TRANSFER_COMPARED'` | - | `[TransferResult, ...]` + `POL-0001` | 409 |
| `GET /api/audit/{obligation_id}` | obligation exists | - | audit packet: proposal, evaluation, approval, JEs, true-up, policy trace | 404 |
| `GET /api/evidence-trail` | run exists | `?run_id=RUN-0001` | SSE stream, section 8 | 404 |
| `POST /api/reset/world` | none | - | proxies `/sim/reset/world`, then wipes `trueup_state.db`, keeps `trueup_playbook.db` | 502 |
| `POST /api/reset/demo` | none | - | proxies `/sim/reset/demo`, wipes `trueup_state.db`, re-seeds `trueup_playbook.db` at `'1.0'` | 502, 500 |
| `ANY /api/lab/{path}` | none | byte passthrough | byte passthrough to `sim` | 502 |

## 8. Evidence-trail SSE stream

`GET /api/evidence-trail?run_id=RUN-0001`, `text/event-stream`, one event per tool call plus lifecycle markers, ids `TC-<run suffix>-<seq>`:

```
event: tool_call_start
data: {"tool_call_id":"TC-0001-007","run_id":"RUN-0001","obligation_id":"OBL-V001-2026-12","tool":"open_document","args":{"doc_id":"CTR-001"},"at":"2027-01-04T09:00:12"}

event: tool_call_result
data: {"tool_call_id":"TC-0001-007","result_summary":"CTR-001 Order Form: $50,000.00 per month (Contract Year 1)","evidence_id":"CTR-001"}

event: proposal_created
data: {"proposal_id":"PRP-V001-2026-12-01","amount":50000.00,"calculation_method":"FIXED_CONTRACT_FEE"}

event: verifier_result
data: {"evaluation_id":"PE-V001-2026-12-01","result":"REVIEW_REQUIRED","required_approval_level":"CONTROLLER"}

event: done
data: {"run_id":"RUN-0001","state":"CLOSE_AWAITING_APPROVAL"}
```

Every `tool_call_start`/`tool_call_result` pair is also written to `trueup_state.db.tool_calls` (`AgentRun` FK) so the trail survives a page reload; the stream replays from that table on reconnect instead of losing history.

## 9. Backend delta and build checklist

Delta against the existing generator (`data/gen/`) and `WORLD_SPEC.md`: the generator changes only so that `world.py` pricing functions, `records.py` invoice and PO builders and `events.py` `release_at` values accept `ScenarioOverride` parameters (`01-scenario-lab-and-mutations.md` section 2), plus the one declared departure of `00-decisions.md` section 1 (`PO-1063.authorized_amount = 415000.00` in `records.py`). `truth.py` and `features.py` keep their logic and are re-run, never hand-edited; no truth file is ever written directly. Everything else below is new code in `trueup/` and `sim/`.

| # | Item | Depends on | Hours |
|---|---|---|---|
| 1 | `sim` FastAPI skeleton: `/sim/health`, `/sim/clock`, `/sim/hash`, `reset()`/`advance_to()` wrapping the existing simulator contract (3.6) | generator as-is | 2 |
| 2 | ScenarioOverride: validators (section 2 of `00-decisions.md`), stage/apply endpoints, `world.py` re-run on apply | 1 | 4 |
| 3 | `sim` outreach, snapshot, fork endpoints (3.5, 3.6) | 1 | 2 |
| 4 | `trueup_state.db` schema (obligations through demo_state) and import of seed `gl_entries.csv` | none | 2 |
| 5 | `trueup_playbook.db` schema (section 1) and seed row `version='1.0', status='FROZEN'` | none | 1 |
| 6 | `/api/lab/*` byte-passthrough proxy to `sim` | 1 | 1 |
| 7 | Close pipeline: playbook loader (section 3) + deterministic estimator + verifier producing `PolicyEvaluation` | 4, 5 | 5 |
| 8 | `POST /api/close/run`, `/api/accrual/approve`, `/api/obligations*`, SSE evidence-trail (section 8) | 7 | 4 |
| 9 | `POST /api/trueup/run`, `/api/investigate` (deterministic match + classifier call) | 8 | 3 |
| 10 | Guard G1, `POST /api/policy/candidate` | 5, 9 | 2 |
| 11 | Replay engine (section 4 procedure) + guard G2, `POST /api/policy/replay` | 7, 10 | 4 |
| 12 | `POST /api/policy/approve`, `/api/policy/reject`, `GET /api/playbook` (section 5) | 11 | 2 |
| 13 | Frozen/Learned runner, `POST /api/transfer/run`, `GET /api/transfer/compare` (section 6) | 3, 12 | 3 |
| 14 | `GET /api/audit/{obligation_id}` audit packet | 8, 9 | 1 |
| 15 | `POST /api/reset/world`, `/api/reset/demo` proxy plus DB wipe/reseed | 2, 5 | 1 |
| 16 | Web page: `#clock-bar`, `#lab-panel`, `#diff-panel`, close/workpaper/outreach/true-up panels, `#evidence-trail`, `#learning-panel`, `#transfer-panel`, `#audit-panel` | 6-15 | 8 |
| 17 | Recorded-run capture at `BASELINE_FIXTURE_HASH`, `RECORDED` badge, live-model fallback to `ESCALATED` (`00-decisions.md` section 5, Live-LLM risk) | 8 | 2 |
| 18 | Leakage tests (3.7 L1-L4) run against the live API instead of the offline harness | 1-15 | 3 |

Total 50 hours; with 4 people in parallel (sim track, close-pipeline track, learning track, UI track) this fits a 24-hour build with roughly 12 hours of slack for integration and the cut-order fallback in `00-decisions.md` section 2 (drop `CTL-CADENCE` first) if items 2-3 run long.
