# 05 Weaknesses a Maximor judge will attack, and the smallest fixes

Deliverable 10. Written from the seat of a finance-automation engineer who has watched many "AI accountant" demos and called a cash-only point solution "very meh".
Every attack is aimed at a named line of the existing design. Every fix is a spec edit or under 2 hours of build on top of the 50 hours in `03-playbook-memory-and-api.md` line 268.
Nothing here changes the product spec. W08 is the one place this specification departs from `WORLD_SPEC.md`, and its spec edits are **applied**: `00-decisions.md` section 1 now pins PO-1063 at $415,000.00 as a declared departure, and `02-state-machine-and-time.md` section 5 now carries leakage test LK11. Every other fix below is still open build work.

## 0. Arithmetic, computed once

| Quantity | Working | Result |
|---|---|---|
| SCN-A tolerance | `max(500.00, 0.02 x 50,000.00 = 1,000.00)` | 1,000.00 |
| SCN-A 8% variance | `50,000.00 x 1.08 = 54,000.00`; `54,000.00 - 50,000.00` | 4,000.00 |
| SCN-A 12% variance | `50,000.00 x 1.12 = 56,000.00`; `56,000.00 - 50,000.00` | 6,000.00 |
| Prior-period Controller trigger | `WORLD_SPEC` 1.5 line 130: `>= 25,000.00`; `6,000.00 < 25,000.00` | no approver today |
| V005 frozen error | `6,752.00 - 6,400.00 = 352.00`; tolerance `max(500.00, 0.02 x 6,400.00 = 128.00) = 500.00` | inside tolerance, still wrong |
| PO-1063 back-solve today | `360,000.00 / 12` (`WORLD_SPEC` line 263) | 30,000.00, the held-out answer |
| PO-1063 pinned cap (applied) | `415,000.00 / 12 = 34,583.33`; nearest offered fee 33,000.00, gap `1,583.33 > 500.00` | no back-solve |
| V018 cap check | `12 x 33,000.00 = 396,000.00 <= 415,000.00` | `VAL-PRODUCTION-FEE` passes |
| Replay coverage today | `1 touched / 35 replayed` (`04` line 50) | 2.86% |

## 1. Ranked attacks

| # | Attack, as the judge says it | Hits | Smallest fix | Cost |
|---|---|---|---|---|
| W01 | "You learned one if-statement." | `00` 2 lines 69-75, `04` 2 | Add the V005 row to `#transfer-panel`: same policy, opposite action | 1.5 h |
| W02 | "The LLM is decorative." | `03` 3 steps 4-6 | Ablation card: classifier vs always-guess vs keyword, over 54 obligations | 1.5 h |
| W03 | "This is still scripted." | `01` 1.2, `02` line 106, `04` line 192 | Free numeric escalator entry, plus leakage test LK7 run live on screen | 2 h |
| W04 | "That policy was hand-written." | `03` 2, `00` 1.7 | Model emits 3 candidate scopes, replay ranks them, show all 3 | 2 h |
| W05 | "One improved obligation out of 35 proves nothing." | `04` line 50 | Replay also over `erp/accrual_schedule_prior.csv`, 2026-05 to 2026-10 | 2 h |
| W06 | "Your true-up posts into a closed period and nobody signs it." | `02` 4, `00` line 144 | `out_of_period` flag, route true-up to the accrual's approver, SUD table | 1.5 h |
| W07 | "Approval is a JSON field." | `03` 5, `03` line 209 | Approver picker with role check, `btn-revoke-policy`, promote/revoke monitor | 1.5 h |
| W08 | "The PO states the answer, and you edited the world to hide it." | `00` line 6 vs `WORLD_SPEC` line 263 | Pin PO-1063 at 415,000.00 not-to-exceed, add leakage test LK11 | **spec applied**, 0.5 h build left |
| W09 | "It is a hard-coded accounting workflow." | `WORLD_SPEC` line 137, `03` 3 | Coverage and autonomy panel over all 54 obligations | 1 h |
| W10 | "It will die live, and the fallback throws away my change." | `04` line 158, `02` line 164 | Focus set of 4 obligations, one retry, GPF keeps the judge's world | 2 h |
| W11 | "The Lab is a cage with four buttons in it." | `01` line 56, `00` line 77 | Allow two stacked overrides, print the reachable-world count | 1 h |
| W12 | "Your GL does not tie to the AP subledger by document." | `WORLD_SPEC` line 366, `02` 4 | AP tie-out line in the audit packet | 0.5 h |

Total 17 hours across the four existing tracks. Cut order: W11, W12, W04, W09. W01, W03, W06 and W10 are never cut.

## 2. The attacks in full

### W01. Only one root cause generalises

- **Attack.** "Every control ends in the same place. `CTL-USAGE-SPIKE` is always correct. Duplicate, terminate and cadence are all labelled 'same' in your own table. Surcharge is always UNKNOWN. The only thing this system can ever learn is POL-0001. That is one if-statement with a review screen on it."
- **Why it lands.** `00-decisions.md` lines 69-75 mark five of nine controls "same" or "identical" for the learned agent. `seeded_root_causes.json` (`WORLD_SPEC` line 791) has three root causes and sets `expected_policy_type` to null on two. SCN-B consumes POL-0001 rather than producing anything (`04` line 99).
- **Smallest fix.** Add a second row to `#transfer-panel`: `OBL-V005-2027-01`, PagerLoop, `pricing_structure = VENDOR_NOTIFIED_UPLIFT`, no pricing exhibit on file. Fixture, truth row and the 9-hour scripted reply already exist (`WORLD_SPEC` line 753). The same POL-0001 predicate matches, and with no document the verifier returns `OUTREACH_REQUIRED`, then `ESCALATE` at cutoff. One policy, three actions: attach the exhibit (V018), cite the footnote clause (V004), ask then escalate (V005).
- **Answer.** "One rule, three vendors, three different actions, and on this one the right answer is to stop and ask rather than book a number."

### W02. The LLM is decorative

- **Attack.** "Your estimator is code, your verifier is code, your matcher is code, your replay is code, and the policy never enters the model context. Delete the model, hard-code `SCHEDULED_PRICE_CHANGE`, and the demo is identical."
- **Why it lands.** `03` section 3 steps 4 to 6 state that the `PolicySet` goes only to the deterministic verifier and that the LLM sees features, evidence and the tool catalogue. In SCN-A the model makes one enum choice from seven values (`WORLD_SPEC` line 343).
- **Smallest fix.** Pre-compute an ablation card for `#audit-panel` from the existing rubric in `WORLD_SPEC` 4.2. Three columns over all 54 obligations: LLM classifier, always-`SCHEDULED_PRICE_CHANGE`, keyword match on the invoice line. Report root-cause accuracy and unnecessary-review rate for each, plus mean tool calls per obligation, frozen 1 (`04` line 84) against learned 7 (`04` lines 76-82, seven trail rows). Run once pre-demo, store the JSON, render it.
- **Answer.** "The model does retrieval and diagnosis, here is the number that says it beats both cheap baselines, and every dollar stays deterministic on purpose because a Controller cannot sign a figure a model invented."

### W03. This is still scripted

- **Attack.** "You gave me four radio buttons on three vendors, your clock jumps to timestamps you hard-coded, and your sixty-second variant literally says 'result pre-warmed'. I picked from your menu."
- **Why it lands.** `01` line 42 is a radio group. `02` line 106 fixes `target_ts` per state and forbids free text. `04` line 192 says pre-warmed. `00` line 267 keeps a recorded run for the baseline hash.
- **Smallest fix.** Two edits. (a) `CTL-ESCALATOR-PCT` on V001 becomes a number input, integer 0 to 25, validated by `VAL-ESCALATOR-PCT`; the four values stay as preset chips for the sixty-second variant only. (b) After `btn-apply-mutation`, run leakage test LK7 (`02` line 236) live against the rebuilt world and print the result in `#diff-panel`: the searched string, the file count scanned, and "found only in `contracts/pricing_schedules/PS-001.txt`". Keep the fixed `target_ts` and label it in the UI as a leakage control, not a script.
- **Answer.** "Type any escalator you like; the number you just typed exists in exactly one file in this company right now, and the agent has not opened it yet."

### W04. The policy is a hand-written rule in disguise

- **Attack.** "POL-0001 is printed verbatim in your spec with a fixed `created_at`. And your two predicates are one predicate: `has_scheduled_price_change` is true if and only if `pricing_structure` is one of those three values. A model deriving that from evidence would not write it twice."
- **Why it lands.** `03` lines 95 to 108 carry the literal record. `WORLD_SPEC` line 370 defines the biconditional. The whitelist is nine fields (`00` line 58), so the search space the model supposedly explored is small and visible.
- **Smallest fix.** `POST /api/policy/candidate` asks the model for three candidate scopes: the exact one, a broader one with `pricing_structure_in` dropped, a narrower one with `has_pricing_exhibit = true` added. Run G1 and the existing replay engine on all three. `#learning-panel` shows three rows with `improved`, `regressed` and `forward_scope_preview` size, chosen row highlighted. The narrow scope drops `OBL-V005-2027-01` from preview, which is the visible reason it loses.
- **Answer.** "It wrote three rules and the replay chose one; here is the one it rejected for being too narrow and the one it rejected for firing on vendors it should not touch."

### W05. Replay on a tiny history proves nothing

- **Attack.** "Thirty-five obligations, one touched, thirty-four unchanged, four not even comparable. Your regression test is n equals one against a world your own generator produced. Of course it improves."
- **Why it lands.** `04` line 50 and `WORLD_SPEC` line 846 give improved 1, regressed 0, unchanged 34. `compared_on_action_only` holds four rows with no actual yet (`WORLD_SPEC` line 838). That is 2.86% of the replay set moving.
- **Smallest fix.** Extend the replay set with `erp/accrual_schedule_prior.csv`, the human team's 2026-05 to 2026-10 rollforward, which already carries `accrued`, `actual` and `variance` per vendor-month, prepared by E004 and reviewed by E002. No new fixture. The replay report prints two denominators: TrueUp obligations (35) and human-prepared prior accruals (count computed at run time), each with feature-matched, would-have-changed and regressed counts. DataForge has no rows there, so the honest headline is "no regression against the accruals a human team actually signed".
- **Answer.** "It replayed against every accrual this close team posted in the last six months, not only against its own."

### W06. Accounting correctness: reversal, true-up posting, cutoff, materiality

- **Attack.** "December closed at 2027-01-05T23:59:59. On 2027-01-12 you post four thousand dollars of December expense into January and nobody approves it. Where is the out-of-period disclosure, and where is the summary of unadjusted differences my auditor asks for?"
- **Why it lands.** `02` lines 189 to 192 date `JE-TRU-` at the invoice `received_date` with no approval step, and `00` line 144 states the convention and stops. At 12% the variance is 6,000.00, below the 25,000.00 prior-period Controller trigger in `WORLD_SPEC` line 130, so nothing routes to a human at all.
- **Smallest fix.** Three additions, all in the workpaper and audit packet. (a) `TrueUpAdjustment` gains `out_of_period: true` plus a rendered line: "prior-period adjustment; 2026-12 expense understated 4,000.00; recorded in 2027-01 because 2026-12 closed 2027-01-05T23:59:59". (b) Any true-up outside tolerance routes to the approver of its own accrual, E001 here, regardless of the 25,000.00 threshold. (c) `#audit-panel` gains a Summary of Unadjusted Differences table: every out-of-period true-up in the period, signed, with a total. The reversal `JE-REV-V001-2026-12` dated 2027-01-01 is already correct and unchanged.
- **Answer.** "The miss lands in January as a prior-period adjustment, it goes back to the same Controller who signed the accrual, and it sits on the unadjusted-differences schedule with everything else."

### W07. Why would a Controller trust this

- **Attack.** "Your approve call takes `actor: E001` in the request body. I can approve as your Controller with curl. The policy goes ACTIVE_PROVISIONAL and nothing ever promotes or revokes it. That is a button, not a control."
- **Why it lands.** `03` section 5 and line 209 check only that a string equals `E001`. `WORLD_SPEC` line 865 says POL-0001 moves to ACTIVE after the January true-ups, and nothing in `00` to `04` implements or shows that step. `REVOKED` exists in the enum (`00` line 54) with no path to it.
- **Smallest fix.** (a) `#learning-panel` renders an approver picker seeded from `org_directory.json`; the server returns `403` for any actor whose `role` is not `CONTROLLER`, and stores the name on the `policy_events` row. (b) Add `btn-revoke-policy` and `POST /api/policy/revoke`, writing `POLICY_REVOKED` and moving the active version pointer back to `1.0`. (c) After the transfer run, print the monitor line: in-scope 2027-01 obligations inside tolerance, with the stated rule that 4 of 4 promotes to ACTIVE and any regression revokes.
- **Answer.** "Only a Controller can approve it, it stays provisional until January proves it, and one button puts the company back on version 1.0 with no code change."

### W08. Leakage through the Lab or the PO amount

- **Attack.** "PO-1063 is 360,000, which is twelve times 30,000, which is your held-out answer. The transfer proof is sitting in a document the agent may read. And you noticed, because `00-decisions.md` quietly changes it to 400,000 in a spec that says the world is frozen."
- **Why it lands.** `WORLD_SPEC` line 263 states the problem in its own words and defends it only with "the v1.0 `FIXED_CONTRACT_FEE` estimator never reads PO amounts", which is a blindfold, not a control. The second half of the attack landed on the first draft of `00` line 6, which moved a frozen fixture value to 400,000.00 with no departure note; that is the worse finding of the two, and it is the part now fixed in place.
- **Smallest fix, applied.** Spec edit in `00-decisions.md` section 1, written as a declared departure with its reason: PO-1063 `authorized_amount` becomes 415,000.00, a not-to-exceed that authorises spend and states no price. `415,000.00 / 12 = 34,583.33`, and the nearest offered fee 33,000.00 sits 1,583.33 away, wider than the 500.00 tolerance on any V018 accrual. Leakage test LK11 is in `02-state-machine-and-time.md` section 5: for every offered parameter value of `CTL-ESCALATOR-PCT` and `CTL-ESCALATOR-DATE`, and for every purchase order linked to the affected obligation, `authorized_amount / 12` must differ from the resulting monthly fee by more than that obligation's tolerance. The scope is those two controls because they are the only ones where the price is a fact the agent must retrieve rather than read off the contract it already has. `VAL-PRODUCTION-FEE` now checks `12 x fee <= 415000.00`. Remaining build: 0.5 h to implement LK11.
- **Answer.** "The PO caps spend and states no price, and a test asserts that no PO in this company divides into a price the agent has not earned."

### W09. It is a hard-coded accounting workflow

- **Attack.** "Five estimator methods, twelve invariants, seven root causes. Bring a vendor that fits none of the five and it escalates. You automated the easy eighty percent a spreadsheet macro already does. This is the cash point solution again."
- **Why it lands.** `WORLD_SPEC` line 137 lists exactly five methods with fixed required evidence, and `03` section 3 runs the same seven-step pipeline for every obligation. The long tail escalates by construction, and the demo never quantifies how large it is.
- **Smallest fix.** Stop hiding it and score it. Add a coverage and autonomy panel above `#close-board`, computed from `GET /api/obligations` across all 54 obligations: count and dollars by `required_approval_level` (`NONE`, `REVIEWER`, `CONTROLLER`), count `ESCALATED`, count `NO_ACCRUAL_DOCUMENTED`, share of dollars posted with no human touch, and unsupported autonomous postings (target 0, `WORLD_SPEC` line 898). Give the escalation count the same visual weight as the automation count.
- **Answer.** "Escalation is the product, not the failure mode; the number we optimise is dollars closed with no human and zero unsupported postings, and both are on this screen."

### W10. Latency and live-demo failure

- **Attack.** "You run a whole close live in twelve seconds. When it stalls, your fallback resets the world and replays a recording of your baseline. So the one thing I care about, my own number, is the first thing you throw away."
- **Why it lands.** `04` line 166 gives beat 5 twelve seconds for a 35-obligation close. `04` line 158 resets to `BASELINE_FIXTURE_HASH` and plays a recording. `02` line 164 calls a Reset Demo hash mismatch "not recoverable live".
- **Smallest fix.** (a) `POST /api/close/run` accepts `obligation_ids[]`; the demo path sends a focus set of four, the judge's obligation plus `OBL-V008-2026-12`, `OBL-V012-2026-11` and `OBL-V019-2026-12`, so the live path is four model paths, not thirty-five; the rest are computed deterministically and rendered as one summary row. (b) On a stall past 5 seconds, retry that single obligation once with a 3-second budget before GPF. (c) GPF keeps the judge's world: the fallback runs the deterministic half and shows the classifier step as `ESCALATED`, `reason = AGENT_RUN_FAILED`, which is already a legal state (`02` line 97).
- **Answer.** "If the model does not answer it escalates to the Controller with your number still on the screen, which is exactly what it should do at two in the morning on close night."

### W11. The Lab is a cage

- **Attack.** "One change per run, nine controls, and six of them are on your own cut list. Real close breakage is two things at once: a price step and a late invoice."
- **Why it lands.** `01` line 56 disables the whole panel after Apply unless `allow_multi=true`, and nothing in the demo flow ever sets it. `00` line 77 puts six of the nine controls in the cut order, leaving three guaranteed.
- **Smallest fix.** Allow exactly two stacked overrides when they target different files, and enable it for the realistic pair `CTL-ESCALATOR-PCT` plus `CTL-INVOICE-DELAY`: the price steps and the bill is late. Invariants INV-1 to INV-10 already run against the rebuilt world, so consistency needs no new code. Print the reachable-world count in `#lab-panel`, computed from the control catalogue at load.
- **Answer.** "Stack a price step and a three-week late invoice if you like; the world rebuilds consistent either way, and the panel shows how many distinct companies you can build from it."

### W12. The GL does not tie to the AP subledger

- **Attack.** "One invoice of 52,500 becomes two journal entries, 50,000 and 2,500, with different entry types. My AP subledger holds one document. Your tie-out breaks on day one."
- **Why it lands.** `WORLD_SPEC` line 366 and `02` lines 189 to 192 create `JE-INV-` and `JE-TRU-` separately so the true-up is visible on screen. That is a presentation choice leaking into the ledger model.
- **Smallest fix.** Keep both entries, because the split is what makes the learning signal auditable, and add a tie-out block to `GET /api/audit/{id}`: `invoice_id`, the `ap_queue.csv` row, both entry ids, their sum, and an equality assertion. Render as one line in `#audit-panel`: "INV-V001-008 52,500.00 = JE-INV 50,000.00 + JE-TRU 2,500.00; account 2000 credited 52,500.00 once".
- **Answer.** "Two entries, one document, one credit to Accounts Payable, and the packet proves it on a single line."
