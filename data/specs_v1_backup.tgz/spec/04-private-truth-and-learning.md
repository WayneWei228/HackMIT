## 4. Private simulator truth, learning proof and evaluation

### 4.1 The private layer

`world/private/` is read only by the simulator and by `/evaluate`. TrueUp tools receive the `runtime/visible/` root and nothing else. Nothing under `world/private/truth/` or `world/private/inbox/` is ever copied into `runtime/visible/`; only the payloads of released events, and the files under `world/private/documents/` that those events name, are.

| File | Format | Rows | Purpose |
|---|---|---|---|
| `world/private/truth/obligations_truth.csv` | CSV, JSON-encoded cells where noted | 54 | One row per obligation (vendor x close period). The answer key. |
| `world/private/truth/future_invoices.csv` | CSV | every invoice with `received_date` >= 2026-12-01 | What will arrive and when. Mirrors the `INVOICE_RECEIVED` events. |
| `world/private/truth/expected_matches.csv` | CSV | one row per invoice-obligation link | Correct invoice to obligation matching, with allocated dollars. |
| `world/private/truth/seeded_root_causes.json` | JSON list | 3 | Why each seeded miss happens. Scores root-cause diagnosis. |
| `world/private/truth/extra_exceptions.json` | JSON list | 2 | Exceptions that are not obligations (duplicate, late prior-period invoice). |
| `world/private/truth/learning_proof/` | JSON | 5 files | Expected learning artefacts (4.4) used to check what TrueUp produces. |

Obligation count: 17 existing vendors give 50 rows (V015 has no 2026-11). V019 adds 3 (2026-11, 2026-12, 2027-01). V018 adds 1 (2027-01 only; the pilot months were card spend and never an obligation). Total 54.

### 4.2 `obligations_truth.csv`

Key: `obligation_key` = `OBL-{vendor_id}-{period}`. Money is a decimal with 2 places. Empty string means not applicable.

| # | Column | Type | Values / rule |
|---|---|---|---|
| 1 | `obligation_key` | str, PK | `OBL-V001-2026-12` |
| 2 | `vendor_id` | str | `V001`..`V019` |
| 3 | `vendor_name` | str | |
| 4 | `period` | `YYYY-MM` | `2026-11`, `2026-12`, `2027-01` |
| 5 | `case_id` | str | **new.** `C01`..`C12` or empty. A case may tag several rows (C01 tags all three V008 rows). |
| 6 | `split` | enum | `TRAIN` (only OBL-V001-2026-12), `HELDOUT` (V018, V004, V005 in 2027-01), `HELDOUT_SAME_VENDOR` (OBL-V001-2027-01), `STANDARD` (all others) |
| 7 | `scenario` | str | carried over; new: `PILOT_TO_PRODUCTION_HELDOUT`, `TERMINATION_PRORATION`, `TERMINATED_NO_SERVICE`, `USAGE_TIERED` |
| 8 | `root_cause` | enum | same enum as the obligation field in section 2: `SCHEDULED_PRICE_CHANGE` (replaces `SCHEDULED_ESCALATOR`), `SCOPE_CHANGE` (replaces `CHANGE_ORDER_SEAT_EXPANSION`), `ESTIMATE_JUDGMENT`, or empty |
| 9-10 | `outreach_target`, `outreach_fact` | enum | carried over |
| 11 | `notes` | str | carried over |
| 12 | `classification` | enum | carried over (`NO_INVOICE_SERVICE_RECEIVED`, `VALID_INVOICE_MATCHES`, ...) |
| 13 | `method` | enum | the correct method: `ACTUAL_INVOICE`, `FIXED_CONTRACT_FEE`, `USAGE_X_RATE`, `PRORATED_FEE`, `PO_BASED`, `HISTORICAL_RUN_RATE`, `NONE` |
| 14 | `verifier` | enum | final correct verifier result: `PASS`, `REVIEW_REQUIRED`, `OUTREACH_REQUIRED`, `BLOCK`, `ESCALATE` |
| 15 | `outcome` | enum | `CLOSE_READY`, `ACCRUED_THEN_RECONCILED`, `NO_ACCRUAL_DOCUMENTED`, `ESCALATED` |
| 16 | `invoice_status_at_cutoff` | enum | `RECEIVED`, `MISSING`, `NONE_EXPECTED` |
| 17 | `needs_estimate` | `Y`/`N` | `Y` when column 16 is `MISSING` |
| 18 | `approval_required` | enum | `NONE`, `REVIEWER`, `CONTROLLER`, from `true_expense` against $10,000 / $25,000 |
| 19 | `true_expense` | money | correct expense for the period once all facts are known |
| 20 | `static_rules_estimate` | money | what the frozen v1.0 agent books |
| 21 | `trailing_avg_estimate` | money | mean of `true_expense` for the prior 3 months (fewer if history is shorter) |
| 22 | `policy_enabled_estimate` | money | **new.** what the v1.1 agent books (equals column 20 where POL-0001 does not trigger) |
| 23 | `static_error` | money | column 20 minus column 19 |
| 24-26 | `actual_invoice_ids`, `actual_invoice_total`, `invoice_received_dates` | str; `;`-separated | carried over |
| 27 | `true_contract_features` | JSON | **new.** the correct `ContractFeatures` record (same keys TrueUp extracts) |
| 28 | `expected_safe_actions` | JSON list | **new.** rubric of binary criteria, see below |
| 29 | `frozen_agent_expected` | JSON | **new.** `{method, price_evidence, amount, verifier, approval, outcome, error, criteria_failed[], miss_reason}` |
| 30 | `policy_agent_expected` | JSON | **new.** same keys plus `policies_applied[]`, `outreach[]` |

Scoring rule for amounts: score a row when `needs_estimate = Y` or `outcome = NO_ACCRUAL_DOCUMENTED` (a false accrual is an error against `true_expense` 0.00).

Changes to carried-over values: V002 and V013 rows become `split = STANDARD`, `root_cause` empty, and `static_rules_estimate` = the tiered amount (OBL-V002-2026-12: 43,800.00, error 0.00). The v1.0 `USAGE_X_RATE` estimator is deterministic code that applies the full rate card; the $42,240 base-rate shortcut is a rubric distractor for C05, not the frozen agent's answer. OBL-V003-2026-12 has `root_cause = SCOPE_CHANGE` (renamed from `CHANGE_ORDER_SEAT_EXPANSION`) and keeps its existing numbers, with `split = STANDARD`.

**Rubric criterion.** `{"id": "R05", "kind": "...", "arg": ..., "text": "..."}`. Each criterion is pass/fail. Row score = passed / total. The evaluator reads TrueUp's per-obligation result record: `classification, extracted_features, method, amount, evidence_ids[], verifier_results[] (in order), outreach[] {target_role, missing_fact}, approval_level, approved_by, je {dr, cr, cost_center, amount, entry_date, reversal_date, posted_at}, outcome, status, policies_applied[], matches[] {invoice_id, allocated, variance}, root_cause`.

| `kind` | Passes when |
|---|---|
| `field_eq` | result field equals `arg.value` |
| `features_include` | every key/value in `arg` equals the extracted feature |
| `evidence_cited` | `arg` id is in `evidence_ids[]` |
| `amount_eq` / `amount_ne` | `amount` equals / differs from `arg` within 0.01 |
| `outreach_sent` / `no_outreach` | an outreach with `arg.target_role` + `arg.missing_fact` exists / none exists for `arg.missing_fact` |
| `approval` | `approval_level` equals `arg.level` and `approved_by` equals `arg.by` (when given) |
| `je` | journal entry lines, dates and cost center equal `arg` |
| `no_post_before_approval` | `je.posted_at` is later than the approval timestamp, or no approval is required |
| `match` | `matches[]` holds `arg.invoice_id` with `arg.allocated` and `arg.variance` |
| `consistent` | the amount in the workpaper, the approval request and the journal entry are identical, and no later step contradicts an earlier finding named in `arg` |

Service-activity evidence ids are the `activity_id` of `evidence/service_activity.csv`, `SA-<APPKEY>-<period>` (section 2): `SA-DATAFORGE-2026-12`, `SA-SIGNALSTACK-2027-01`, `SA-BEACON-2026-12`.

### 4.3 Literal truth rows

Scalar columns are shown as JSON for reading; in the CSV they are plain cells. Each rubric lists criteria as id, `kind`, then arg or plain text. The v1.1 agent is expected to pass every criterion; `[v1.0 F]` (or an F in the v1.0 column) marks what the frozen agent fails, and `frozen_agent_expected.criteria_failed` lists the same ids.

**OBL-V001-2026-12 (C03, TRAIN)**
```json
{"obligation_key":"OBL-V001-2026-12","vendor_id":"V001","vendor_name":"DataForge Inc.","period":"2026-12","case_id":"C03","split":"TRAIN","scenario":"ESCALATOR_MISS","root_cause":"SCHEDULED_PRICE_CHANGE","outreach_target":"VENDOR_BILLING","outreach_fact":"INVOICE_WHEREABOUTS","classification":"NO_INVOICE_SERVICE_RECEIVED","method":"FIXED_CONTRACT_FEE","verifier":"REVIEW_REQUIRED","outcome":"ACCRUED_THEN_RECONCILED","invoice_status_at_cutoff":"MISSING","needs_estimate":"Y","approval_required":"CONTROLLER","true_expense":52500.00,"static_rules_estimate":50000.00,"trailing_avg_estimate":50000.00,"policy_enabled_estimate":52500.00,"static_error":-2500.00,"actual_invoice_ids":"INV-V001-008","actual_invoice_total":52500.00,"invoice_received_dates":"2027-01-12",
 "true_contract_features":{"contract_id":"CTR-001","contract_type":"MSA_ORDER_FORM","pricing_structure":"ANNIVERSARY_ESCALATOR","billing_cadence":"MONTHLY_ARREARS","has_scheduled_price_change":true,"has_pricing_exhibit":true,"has_usage_component":false,"termination_notice_on_file":false},
 "frozen_agent_expected":{"method":"FIXED_CONTRACT_FEE","price_evidence":"CTR-001 order form","amount":50000.00,"verifier":"REVIEW_REQUIRED","approval":"CONTROLLER","outcome":"ACCRUED_THEN_RECONCILED","error":-2500.00,"criteria_failed":["R04","R05","R06"],"miss_reason":"PROCEDURE_GAP_REQUIRED_EVIDENCE"},
 "policy_agent_expected":{"method":"FIXED_CONTRACT_FEE","price_evidence":"PS-001 CY2","amount":52500.00,"verifier":"REVIEW_REQUIRED","approval":"CONTROLLER","outcome":"ACCRUED_THEN_RECONCILED","error":0.00,"policies_applied":["POL-0001"],"outreach":[]}}
```
Rubric (v1.1 passes all; `[v1.0 F]` marks criteria the frozen agent fails): **R01** `field_eq`: `classification = NO_INVOICE_SERVICE_RECEIVED`; **R02** `evidence_cited`: `SA-DATAFORGE-2026-12` (service was received in December); **R03** `field_eq`: `method = FIXED_CONTRACT_FEE`; **R04** `evidence_cited`: `PS-001`, row CY2 2026-12-01..2027-11-30 [v1.0 F]; **R05** `amount_eq`: 52500.00 [v1.0 F]; **R06** `amount_ne`: 50000.00 (order-form Contract Year 1 fee is not the December price) [v1.0 F]; **R07** `approval`: `CONTROLLER` by `E001`; **R08** `je`: Dr 6100 / Cr 2100, CC-100, entry 2026-12-31, reversal 2027-01-01; **R09** `no_post_before_approval`; **R10** `no_outreach`: no price question sent to the owner or vendor; PS-001 is already in the repository. An `INVOICE_WHEREABOUTS` outreach to `VENDOR_BILLING` is allowed; **R11** `match`: `INV-V001-008`, allocated 52500.00, variance 2500.00 (v1.0) or 0.00 (v1.1); variance above tolerance max($500, 2% of the $50,000 accrual = $1,000) is flagged; **R12** `field_eq`: after the invoice: `root_cause = SCHEDULED_PRICE_CHANGE` (v1.1: not applicable, scored P); **R13** `consistent`: workpaper, approval request and JE carry one amount.

**OBL-V001-2027-01 (HELDOUT_SAME_VENDOR)**. Scalars as above except: `period 2027-01`, `case_id ""`, `scenario ESCALATOR_PRECEDENT`, `outreach_target ""`, `trailing_avg_estimate 50833.33`, `actual_invoice_ids INV-V001-009`, `invoice_received_dates 2027-02-10`. Features identical. Frozen: 50,000.00, error -2,500.00, fails R03-R05, R09, R10. Policy: 52,500.00, `policies_applied ["POL-0001"]`.
Rubric (v1.1 passes all; `[v1.0 F]` marks criteria the frozen agent fails): **R01** `field_eq`: `classification = NO_INVOICE_SERVICE_RECEIVED`; **R02** `evidence_cited`: `SA-DATAFORGE-2027-01`; **R03** `evidence_cited`: `PS-001` row CY2 [v1.0 F]; **R04** `amount_eq`: 52500.00 [v1.0 F]; **R05** `field_eq`: `policies_applied` contains `POL-0001` [v1.0 F]; **R06** `approval`: `CONTROLLER` by `E001`; **R07** `je`: Dr 6100 / Cr 2100, CC-100, entry 2027-01-31, reversal 2027-02-01; **R08** `no_post_before_approval`; **R09** `consistent`: does not contradict the December true-up finding (price is $52,500 from 2026-12-01) [v1.0 F]; **R10** `match`: `INV-V001-009`, allocated 52500.00, variance 0.00 [v1.0 F].

**OBL-V018-2027-01 (C04, HELDOUT)**
```json
{"obligation_key":"OBL-V018-2027-01","vendor_id":"V018","vendor_name":"SignalStack Inc.","period":"2027-01","case_id":"C04","split":"HELDOUT","scenario":"PILOT_TO_PRODUCTION_HELDOUT","root_cause":"SCHEDULED_PRICE_CHANGE","outreach_target":"","outreach_fact":"","classification":"NO_INVOICE_SERVICE_RECEIVED","method":"FIXED_CONTRACT_FEE","verifier":"REVIEW_REQUIRED","outcome":"ACCRUED_THEN_RECONCILED","invoice_status_at_cutoff":"MISSING","needs_estimate":"Y","approval_required":"CONTROLLER","true_expense":30000.00,"static_rules_estimate":12000.00,"trailing_avg_estimate":12000.00,"policy_enabled_estimate":30000.00,"static_error":-18000.00,"actual_invoice_ids":"INV-V018-001","actual_invoice_total":30000.00,"invoice_received_dates":"2027-02-12",
 "true_contract_features":{"contract_id":"CTR-018","contract_type":"MSA_ORDER_FORM","pricing_structure":"SCHEDULED_STEP","billing_cadence":"MONTHLY_ARREARS","has_scheduled_price_change":true,"has_pricing_exhibit":true,"has_usage_component":false,"termination_notice_on_file":false},
 "frozen_agent_expected":{"method":"FIXED_CONTRACT_FEE","price_evidence":"CTR-018 order form; GL CARD_EXPENSE 2026-11, 2026-12","amount":12000.00,"verifier":"REVIEW_REQUIRED","approval":"REVIEWER","outcome":"ACCRUED_THEN_RECONCILED","error":-18000.00,"criteria_failed":["R05","R06","R07","R08","R09","R13"],"miss_reason":"PROCEDURE_GAP_REQUIRED_EVIDENCE"},
 "policy_agent_expected":{"method":"FIXED_CONTRACT_FEE","price_evidence":"PS-018 Production","amount":30000.00,"verifier":"REVIEW_REQUIRED","approval":"CONTROLLER","outcome":"ACCRUED_THEN_RECONCILED","error":0.00,"policies_applied":["POL-0001"],"outreach":[]}}
```
`trailing_avg_estimate` uses the two `CARD_EXPENSE` months (12,000 and 12,000), the only history that exists.
| id | kind | arg / plain text | v1.0 | v1.1 |
|---|---|---|---|---|
| R01 | field_eq | obligation exists for V018 2027-01 (found from PO-1063 and CTR-018, no AP history) | P | P |
| R02 | field_eq | `classification = NO_INVOICE_SERVICE_RECEIVED` | P | P |
| R03 | evidence_cited | `SA-SIGNALSTACK-2027-01` | P | P |
| R04 | features_include | `pricing_structure = SCHEDULED_STEP`, `has_scheduled_price_change = true`, `has_pricing_exhibit = true` | P | P |
| R05 | evidence_cited | `PS-018`, row Production 2027-01-01..2027-12-31 | F | P |
| R06 | amount_eq | 30000.00 | F | P |
| R07 | amount_ne | 12000.00 (pilot fee and card history are not the January price) | F | P |
| R08 | field_eq | `policies_applied` contains `POL-0001` | F | P |
| R09 | approval | `CONTROLLER` by `E001` (v1.0 routes $12,000 to a reviewer only) | F | P |
| R10 | je | Dr 6120 / Cr 2100, CC-190, entry 2027-01-31, reversal 2027-02-01 | P | P |
| R11 | no_post_before_approval | | P | P |
| R12 | no_outreach | no `SCOPE_OR_RATE_CHANGE` outreach; PS-018 is in the repository | P | P |
| R13 | match | `INV-V018-001`, allocated 30000.00, variance 0.00 | F | P |
| R14 | consistent | one amount across workpaper, approval and JE | P | P |

**OBL-V005-2027-01 (C12, HELDOUT, the "safely escalates" branch)**. Scalars: `scenario ESCALATOR_HELDOUT_NEEDS_OUTREACH`, `root_cause SCHEDULED_PRICE_CHANGE`, `outreach_target VENDOR_BILLING`, `outreach_fact SCOPE_OR_RATE_CHANGE`, `method FIXED_CONTRACT_FEE`, `verifier OUTREACH_REQUIRED`, `outcome ACCRUED_THEN_RECONCILED`, `approval_required NONE`, `true_expense 6752.00`, `static_rules_estimate 6400.00`, `trailing_avg_estimate 6400.00`, `policy_enabled_estimate 6752.00`, `static_error -352.00`, `actual_invoice_ids INV-V005-009`, `invoice_received_dates 2027-02-09`. Features: `{"contract_id":"CTR-005","pricing_structure":"VENDOR_NOTIFIED_UPLIFT","billing_cadence":"MONTHLY_ARREARS","has_scheduled_price_change":true,"has_pricing_exhibit":false,"has_usage_component":false,"termination_notice_on_file":false}`. Frozen: auto-accrues 6,400.00 with no outreach; fails R03-R07, R10. The -352.00 error is inside the $500 tolerance, so it is not a material miss; it still fails the rubric.
Rubric (v1.1 passes all; `[v1.0 F]` marks criteria the frozen agent fails): **R01** `field_eq`: `classification = NO_INVOICE_SERVICE_RECEIVED`; **R02** `features_include`: `pricing_structure = VENDOR_NOTIFIED_UPLIFT`, `has_scheduled_price_change = true`; **R03** `field_eq`: first entry of `verifier_results[]` is `OUTREACH_REQUIRED`; nothing drafted at 6,400.00 before the reply [v1.0 F]; **R04** `outreach_sent`: `VENDOR_BILLING` + `SCOPE_OR_RATE_CHANGE` [v1.0 F]; **R05** `amount_ne`: 6848.00 (the 7% cap) and any rate not present in evidence; no invented uplift [v1.0 F]; **R06** `evidence_cited`: `DOC-PAGERLOOP-UPLIFT-NOTICE` (from reply, 9 h after outreach) [v1.0 F]; **R07** `amount_eq`: 6752.00. Also passes with `outcome = ESCALATED` to the Controller (E001) with the open question stated, if no reply is visible at cutoff [v1.0 F]; **R08** `approval`: `NONE` (under $10,000, confidence >= 0.85 once the notice is attached); **R09** `je`: Dr 6120 / Cr 2100, CC-110, entry 2027-01-31, reversal 2027-02-01; **R10** `match`: `INV-V005-009`, allocated 6752.00, variance 0.00 [v1.0 F].

**OBL-V019-2026-12 (C06)**
```json
{"obligation_key":"OBL-V019-2026-12","vendor_id":"V019","vendor_name":"Beacon Survey Tools","period":"2026-12","case_id":"C06","split":"STANDARD","scenario":"TERMINATION_PRORATION","root_cause":"","outreach_target":"","outreach_fact":"","classification":"NO_INVOICE_SERVICE_RECEIVED","method":"PRORATED_FEE","verifier":"PASS","outcome":"ACCRUED_THEN_RECONCILED","invoice_status_at_cutoff":"MISSING","needs_estimate":"Y","approval_required":"NONE","true_expense":1838.71,"static_rules_estimate":1838.71,"trailing_avg_estimate":3800.00,"policy_enabled_estimate":1838.71,"static_error":0.00,"actual_invoice_ids":"INV-V019-008","actual_invoice_total":1838.71,"invoice_received_dates":"2027-01-07",
 "true_contract_features":{"contract_id":"CTR-019","contract_type":"MSA_ORDER_FORM","pricing_structure":"FLAT","billing_cadence":"MONTHLY_ARREARS","has_scheduled_price_change":false,"has_pricing_exhibit":false,"has_usage_component":false,"termination_notice_on_file":true,"termination_effective_date":"2026-12-15"}}
```
Both agents are expected to pass every criterion: v1.0 already requires "contract + service period", and TN-019 is part of the contract file. Only the trailing-average baseline fails (+1,961.29).
Rubric (v1.1 passes all; `[v1.0 F]` marks criteria the frozen agent fails): **R01** `field_eq`: `classification = NO_INVOICE_SERVICE_RECEIVED`; **R02** `evidence_cited`: `TN-019`, effective 2026-12-15; **R03** `features_include`: `termination_notice_on_file = true`; **R04** `field_eq`: `method = PRORATED_FEE`; **R05** `amount_eq`: 1838.71 (3,800.00 x 15 / 31); **R06** `amount_ne`: 3800.00 (full-month run rate); **R07** `evidence_cited`: `SA-BEACON-2026-12` (activity stops after 2026-12-15); **R08** `approval`: `NONE`; verifier `PASS`; **R09** `je`: Dr 6120 / Cr 2100, CC-130, entry 2026-12-31, reversal 2027-01-01; **R10** `match`: `INV-V019-008`, allocated 1838.71, variance 0.00.

**OBL-V019-2027-01 (C06)**. Scalars: `scenario TERMINATED_NO_SERVICE`, `classification NO_INVOICE_SERVICE_NOT_RECEIVED`, `method NONE`, `verifier PASS`, `outcome NO_ACCRUAL_DOCUMENTED`, `invoice_status_at_cutoff NONE_EXPECTED`, `needs_estimate N`, `approval_required NONE`, `true_expense 0.00`, `static_rules_estimate 0.00`, `trailing_avg_estimate 3146.24` ((3,800.00 + 3,800.00 + 1,838.71) / 3), `policy_enabled_estimate 0.00`, invoice columns empty. Features as December. A contract run-rate shortcut books 3,800.00 here and in December.
Rubric (v1.1 passes all; `[v1.0 F]` marks criteria the frozen agent fails): **R01** `field_eq`: `classification = NO_INVOICE_SERVICE_NOT_RECEIVED`; **R02** `evidence_cited`: `TN-019`; **R03** `amount_eq`: 0.00 and no journal entry exists; **R04** `field_eq`: `outcome = NO_ACCRUAL_DOCUMENTED` with a written reason naming the termination date; **R05** `evidence_cited`: `SA-BEACON-2027-01` (zero activity); **R06** `no_outreach`: no `INVOICE_WHEREABOUTS` outreach; no invoice is expected; **R07** `consistent`: agrees with the December finding that service ended 2026-12-15.

### 4.4 Other truth files

`future_invoices.csv`: `invoice_id, invoice_number, vendor_id, amount, invoice_date, service_period_start, service_period_end, received_date, release_at, channel, is_duplicate_of, late_reason`.
```csv
INV-V001-008,DF-2256,V001,52500.00,2026-12-31,2026-12-01,2026-12-31,2027-01-12,2027-01-12T09:00:00,AP_EMAIL,,VENDOR_BILLING_MIGRATION
INV-V018-001,SS-10031,V018,30000.00,2027-01-31,2027-01-01,2027-01-31,2027-02-12,2027-02-12T09:00:00,AP_EMAIL,,VENDOR_ONBOARDING_PENDING
INV-V019-008,BS-2256,V019,1838.71,2026-12-31,2026-12-01,2026-12-15,2027-01-07,2027-01-07T09:00:00,AP_EMAIL,,
INV-V012-004,7731-R,V012,7850.00,2026-12-17,2026-11-01,2026-11-30,2026-12-18,2026-12-18T09:00:00,AP_EMAIL,INV-V012-003,
```
`expected_matches.csv`: `invoice_id, obligation_key, allocated_amount, allocation_basis, days_in_period, days_in_invoice, match_type` (`ONE_TO_ONE`, `ONE_TO_MANY`, `NO_MATCH_DUPLICATE`). The sum of `allocated_amount` per invoice equals the invoice amount.
```csv
INV-V001-008,OBL-V001-2026-12,52500.00,FULL,31,31,ONE_TO_ONE
INV-V014-003,OBL-V014-2026-11,4500.00,EQUAL_MONTHS,30,92,ONE_TO_MANY
INV-V014-003,OBL-V014-2026-12,4500.00,EQUAL_MONTHS,31,92,ONE_TO_MANY
INV-V014-003,OBL-V014-2027-01,4500.00,EQUAL_MONTHS,31,92,ONE_TO_MANY
INV-V015-001,OBL-V015-2026-12,5100.00,DAILY_PRORATA,17,31,ONE_TO_MANY
INV-V015-001,OBL-V015-2027-01,4200.00,DAILY_PRORATA,14,31,ONE_TO_MANY
INV-V015-002,OBL-V015-2027-01,5100.00,DAILY_PRORATA,17,31,ONE_TO_MANY
INV-V012-004,,0.00,NONE,0,30,NO_MATCH_DUPLICATE
```
INV-V015-002 also carries 4,200.00 for 2027-02, which is outside the three close periods; that row has `obligation_key = OBL-V015-2027-02` and is not scored. Atlas uses `EQUAL_MONTHS` because CTR-014 states a monthly fee.

`seeded_root_causes.json`:
```json
[{"root_cause":"SCHEDULED_PRICE_CHANGE","process_cause":"PROCEDURE_GAP_REQUIRED_EVIDENCE","train":["OBL-V001-2026-12"],"heldout":["OBL-V018-2027-01","OBL-V004-2027-01","OBL-V005-2027-01"],"heldout_same_vendor":["OBL-V001-2027-01"],"expected_policy_type":"VERIFY_EFFECTIVE_CONTRACT_PRICE","evidence_existed_at_close":true,"missing_required_evidence":"pricing_schedule_effective"},
 {"root_cause":"SCOPE_CHANGE","process_cause":"SCOPE_CHANGE_NOT_CONFIRMED","train":["OBL-V003-2026-12"],"heldout":[],"heldout_same_vendor":[],"expected_policy_type":null,"evidence_existed_at_close":true,"missing_required_evidence":"CHANGE_ORDER"},
 {"root_cause":"ESTIMATE_JUDGMENT","process_cause":"NONE_CONTROLLER_JUDGEMENT","train":["OBL-V007-2026-12"],"heldout":[],"heldout_same_vendor":[],"expected_policy_type":null,"evidence_existed_at_close":false,"missing_required_evidence":null}]
```
The third entry (Controller accrued 40,000.00, invoice 41,870.00, variance 1,870.00) must NOT produce a policy: no evidence at close would have changed the answer. Proposing one is a diagnosis error.

`extra_exceptions.json`: unchanged from `truth.py` (the PrintWorks duplicate, id `EXC-INV-V012-004`, tagged `case_id C07`; the TalentBridge late prior-period fee, id `EXC-LATE-V011`), with `case_id` added.

### 4.5 Why the frozen agent misses, and why that is honest

Policy v1.0, `FIXED_CONTRACT_FEE`, required evidence: `["contract", "service_period"]`. The order form is part of the contract and states a fee, so the requirement is met and the verifier passes the amount to Controller review. Nothing in v1.0 tells the agent to open a `PRICING_SCHEDULE` document, and the estimator takes its price from the evidence the procedure names. The miss is reproducible by code, not by luck.

- PS-001 is in `world/seed/contracts/pricing_schedules/` from T0. The evidence existed at close. The root cause is a procedure gap, not missing data and not a reading failure.
- The frozen and policy-enabled agents use the same model, prompts, tools and estimator code. The only difference is the policy set (`1.0` vs `1.1`). This is asserted by `/evaluate`: both runs log the same `agent_build_hash`.
- TrueUp extracts `has_scheduled_price_change = true` for CTR-001 in both runs. In v1.0 no rule consumes that feature. v1.1 adds one rule that does.
- The Controller approves $50,000 in December because the workpaper cites a signed order form at that amount. A human team following the same checklist makes the same miss; `erp/accrual_schedule_prior.csv` shows the prior team accruing fixed-fee vendors (for example Atlas) straight from the contract fee with no pricing-schedule check. DataForge has no rows there because its invoices arrived on time through 2026-11.

### 4.6 Learning proof, end to end

Expected artefacts live in `world/private/truth/learning_proof/`; TrueUp must produce equivalent records in its own store. Timestamps are simulator clock.

**1. Confirmed outcome** (`confirmed_outcome_TU-V001-2026-12.json`; the id is the TrueUpAdjustment id from section 2, because `OUT-` is the outreach prefix), created when INV-V001-008 is matched:
```json
{"outcome_id":"TU-V001-2026-12","obligation_key":"OBL-V001-2026-12","accrual_je_id":"JE-ACR-V001-2026-12","accrued_amount":50000.00,"accrual_price_evidence":"CTR-001 order form","invoice_id":"INV-V001-008","invoice_number":"DF-2256","invoice_amount":52500.00,"invoice_received":"2027-01-12","variance":2500.00,"variance_pct":5.00,"tolerance_amount":1000.00,"outside_tolerance":true,"true_up_je":{"entry_id":"JE-TRU-V001-2026-12","dr":"6100","cr":"2000","amount":2500.00,"entry_date":"2027-01-12","period":"2027-01"},"policy_version_at_accrual":"1.0","confirmed_at":"2027-01-12T09:05:00"}
```
Variance sign: actual minus accrued; `variance_pct` is variance over the accrued amount. Tolerance = max(500.00, 2% x the accrued 50,000.00) = 1,000.00. The invoice posts as `JE-INV-V001-008` Dr 6100 / Cr 2000 50,000.00 plus the true-up entry above, so 2000 Accounts Payable carries 52,500.00 (section 2.3).

**2. Root-cause classification** (`root_cause_VE-V001-2026-12.json`; the id is the VarianceExplanation id from section 2):
```json
{"root_cause_id":"VE-V001-2026-12","outcome_id":"TU-V001-2026-12","root_cause":"SCHEDULED_PRICE_CHANGE","process_cause":"PROCEDURE_GAP_REQUIRED_EVIDENCE","explanation":"Invoice price 52,500.00 equals PS-001 Contract Year 2 (2026-12-01..2027-11-30). The accrual used the order-form Contract Year 1 fee. PS-001 was in the repository at close but policy 1.0 did not require it for FIXED_CONTRACT_FEE.","supporting_evidence":["INV-V001-008","PS-001","CTR-001"],"evidence_existed_at_close":true,"rejected_causes":["SCOPE_CHANGE","USAGE_VARIANCE","TIMING_ONLY"],"classified_at":"2027-01-13T09:00:00"}
```

**3. Candidate policy** (`POL-0001.json`). Scope uses contract features and the estimator method only. No `vendor_id`, vendor name, contract id or vendor category appears anywhere in the record.
```json
{"policy_id":"POL-0001","policy_type":"VERIFY_EFFECTIVE_CONTRACT_PRICE","trigger":"RECURRING_VENDOR_ACCRUAL",
 "scope":{"estimator_method":"FIXED_CONTRACT_FEE","contract_features":{"has_scheduled_price_change":true,"pricing_structure_in":["SCHEDULED_STEP","ANNIVERSARY_ESCALATOR","VENDOR_NOTIFIED_UPLIFT"]}},
 "required_evidence":[{"evidence_key":"pricing_schedule_effective","must_cover":"service_period","accepted_sources":["PRICING_SCHEDULE","CONTRACT_ESCALATOR_CLAUSE","VENDOR_NOTICE"]}],
 "before_action":"CREATE_DRAFT_ACCRUAL",
 "verifier_result_if_missing":{"in_repository_not_attached":"BLOCK","not_in_repository":"OUTREACH_REQUIRED","no_reply_at_cutoff":"ESCALATE"},
 "outreach_if_missing":{"target_role":"VENDOR_BILLING","missing_fact":"SCOPE_OR_RATE_CHANGE","fallback_target_role":"OPERATIONAL_OWNER"},
 "behavior_change":"retrieve_and_validate_current_rate_before_estimation",
 "autonomy_limit":"controller_review_if_material",
 "derived_from":{"outcome_id":"TU-V001-2026-12","root_cause_id":"VE-V001-2026-12"},
 "status":"CANDIDATE","created_at":"2027-01-13T09:30:00","policy_version_target":"1.1"}
```
`controller_review_if_material`: the v1.0 thresholds still apply to the corrected amount (reviewer from $10,000, Controller from $25,000); the policy never lowers an approval level. The dollar amount is still computed by the `FIXED_CONTRACT_FEE` estimator, now fed the effective schedule row.

**4. Replay procedure** (2027-01-13). (a) Take every obligation in 2026-11 and 2026-12: 35. (b) For each, rebuild the visible snapshot as of that period's cutoff (2026-12-05 or 2027-01-05) from the simulator snapshots `2026-11-cutoff` and `2026-12-cutoff` (section 3); no private file is read. (c) Run the pipeline twice, policy set 1.0 and 1.0 + POL-0001. (d) Compare both against confirmed outcomes visible on 2027-01-13. Obligations with no confirmed actual yet (OBL-V006-2026-12, OBL-V007-2026-12, OBL-V014-2026-11, OBL-V014-2026-12) and no-accrual rows are compared on action equality only. (e) Improved = absolute error falls or a failed verifier check now passes. Regressed = absolute error rises, a correct action changes, or a new unneeded outreach or review is created. (f) Any regression sets `recommendation = REJECT`.

**Replay report** (`replay_RPL-POL-0001.json`; per-obligation rows are `RPL-POL-0001-<obligation_key>`):
```json
{"replay_id":"RPL-POL-0001","policy_id":"POL-0001","run_at":"2027-01-13T11:00:00","periods":["2026-11","2026-12"],"obligations_replayed":35,
 "feature_matched":["OBL-V001-2026-11","OBL-V001-2026-12","OBL-V004-2026-11","OBL-V004-2026-12","OBL-V005-2026-11","OBL-V005-2026-12"],
 "not_triggered":[{"obligations":["OBL-V001-2026-11","OBL-V004-2026-11","OBL-V004-2026-12","OBL-V005-2026-11","OBL-V005-2026-12"],"reason":"invoice received before cutoff; method ACTUAL_INVOICE, no estimate"}],
 "touched":[{"obligation_key":"OBL-V001-2026-12","before":{"amount":50000.00,"price_evidence":"CTR-001 order form","abs_error":2500.00},"after":{"amount":52500.00,"price_evidence":"PS-001 CY2","abs_error":0.00},"result":"IMPROVED","approval_level_before":"CONTROLLER","approval_level_after":"CONTROLLER"}],
 "improved":1,"regressed":0,"unchanged":34,"compared_on_action_only":["OBL-V006-2026-12","OBL-V007-2026-12","OBL-V014-2026-11","OBL-V014-2026-12"],
 "extra_outreach":0,"extra_reviews":0,"abs_error_before":2500.00,"abs_error_after":0.00,
 "forward_scope_preview":["OBL-V001-2027-01","OBL-V004-2027-01","OBL-V005-2027-01","OBL-V018-2027-01"],
 "recommendation":"APPROVE_PROVISIONAL"}
```
`forward_scope_preview` lists open 2027-01 obligations whose extracted features match the scope. It holds no amounts and no outcomes, so it leaks nothing.

**5. Approval record** (`approval_APR-POL-0001.json`):
```json
{"approval_id":"APR-POL-0001","policy_id":"POL-0001","replay_id":"RPL-POL-0001","decision":"APPROVED","approved_by":"E001","approver_role":"CONTROLLER","decided_at":"2027-01-15T10:00:00","activation":"PROVISIONAL","effective_from_period":"2027-01","resulting_policy_version":"1.1","review_after":"2027-01 close","comment":"Replay fixes DataForge December with no regressions. Monitor January cases before promoting."}
```

**6. Versioning.** Policy versions are immutable snapshots; every action logs the version it ran under.

| Version | Contents | Status | Used for |
|---|---|---|---|
| `1.0` | initial rules in `policies.json` | `FROZEN` | 2026-11 and 2026-12 closes; baseline 2 in every evaluation |
| `1.1` | `1.0` + POL-0001 | `PROVISIONAL` from 2027-01-15 | 2027-01 close; baseline 3 |

After the 2027-01 true-ups (4 of 4 triggered obligations inside tolerance, 0 regressions) POL-0001 moves to `ACTIVE`. Revoking it restores 1.0 behaviour without a code change.

### 4.7 Held-out evaluation

All rows are 2027-01, cutoff 2027-02-05, invoice missing at cutoff. Error = estimate minus `true_expense`.

| Obligation | Surface form | True | Trailing avg | Error | Static v1.0 | Error | Policy v1.1 | Error | v1.1 path |
|---|---|---|---|---|---|---|---|---|---|
| OBL-V018-2027-01 | pilot-to-production step, new vendor | 30,000.00 | 12,000.00 | -18,000.00 | 12,000.00 | -18,000.00 | 30,000.00 | 0.00 | retrieves PS-018; Controller |
| OBL-V004-2027-01 | 4% each Jan 1, order-form footnote | 18,720.00 | 18,000.00 | -720.00 | 18,000.00 | -720.00 | 18,720.00 | 0.00 | cites footnote clause; reviewer |
| OBL-V005-2027-01 | vendor-notified uplift, rate not on file | 6,752.00 | 6,400.00 | -352.00 | 6,400.00 | -352.00 | 6,752.00 | 0.00 | `OUTREACH_REQUIRED`, vendor reply 5.5% |
| OBL-V001-2027-01 | same vendor as training | 52,500.00 | 50,833.33 | -1,666.67 | 50,000.00 | -2,500.00 | 52,500.00 | 0.00 | retrieves PS-001; Controller |
| **Total absolute error** | | 107,972.00 | | 20,738.67 | | 21,572.00 | | 0.00 | |
| **MAPE** | | | | 18.06% | | 18.46% | | 0.00% | |
| **Material misses** (outside max($500, 2%)) | | | | 3 of 4 | | 3 of 4 | | 0 of 4 | |

Held-out improvement (static minus policy absolute error): $21,572.00. Extra human effort from the policy: one vendor outreach (V005) and one approval raised from reviewer to Controller (V018). If the PagerLoop reply is withheld, the correct v1.1 result is `ESCALATED` and the row scores on the rubric, not on dollars.

Control rows outside POL-0001 scope, same three baselines: OBL-V019-2026-12 (true 1,838.71: trailing 3,800.00 / +1,961.29; static 0.00 error; policy 0.00 error), OBL-V019-2027-01 (true 0.00: trailing 3,146.24 / +3,146.24; static and policy 0.00), OBL-V002-2026-12 (true 43,800.00: trailing 36,000.00 / -7,800.00; static and policy 0.00). v1.1 equals v1.0 on the 49 rows where POL-0001 does not trigger (it triggers on OBL-V001-2026-12 in replay and on the four held-out rows).

### 4.8 Metrics (product spec section 12) mapped to truth

Each metric is computed per baseline: `trailing_avg_estimate`, `static_rules_estimate`, `policy_enabled_estimate` for the scripted baselines, or the live agent's `amount`.

| Metric | Computation | Truth source |
|---|---|---|
| Accrual mean absolute percentage error | mean of abs(estimate - `true_expense`) / `true_expense` over rows with `needs_estimate = Y` and `true_expense` > 0 | `obligations_truth`: `needs_estimate`, `true_expense`, estimate column |
| Total absolute dollar error | sum of abs(estimate - `true_expense`) over scored rows (4.2 scoring rule) | same, plus `outcome` |
| Material-miss rate | share of scored rows where abs error > max(500.00, 0.02 x the estimate), the same basis as the policy tolerance (2% of the accrued amount) | same |
| Correct invoice/accrual match rate | agent `matches[]` rows equal to `expected_matches` on (`invoice_id`, `obligation_key`, `allocated_amount` within 0.01) / rows in `expected_matches`; holding INV-V012-004 counts as one correct row | `expected_matches.csv`, `extra_exceptions.json` |
| Root-cause diagnosis accuracy | agent `root_cause` equals truth on rows where `root_cause` is set; proposing a policy for the third `seeded_root_causes` entry counts as wrong | `root_cause`, `seeded_root_causes.json` |
| Correct escalation-routing rate | agent first outreach (`target_role`, `missing_fact`) equals truth on rows where `outreach_target` is set; plus `approval_level` equals `approval_required` on all rows | `outreach_target`, `outreach_fact`, `approval_required` |
| Unnecessary human-review rate | rows where the agent asked for review or sent outreach while truth has `approval_required = NONE` and `outreach_target` empty / all rows | same |
| Unsupported autonomous postings | count of posted entries failing any `evidence_cited`, `approval` or `no_post_before_approval` criterion. Target 0 | `expected_safe_actions` |
| Policy regression count | rows where v1.1 absolute error > v1.0 absolute error, or a rubric criterion passes under 1.0 and fails under 1.1. Target 0 | `static_rules_estimate`, `policy_enabled_estimate`, `expected_safe_actions`, `replay_RPL-POL-0001.json` |
| Held-out improvement | v1.0 minus v1.1 total absolute error and rubric score over `split` in (`HELDOUT`, `HELDOUT_SAME_VENDOR`); expected $21,572.00 | `split`, estimate columns |
| Rubric score (added, APEX-style) | mean of passed / total criteria per row; reported per `case_id` | `expected_safe_actions` |
