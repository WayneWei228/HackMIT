## 2. Source systems, files and schemas

All paths are relative to `runtime/visible/`. The simulator copies `world/seed/` there at T0 = `2026-12-01T00:00` and then appends rows or adds files as events are released. TrueUp tools get this root only.

Conventions. Types: `str`, `int`, `dec` (number, 2 decimals, USD), `bool`, `date` (`YYYY-MM-DD`), `ym` (`YYYY-MM`), `ts` (`YYYY-MM-DDTHH:MM:SS`, company local time, no offset), `enum`, `[]` = list. CSV blanks mean null. An `evidence_id` is the primary key of a visible record (for example `CTR-001`, `PS-001`, `INV-V001-008`, `SA-DATAFORGE-2026-12`). Files with a composite key use the form given in the table. Existing paths from the first fixture set are kept; only new sources get new folders.

### 2.1 File inventory

| Path | Imitates | Format | Primary key (evidence_id form) | Grows after T0 via |
|---|---|---|---|---|
| `company.json` | ERP setup | JSON object | n/a | `PERIOD_STATUS_CHANGE` rewrites `close_calendar[].status` |
| `org_directory.json` | Org directory / HRIS | JSON object | `employee_id`; contacts `(vendor_id, role)` | `VENDOR_ONBOARDED` adds V018 contact |
| `vendors.json` | Procurement vendor master | JSON list | `vendor_id` | `VENDOR_ONBOARDED` adds V018 on 2027-01-08 |
| `purchase_orders.json` | Procurement | JSON list | `po_id` | `PO_ISSUED` adds PO-1063 on 2027-01-08 |
| `change_orders.json` | Procurement | JSON list | `change_order_id` | `PO_ISSUED` adds CO-1 on 2026-12-10 |
| `contracts/index.json` | Contract repository index | JSON list | `doc_id` | `CONTRACT_DOC_ADDED` |
| `contracts/CTR-0NN.pdf` + `.txt` | Contract repository | PDF + text | `doc_id` = `CTR-0NN` | `CONTRACT_DOC_ADDED` (CTR-018) |
| `contracts/pricing_schedules/PS-0NN.pdf` + `.txt` | Contract repository | PDF + text | `doc_id` = `PS-0NN` | `CONTRACT_DOC_ADDED` (PS-018) |
| `contracts/notices/TN-019.pdf` + `.txt` | Contract repository | PDF + text | `doc_id` = `TN-019` | seed only |
| `invoices/invoices.json`, `invoices/pdf/<invoice_id>.pdf` | AP inbox capture | JSON list + PDF | `invoice_id` | `INVOICE_RECEIVED` |
| `ap_queue.csv` | AP subledger / queue | CSV | `ap_id` | `INVOICE_RECEIVED` (same event as the invoice) |
| `gl_entries.csv` | ERP GL extract | CSV | `(entry_id, line_no)`; evidence_id = `entry_id` | `EVIDENCE_UPDATE` (Dec card row); TrueUp posting tool |
| `erp/accrual_schedule_prior.csv` | Close team spreadsheet | CSV | `(vendor_id, period)`; `ACS-V007-2026-10` | seed only |
| `evidence/usage_daily.csv` | Usage / metering export | CSV | `(vendor_id, date, metric)`; monthly `USG-V002-2026-12` | `USAGE_EXPORT`, whole month at 06:00 on day 1 of next month |
| `evidence/service_activity.csv` | SSO + vendor admin consoles | CSV | `activity_id` | `EVIDENCE_UPDATE`, whole month at 06:00 on day 1 of next month |
| `evidence/seat_snapshots.csv` | Vendor admin console | CSV | `(vendor_id, snapshot_date)`; `SEAT-V003-2026-12-10` | `EVIDENCE_UPDATE` |
| `evidence/timesheets.csv` | PMO timesheet tool | CSV | `(vendor_id, week_ending)`; `TS-V006-2026-12-25` | `EVIDENCE_UPDATE` (new weeks, approvals) |
| `evidence/hr_hires.csv` | HRIS | CSV | `hr_record_id` | `EVIDENCE_UPDATE` |
| `evidence/goods_receipts.csv` | Procurement receiving | CSV | `receipt_id` | `EVIDENCE_UPDATE` |
| `close_policy_manual.md` | Policy manual (prose) | Markdown | section number | new version file on policy activation |
| `policies.json` | Policy manual (data) | JSON object | `policy_version` | rewritten by TrueUp on activation of v1.1 |
| `inbox/messages.jsonl` | Shared close inbox | JSON lines | `message_id` | simulator only: OUTBOUND row when TrueUp calls `send_outreach`, INBOUND row after `delay_hours` |

`inbox/scripted_responses.json` moves to `world/private/inbox/scripted_responses.json` and is never visible. `ground_truth/` is renamed `world/private/truth/`.

### 2.2 Schemas and example records

**company.json** keys: `name` str, `description` str, `base_currency` str, `entities[]` {`entity_id`, `name`, `country`}, `cost_centers[]` {`id`, `name`}, `chart_of_accounts[]` {`account`, `name`, `type` enum asset/liability/expense}, `close_calendar[]` {`period` ym, `cutoff` date, `status` enum FUTURE/OPEN/CLOSED}, `closed_periods[]` ym. Add account `2050 Corporate Card Payable` (liability). Status meaning: FUTURE = month still running or not started (postings allowed), OPEN = month ended and in close, CLOSED = no postings. OPEN starts at 00:00 on day 1 of the next month; CLOSED starts at the cutoff instant (23:59:59 on the cutoff date). The verifier check PERIOD_OPEN passes when status is not CLOSED. At T0: 2026-11 OPEN, 2026-12 and 2027-01 FUTURE.
```json
{"period": "2026-12", "cutoff": "2027-01-05", "status": "FUTURE"}
```

**org_directory.json** `employees[]`: `employee_id` str PK, `name`, `title`, `role` enum (CONTROLLER, ACCOUNTING_MANAGER, AP_SPECIALIST, CLOSE_ACCOUNTANT, BUDGET_OWNER, REQUESTER, FPA, TREASURY), `cost_center` FK company.cost_centers nullable, `legal_entity_id` FK, `email`. `vendor_contacts[]`: `vendor_id` FK vendors, `name`, `email`, `role` enum VENDOR_BILLING/VENDOR_ACCOUNT_MANAGER.
```json
{"employee_id": "E019", "name": "Elena Rossi", "title": "VP Marketing", "role": "BUDGET_OWNER", "cost_center": "CC-190", "legal_entity_id": "NS-US", "email": "elena.rossi@northstar.example"}
```

**vendors.json** columns: `vendor_id` str PK, `name` str, `category` enum (SAAS_OR_DATA, CLOUD_USAGE, CONSULTING, LEGAL, FACILITIES, RENT, RECRUITING, MARKETING, TELECOM; unchanged), `spend_type` enum (SUBSCRIPTION, USAGE, SERVICES, RENT, OTHER), `gl_account` FK chart, `cost_center` FK, `legal_entity_id` FK, `operational_owner` FK employee, `requester` FK employee, `billing_contact` str, `billing_email` str, `contract_id` FK contracts/index nullable, `po_id` FK PO nullable, `payment_terms` str, `onboarded_date` date, `status` enum ACTIVE/TERMINATED, `notes` str. The old `pricing_model` column is deleted. Mapping from the old values: FIXED_MONTHLY, FIXED_MONTHLY_ADVANCE_MIDMONTH, PER_SEAT, ANNUAL_PREPAID -> SUBSCRIPTION; USAGE_TIERED -> USAGE; TIME_AND_MATERIALS, HOURLY_NO_CAP, CONTINGENT_PER_HIRE, FIXED_QUARTERLY_ARREARS -> SERVICES; FIXED_MONTHLY_ADVANCE (OfficeNest) and Thames serviced office (V017) -> RENT; PER_JOB_PO, VARIABLE_MONTHLY -> OTHER. V018 and V019 are SUBSCRIPTION. `notes` must not mention prices, escalators or schedules. `status` is ACTIVE for all 19 vendors in all three periods, including V019 (procurement never updated it; deliberate conflict with TN-019, like the open PO-0962).
```json
{"vendor_id": "V001", "name": "DataForge Inc.", "category": "SAAS_OR_DATA", "spend_type": "SUBSCRIPTION", "gl_account": "6100", "cost_center": "CC-100", "legal_entity_id": "NS-US", "operational_owner": "E010", "requester": "E030", "billing_contact": "Amira Khan", "billing_email": "billing@dataforge.example", "contract_id": "CTR-001", "po_id": "PO-1029", "payment_terms": "Net 30", "onboarded_date": "2025-11-20", "status": "ACTIVE", "notes": ""}
{"vendor_id": "V018", "name": "SignalStack Inc.", "category": "SAAS_OR_DATA", "spend_type": "SUBSCRIPTION", "gl_account": "6120", "cost_center": "CC-190", "legal_entity_id": "NS-US", "operational_owner": "E019", "requester": "E019", "billing_contact": "SignalStack Billing", "billing_email": "billing@signalstack.example", "contract_id": "CTR-018", "po_id": "PO-1063", "payment_terms": "Net 30", "onboarded_date": "2027-01-08", "status": "ACTIVE", "notes": "Onboarded from corporate card to AP"}
```

**purchase_orders.json**: `po_id` PK, `vendor_id` FK, `owner` FK employee, `requester` FK employee, `cost_center` FK, `legal_entity_id` FK, `authorized_amount` dec, `type` enum BLANKET_ANNUAL/PROJECT_TM/ONE_TIME, `valid_from` date, `valid_to` date, `issued_date` date, `status` enum OPEN/CLOSED, `description` str. Blanket POs that ended 2026-12-31 are extended to 2027-12-31 at the same `authorized_amount`, so extended PO amounts never encode a future price. New for Beacon: PO-0962 (V019, BLANKET_ANNUAL, 45600.0, 2026-04-01..2027-03-31, issued 2026-03-20, OPEN). PO-1063 is the one PO whose amount implies a future price (360000 = 12 x 30000); the v1.0 `FIXED_CONTRACT_FEE` estimator never reads PO amounts.
```json
{"po_id": "PO-1063", "vendor_id": "V018", "owner": "E019", "requester": "E019", "cost_center": "CC-190", "legal_entity_id": "NS-US", "authorized_amount": 360000.0, "type": "BLANKET_ANNUAL", "valid_from": "2027-01-01", "valid_to": "2027-12-31", "issued_date": "2027-01-08", "status": "OPEN", "description": "SignalStack product analytics, 2027"}
```

**change_orders.json**: `change_order_id` PK, `po_id` FK, `vendor_id` FK, `effective_date` date, `requested_by` FK, `approved_by` FK, `description` str, `seat_delta` int, `unit_price` dec, `po_increase` dec. Example: existing CO-1 (PO-1017, V003, 2026-12-10, +30 seats at 85.00).

**contracts/index.json**: `doc_id` PK, `doc_type` enum (MSA = every `CTR-0NN` file whatever its contract_type, PRICING_SCHEDULE, TERMINATION_NOTICE, VENDOR_NOTICE = the PagerLoop uplift notice `DOC-PAGERLOOP-UPLIFT-NOTICE`, filed under `inbox/attachments/` when the vendor reply arrives), `contract_id` str (groups documents of one agreement), `counterparty_name` str, `vendor_id` FK vendors nullable (null until the vendor is onboarded), `title` str, `effective_date` date, `filed_date` date, `filed_by` FK employee, `files[]` str, `supersedes` doc_id nullable. The `CTR-0NN` file holds the MSA followed by the Order Form (Exhibit A). The pricing schedule (Exhibit B) is always a separate document. CTR-018 and PS-018 are filed 2027-01-08 with the onboarding paperwork.
```json
{"doc_id": "PS-001", "doc_type": "PRICING_SCHEDULE", "contract_id": "CTR-001", "counterparty_name": "DataForge Inc.", "vendor_id": "V001", "title": "Exhibit B - Pricing Schedule", "effective_date": "2025-12-01", "filed_date": "2025-11-24", "filed_by": "E030", "files": ["contracts/pricing_schedules/PS-001.pdf", "contracts/pricing_schedules/PS-001.txt"], "supersedes": null}
```
Text layout of `PS-001.txt` (PS-018 is identical in form, rows `Pilot | 2026-11-01 | 2026-12-31 | $12,000.00` and `Production | 2027-01-01 | 2027-12-31 | $30,000.00`):
```
PRICING SCHEDULE (EXHIBIT B)   Document ID: PS-001   Contract ID: CTR-001
Contract Year | Start      | End        | Monthly Platform Fee
CY1           | 2025-12-01 | 2026-11-30 | $50,000.00
CY2           | 2026-12-01 | 2027-11-30 | $52,500.00
```
`TN-019.txt` header lines: `Document ID: TN-019`, `Contract ID: CTR-019`, `Notice date: 2026-11-14`, `Termination effective: 2026-12-15`, `Sent by: Jordan Blake (E013)`, then one paragraph citing the 30-day notice clause and "fees prorated to the effective date".

**invoices/invoices.json**: `invoice_id` PK, `invoice_number` str, `vendor_id` FK, `vendor_name`, `bill_to` str, `invoice_date` date, `received_date` date, `service_period_start` date, `service_period_end` date, `po_id` FK nullable, `currency` str, `amount` dec, `line_items[]` {`description`, `quantity` dec, `unit_price` dec, `amount` dec}, `payment_terms`, `received_channel`, `notes`. Number prefixes: add `SS` (V018, numbers start `SS-10031`) and `BS` (V019).
```json
{"invoice_id": "INV-V001-008", "invoice_number": "DF-2256", "vendor_id": "V001", "vendor_name": "DataForge Inc.", "bill_to": "Northstar Analytics, Inc.", "invoice_date": "2026-12-31", "received_date": "2027-01-12", "service_period_start": "2026-12-01", "service_period_end": "2026-12-31", "po_id": "PO-1029", "currency": "USD", "amount": 52500.0, "line_items": [{"description": "DataForge Platform subscription - December 2026 (Contract Year 2)", "quantity": 1, "unit_price": 52500.0, "amount": 52500.0}], "payment_terms": "Net 30", "received_channel": "ap@northstar.example", "notes": ""}
```

**ap_queue.csv**: `ap_id` PK (`AP-V001-008`), `invoice_id` FK, `invoice_number`, `vendor_id` FK, `received_date` date, `received_channel`, `amount` dec, `coded_entity` FK, `coded_account` FK, `coded_cost_center` FK, `po_id` FK nullable, `status` enum PENDING_APPROVAL/APPROVED/ON_HOLD/PAID, `approver` FK employee, `due_date` date, `paid_date` date nullable.
```
AP-V018-001,INV-V018-001,SS-10031,V018,2027-02-12,ap@northstar.example,30000.0,NS-US,6120,CC-190,PO-1063,PENDING_APPROVAL,E019,2027-03-02,
```

**gl_entries.csv**: `entry_id` str, `line_no` int, `posting_date` date, `period` ym, `legal_entity_id` FK, `account` FK, `cost_center` FK, `vendor_id` FK nullable, `debit` dec, `credit` dec, `entry_type` enum (INVOICE, ACCRUAL, ACCRUAL_CARRYFORWARD, ACCRUAL_REVERSAL, AMORTIZATION, CARD_EXPENSE, TRUE_UP), `reference` str, `memo` str, `reversal_of` entry_id nullable, `posted_by` str (employee id, `CARD_FEED`, or `TRUEUP`), `obligation_id` str nullable (new; blank on seed rows, required on every `TRUEUP` row). Seed entry ids are `JE-NNNNN`; card entries are `JE-CARD-0001` (Nov) and `JE-CARD-0002` (Dec, posting_date 2026-12-02, released by `EVIDENCE_UPDATE`); TrueUp entries are `JE-ACR-`, `JE-REV-`, `JE-INV-`, `JE-TRU-` + obligation or invoice suffix. Card rows have blank `vendor_id`; the merchant name appears only in `memo`.
```
JE-CARD-0001,1,2026-11-03,2026-11,NS-US,6120,CC-190,,12000.0,0.0,CARD_EXPENSE,CARD-4417-20261103,Corp card x4417 (E019) SIGNALSTACK INC pilot fee Nov 2026,,CARD_FEED,
JE-CARD-0001,2,2026-11-03,2026-11,NS-US,2050,CC-190,,0.0,12000.0,CARD_EXPENSE,CARD-4417-20261103,Corp card x4417 (E019) SIGNALSTACK INC pilot fee Nov 2026,,CARD_FEED,
JE-ACR-V001-2026-12,1,2026-12-31,2026-12,NS-US,6100,CC-100,V001,50000.0,0.0,ACCRUAL,ACR-V001-2026-12,Accrual DataForge Inc. service 2026-12,,TRUEUP,OBL-V001-2026-12
```

**erp/accrual_schedule_prior.csv** (the human team's rollforward, one row per vendor-month they accrued in 2026-05..2026-10): `vendor_id` FK, `vendor_name`, `period` ym, `gl_account` FK, `cost_center` FK, `basis` str (free text: "commit fee", "owner estimate", "quarterly contract"), `accrued` dec, `actual` dec nullable, `variance` dec nullable (= actual - accrued), `invoice_number` str nullable, `invoice_received` date nullable, `je_ref` FK gl_entries.reference, `preparer` FK employee, `reviewer` FK employee, `note` str. DataForge, SignalStack and Beacon have no rows (never accrued in history). Planted conflict: the V002 note says "accrue at commit, overage immaterial", which is false for 2026-12.
```
V007,Meridian Legal LLP,2026-10,6210,CC-150,owner estimate,12000.0,12750.0,750.0,ML-2228,2026-11-20,ACR-V007-2026-10,E004,E002,Owner estimate low; final bill included filing fees
```

**evidence/usage_daily.csv**: `vendor_id` FK, `date` date, `metric` enum compute_hours/egress_gb, `quantity` int, `source` str. Example: `V002,2026-12-01,compute_hours,11532,usage-export` (December sums to 352,000).

**evidence/service_activity.csv** (one row per application per month): `activity_id` PK (`SA-<APPKEY>-<period>`; APPKEY is the first word of the vendor name in capitals: DATAFORGE, LUMEN, PAGERLOOP, PAYCIRCLE, QUANTIVE, SIGNALSTACK, BEACON), `period` ym, `application` str, `vendor_id` FK nullable (blank when the vendor is not in the vendor master at export time; rows are never patched later, so SignalStack 2026-11 and 2026-12 stay blank), `source_system` str, `active_users` int, `active_days` int, `api_calls` int, `first_activity_date` date nullable, `last_activity_date` date nullable, `service_status` enum ACTIVE/PARTIAL/INACTIVE. Covers V001, V004, V005, V009, V015, V018, V019. Beacon: 2026-12 PARTIAL with `last_activity_date` 2026-12-15; 2027-01 INACTIVE with zeros.
```
SA-DATAFORGE-2026-12,2026-12,DataForge Platform,V001,okta-sso+dataforge-admin-api,41,31,1284000,2026-12-01,2026-12-31,ACTIVE
SA-SIGNALSTACK-2026-11,2026-11,SignalStack,,okta-sso,9,22,0,2026-11-04,2026-11-30,ACTIVE
SA-SIGNALSTACK-2027-01,2027-01,SignalStack,V018,okta-sso,64,31,412000,2027-01-01,2027-01-31,ACTIVE
```

**evidence/seat_snapshots.csv**: `vendor_id`, `snapshot_date` date, `active_seats` int, `source`. **evidence/timesheets.csv**: `vendor_id`, `po_id` FK, `week_ending` date, `service_month` ym, `hours` int, `rate` dec, `approval_status` enum APPROVED/PENDING, `approved_by` FK nullable, `approved_date` date nullable. **evidence/hr_hires.csv**: `vendor_id`, `employee_start_date` date, `role`, `base_salary` int, `source_agency`, `hr_record_id` PK. **evidence/goods_receipts.csv**: `vendor_id`, `po_id` FK, `delivery_date` date, `description`, `received_by` FK, `receipt_id` PK. Unchanged from the first fixture set. Example: `V006,PO-1042,2026-12-25,2026-12,36,185.0,PENDING,,`.

**policies.json**: `policy_version` str, `close_cutoff_day` int, `allowed_methods` {method: required_evidence_key[]}, `historical_run_rate_limits` {`max_amount`, `max_variation_pct`}, `approval_thresholds` {`auto_max` 9999.99, `reviewer_max` 24999.99, `min_auto_confidence` 0.85}, `true_up_tolerance` {`abs` 500.0, `pct` 2.0}, `prior_period_controller_threshold` dec, `outreach_wait_hours` int, `learned_policies[]`. Required-evidence keys: `contract`, `service_period`, `usage_record`, `contract_rate`, `service_dates`, `purchase_order`, `service_receipt`, `prior_invoices_min_3`, and (v1.1 only) `pricing_schedule_effective`. v1.0 line that causes the December miss: `"FIXED_CONTRACT_FEE": ["contract", "service_period"]`.

**inbox/messages.jsonl**: `message_id` PK (`MSG-<outreach_id>-O` outbound, `-R` reply), `thread_id` = `outreach_id`, `obligation_id` FK, `direction` enum OUTBOUND/INBOUND, `from` str, `to` str, `target_role` enum (OPERATIONAL_OWNER, REQUESTER, AP_SPECIALIST, VENDOR_BILLING, ACCOUNTING_MANAGER, CONTROLLER), `missing_fact` enum (SERVICE_RECEIVED, SCOPE_OR_RATE_CHANGE, INVOICE_WHEREABOUTS, AP_STATUS, TREATMENT; these five are the scripted-reply match keys and must not be extended), `sent_at` ts (stamped by the simulator: send time for OUTBOUND, delivery time for INBOUND), `response_type` enum DATA/CONFIRMATION/CONFLICTING/DECISION nullable, `body` str, `structured_facts` object, `attachments[]` evidence_id. Silence produces no row.
```json
{"message_id": "MSG-OUT-V001-2026-12-01-R", "thread_id": "OUT-V001-2026-12-01", "obligation_id": "OBL-V001-2026-12", "direction": "INBOUND", "from": "billing@dataforge.example", "to": "close@northstar.example", "target_role": "VENDOR_BILLING", "missing_fact": "INVOICE_WHEREABOUTS", "sent_at": "2027-01-03T16:00:00", "response_type": "DATA", "body": "We are migrating billing systems, so December invoices will go out around Jan 11. Apologies for the delay.", "structured_facts": {"expected_issue_date": "2027-01-11"}, "attachments": []}
```

### 2.3 Canonical VendorObligation

One record per vendor per service month, id `OBL-<vendor_id>-<ym>`. Stored in the TrueUp state store, not under `runtime/visible/`. Steps refer to product spec section 5.

| Field | Type | Set by step |
|---|---|---|
| `obligation_id`, `vendor_id`, `legal_entity_id`, `service_period_start`, `service_period_end`, `close_period`, `category`, `cost_center` | str, FK, FK, date, date, ym, enum, FK | 1 Discover |
| `contract_id`, `po_id`, `expected_bill_date` | FK nullable, FK nullable, date | 1 Discover; date updated by 6 Outreach |
| `invoice_status` | enum RECEIVED, MISSING, MISMATCHED, DUPLICATE_SUSPECTED, NOT_EXPECTED | 2 Gather; 8 True-up |
| `service_received_status` | enum CONFIRMED, PARTIAL, UNCLEAR, NOT_RECEIVED | 2 Gather; 6 Outreach |
| `evidence_ids` | evidence_id[] (append only) | 2, 6, 8 |
| `classification` (extension) | enum VALID_INVOICE_MATCHES, INVOICE_MISMATCHED, NO_INVOICE_SERVICE_RECEIVED, NO_INVOICE_SERVICE_UNCLEAR, NO_INVOICE_SERVICE_NOT_RECEIVED, INVOICE_SPANS_PERIODS, NO_ACCRUAL_PREPAID | 3 Classify |
| `outcome` (extension) | enum nullable: CLOSE_READY, ACCRUED, RECONCILED, ESCALATED (the four product-spec outcomes) plus NO_ACCRUAL_DOCUMENTED. Truth `ACCRUED_THEN_RECONCILED` = ACCRUED at cutoff, RECONCILED after the invoice | 7 Work product; 8 True-up |
| `estimator_method` | enum FIXED_CONTRACT_FEE, USAGE_X_RATE, PRORATED_FEE, PO_BASED, HISTORICAL_RUN_RATE, ACTUAL_INVOICE, NONE | 4 Estimate |
| `estimated_amount` | dec nullable (from deterministic estimator only) | 4 Estimate |
| `confidence_score`, `risk_score` | float 0..1 | 4 Estimate, 5 Verify |
| `policy_version_used` | str | 5 Verify |
| `approval_history` | Approval[] | 5 Verify / 7 Work product |
| `outreach_history` | OutreachTask[] | 6 Outreach |
| `accrual_entry_id` | FK gl_entries.entry_id nullable | 7 Work product (after approval) |
| `invoice_id`, `true_up_amount`, `root_cause` | FK nullable, dec nullable, enum nullable (SCHEDULED_PRICE_CHANGE, TIERED_OVERAGE_RATE, SCOPE_CHANGE, USAGE_VARIANCE, PRORATION, ESTIMATE_JUDGMENT, TIMING_ONLY) | 8 True-up |
| `status` | enum DISCOVERED, IN_EVIDENCE_GATHERING, INVOICE_VALIDATED, ACCRUAL_CANDIDATE, PENDING_REVIEW, ACCRUED, INVOICE_RECEIVED, MATCHED, TRUE_UP_REQUIRED, RECONCILED, OUTREACH_PENDING, ESCALATED, HOLD_DO_NOT_POST | every step |

OBL-V001-2026-12 right after accrual (2027-01-05, policy 1.0). Times follow the evaluation harness schedule in section 3 (outreach at pass 1, reply 30 hours later, proposal at pass 3); the demo run in section 5 uses its own later send time:
```json
{"obligation_id": "OBL-V001-2026-12", "vendor_id": "V001", "legal_entity_id": "NS-US",
 "service_period_start": "2026-12-01", "service_period_end": "2026-12-31", "close_period": "2026-12",
 "category": "SAAS_OR_DATA", "cost_center": "CC-100", "contract_id": "CTR-001", "po_id": "PO-1029",
 "expected_bill_date": "2027-01-11", "invoice_status": "MISSING", "service_received_status": "CONFIRMED",
 "evidence_ids": ["CTR-001", "PO-1029", "SA-DATAFORGE-2026-12", "INV-V001-007", "MSG-OUT-V001-2026-12-01-R"],
 "classification": "NO_INVOICE_SERVICE_RECEIVED", "estimator_method": "FIXED_CONTRACT_FEE",
 "estimated_amount": 50000.00, "confidence_score": 0.91, "risk_score": 0.30,
 "accrual_entry_id": "JE-ACR-V001-2026-12", "invoice_id": null, "true_up_amount": null, "root_cause": null,
 "status": "ACCRUED", "outcome": "ACCRUED", "policy_version_used": "1.0",
 "approval_history": [{"approval_id": "APR-V001-2026-12-01", "obligation_id": "OBL-V001-2026-12", "proposal_id": "PRP-V001-2026-12-01", "level": "CONTROLLER", "approver_id": "E001", "decision": "APPROVED", "decided_at": "2027-01-05T17:30:00", "comment": "Agrees to order form and November invoice."}],
 "outreach_history": [{"outreach_id": "OUT-V001-2026-12-01", "obligation_id": "OBL-V001-2026-12", "target_role": "VENDOR_BILLING", "target": "billing@dataforge.example", "missing_fact": "INVOICE_WHEREABOUTS", "sent_at": "2027-01-02T10:00:00", "status": "ANSWERED", "response_message_id": "MSG-OUT-V001-2026-12-01-R", "responded_at": "2027-01-03T16:00:00"}]}
```
After reconciliation (2027-01-12). Only these fields change; the rest is identical:
```json
{"invoice_status": "RECEIVED", "invoice_id": "INV-V001-008", "true_up_amount": 2500.00,
 "root_cause": "SCHEDULED_PRICE_CHANGE", "status": "RECONCILED", "outcome": "RECONCILED",
 "evidence_ids": ["CTR-001", "PO-1029", "SA-DATAFORGE-2026-12", "INV-V001-007", "MSG-OUT-V001-2026-12-01-R", "INV-V001-008", "PS-001"]}
```
`policy_version_used` stays `"1.0"`: it records the version that governed the accrual. The accrual auto-reverses on 2027-01-01 (`JE-REV-V001-2026-12`). The invoice posts in 2027-01 as two entries that together credit 2000 Accounts Payable $52,500: `JE-INV-V001-008` Dr 6100 / Cr 2000 $50,000 (the accrued portion, `entry_type = INVOICE`) and `JE-TRU-V001-2026-12` Dr 6100 / Cr 2000 $2,500 (`entry_type = TRUE_UP`, dated 2027-01-12). Net January effect is +$2,500. When the true-up is $0 only the `JE-INV-` entry exists. $2,500 exceeds tolerance (greater of $500 or 2% of $50,000 = $1,000), so the path is INVOICE_RECEIVED -> TRUE_UP_REQUIRED -> RECONCILED.

### 2.4 Observable ContractFeatures

Extracted by the Evidence Agent from repository documents, one record per `contract_id`, re-extracted whenever a document with that `contract_id` is added. Stored in TrueUp state. Learned-policy scopes read only this record and the estimator method. Fields: `contract_id` PK, `vendor_id` FK nullable, `source_doc_ids[]`, `extracted_at` ts, `contract_type` enum (MSA_ORDER_FORM, LEASE, SOW_TM, ENGAGEMENT_LETTER, SERVICE_AGREEMENT), `pricing_structure` enum (FLAT, SCHEDULED_STEP, ANNIVERSARY_ESCALATOR, VENDOR_NOTIFIED_UPLIFT, COMMIT_PLUS_OVERAGE, PER_SEAT, TIME_AND_MATERIALS, CONTINGENT_FEE, PER_JOB), `billing_cadence` enum (MONTHLY_ARREARS, MONTHLY_ADVANCE, QUARTERLY_ARREARS, ANNUAL_ADVANCE, PER_EVENT), `has_scheduled_price_change` bool (true iff pricing_structure is SCHEDULED_STEP, ANNIVERSARY_ESCALATOR or VENDOR_NOTIFIED_UPLIFT), `has_pricing_exhibit` bool, `has_usage_component` bool, `termination_notice_on_file` bool, `termination_effective_date` date nullable, `term_start` date, `term_end` date, `auto_renews` bool, `notice_days` int, `order_form_fee` dec nullable, `citations[]` {`feature`, `doc_id`, `locator`, `quote`}.
```json
{"contract_id": "CTR-001", "vendor_id": "V001", "source_doc_ids": ["CTR-001", "PS-001"], "extracted_at": "2026-12-01T08:00:00",
 "contract_type": "MSA_ORDER_FORM", "pricing_structure": "ANNIVERSARY_ESCALATOR", "billing_cadence": "MONTHLY_ARREARS",
 "has_scheduled_price_change": true, "has_pricing_exhibit": true, "has_usage_component": false, "termination_notice_on_file": false, "termination_effective_date": null,
 "term_start": "2025-12-01", "term_end": "2027-11-30", "auto_renews": false, "notice_days": 30, "order_form_fee": 50000.00,
 "citations": [{"feature": "has_pricing_exhibit", "doc_id": "CTR-001", "locator": "s4.3", "quote": "Fees for each Contract Year are set out in the Pricing Schedule (Exhibit B)."},
               {"feature": "order_form_fee", "doc_id": "CTR-001", "locator": "Order Form", "quote": "$50,000.00 per month (Contract Year 1)"}]}
{"contract_id": "CTR-018", "vendor_id": "V018", "source_doc_ids": ["CTR-018", "PS-018"], "extracted_at": "2027-01-08T14:00:00",
 "contract_type": "MSA_ORDER_FORM", "pricing_structure": "SCHEDULED_STEP", "billing_cadence": "MONTHLY_ARREARS",
 "has_scheduled_price_change": true, "has_pricing_exhibit": true, "has_usage_component": false, "termination_notice_on_file": false, "termination_effective_date": null,
 "term_start": "2026-11-01", "term_end": "2027-12-31", "auto_renews": false, "notice_days": 30, "order_form_fee": 12000.00,
 "citations": [{"feature": "pricing_structure", "doc_id": "PS-018", "locator": "table row 2", "quote": "Production | 2027-01-01 | 2027-12-31 | $30,000.00"},
               {"feature": "order_form_fee", "doc_id": "CTR-018", "locator": "Order Form", "quote": "Pilot Fee $12,000.00 per month"}]}
```
Under v1.0 the features are extracted and stored but no rule reads `has_scheduled_price_change`. That is the procedure gap.

### 2.5 ActionProposal and verifier result (PolicyEvaluation)

ActionProposal fields: `proposal_id` PK (`PRP-<vendor>-<ym>-NN`), `obligation_id` FK, `action_type` enum (POST_ACCRUAL, MARK_CLOSE_READY, POST_INVOICE, ALLOCATE_INVOICE, POST_TRUE_UP, NO_ACCRUAL_DOCUMENTED, HOLD_INVOICE, SEND_OUTREACH, ESCALATE), `period` ym, `amount` dec nullable, `currency` str, `accounts` {`debit` FK, `credit` FK}, `entry_date` date, `reversal_date` date nullable, `calculation_method` enum (same as `estimator_method`), `calculation_trace` {`inputs` object, `formula` str, `result` dec} written by the estimator code, `evidence_ids[]`, `confidence` float, `policy_version` str, `proposed_by` str (agent name), `created_at` ts.
```json
{"proposal_id": "PRP-V001-2026-12-01", "obligation_id": "OBL-V001-2026-12", "action_type": "POST_ACCRUAL", "period": "2026-12",
 "amount": 50000.00, "currency": "USD", "accounts": {"debit": "6100", "credit": "2100"}, "entry_date": "2026-12-31", "reversal_date": "2027-01-01",
 "calculation_method": "FIXED_CONTRACT_FEE", "calculation_trace": {"inputs": {"monthly_fee": 50000.00, "fee_source": "CTR-001 Order Form", "months": 1}, "formula": "monthly_fee * months", "result": 50000.00},
 "evidence_ids": ["CTR-001", "PO-1029", "SA-DATAFORGE-2026-12"], "confidence": 0.91, "policy_version": "1.0", "proposed_by": "estimation_agent", "created_at": "2027-01-05T17:00:00"}
```
PolicyEvaluation fields: `evaluation_id` PK (`PE-<proposal suffix>`), `proposal_id` FK, `obligation_id` FK, `policy_version` str, `result` enum PASS/REVIEW_REQUIRED/OUTREACH_REQUIRED/BLOCK/ESCALATE, `checks[]` {`invariant` enum, `passed` bool, `source` str (`BASE` or a learned policy id), `detail` str}, `missing_evidence[]` required-evidence key, `required_approval_level` enum NONE/REVIEWER/CONTROLLER, `next_action` {`type`, `target_role`, `missing_fact`} nullable, `evaluated_at` ts. Invariants: ENTRY_BALANCES, PERIOD_OPEN, SERVICE_RECEIPT_SUPPORTED, REQUIRED_IDENTIFIERS, NO_DUPLICATE_ACCRUAL, ALLOWED_METHOD, EVIDENCE_TRACE_COMPLETE, ENTITY_ACCOUNT_COMPATIBLE, MATERIALITY_APPROVAL, UNCERTAINTY_CANNOT_POST, NO_SILENT_POLICY_WEAKENING, ACTION_TRACEABLE. Result precedence: ESCALATE > BLOCK > OUTREACH_REQUIRED > REVIEW_REQUIRED > PASS. For `pricing_schedule_effective`: the key is satisfied when `evidence_ids` holds a document that states the price effective for the service period. Accepted sources: a PRICING_SCHEDULE document (PS-001, PS-018), the `CTR-0NN` document when ContractFeatures cites an escalator clause that states the rate (Lumen CTR-004 footnote, 4%), or a VENDOR_NOTICE document (PagerLoop). BLOCK when such a document exists in `contracts/index.json` but is not in `evidence_ids` or the amount does not use it; OUTREACH_REQUIRED (`target_role` VENDOR_BILLING, `missing_fact` SCOPE_OR_RATE_CHANGE) when none exists (PagerLoop before the reply). If no reply is visible at cutoff the result becomes ESCALATE to the Controller.
```json
{"evaluation_id": "PE-V001-2026-12-01", "proposal_id": "PRP-V001-2026-12-01", "obligation_id": "OBL-V001-2026-12", "policy_version": "1.0", "result": "REVIEW_REQUIRED",
 "checks": [{"invariant": "EVIDENCE_TRACE_COMPLETE", "passed": true, "source": "BASE", "detail": "FIXED_CONTRACT_FEE requires contract, service_period; both attached"},
            {"invariant": "MATERIALITY_APPROVAL", "passed": false, "source": "BASE", "detail": "50000.00 >= 25000.00"}],
 "missing_evidence": [], "required_approval_level": "CONTROLLER", "next_action": {"type": "REQUEST_APPROVAL", "target_role": "CONTROLLER", "missing_fact": null}, "evaluated_at": "2027-01-05T17:00:05"}
{"evaluation_id": "PE-V018-2027-01-01", "proposal_id": "PRP-V018-2027-01-01", "obligation_id": "OBL-V018-2027-01", "policy_version": "1.1", "result": "BLOCK",
 "checks": [{"invariant": "EVIDENCE_TRACE_COMPLETE", "passed": false, "source": "POL-0001", "detail": "has_scheduled_price_change=true; PS-018 exists but is not attached"},
            {"invariant": "MATERIALITY_APPROVAL", "passed": false, "source": "BASE", "detail": "12000.00 >= 10000.00"}],
 "missing_evidence": ["pricing_schedule_effective"], "required_approval_level": "REVIEWER", "next_action": {"type": "ATTACH_EVIDENCE", "target_role": null, "missing_fact": null}, "evaluated_at": "2027-02-02T10:00:05"}
```
All 12 checks are always written; the examples show two each for brevity.

### 2.6 Entity relationships: how `obligation_id` flows

Source records never carry `obligation_id` (they come from outside TrueUp). Every TrueUp-created record does.

| Record | Id form | Key to obligation | Other foreign keys |
|---|---|---|---|
| VendorObligation | `OBL-V001-2026-12` | PK | vendor_id, contract_id, po_id, legal_entity_id, cost_center |
| EvidenceFact (extracted fact + citation) | `EVF-V001-2026-12-03` | `obligation_id` | `evidence_id` (source record), `doc locator` |
| ContractFeatures | `CTR-001` | via obligation.contract_id | source_doc_ids |
| ActionProposal | `PRP-V001-2026-12-01` | `obligation_id` | evidence_ids[], policy_version |
| PolicyEvaluation | `PE-V001-2026-12-01` | `obligation_id` | proposal_id, policy_version, learned policy ids |
| AccrualWorkpaper | `WP-V001-2026-12` | `obligation_id` | proposal_id, evaluation_id, evidence_ids[] |
| Approval | `APR-V001-2026-12-01` | `obligation_id` | proposal_id, approver_id |
| OutreachTask / OutreachResponse | `OUT-V001-2026-12-01` / `MSG-...-R` | `obligation_id` | target employee or vendor contact, message_id |
| JournalEntry (gl_entries rows, `posted_by=TRUEUP`) | `JE-ACR-V001-2026-12`, `JE-REV-...`, `JE-INV-V001-008`, `JE-TRU-V001-2026-12` | `obligation_id` column | proposal_id in `reference`, reversal_of |
| InvoiceMatch | `IM-INV-V001-008` | `obligation_id` (one row per obligation for multi-period invoices, with `allocated_amount`) | invoice_id, accrual_entry_id |
| TrueUpAdjustment (the confirmed outcome that starts learning) | `TU-V001-2026-12` | `obligation_id` | invoice_id, accrual_entry_id, true_up_entry_id `JE-TRU-V001-2026-12`, `amount` 2500.00, `within_tolerance` false |
| VarianceExplanation (FP&A; also the root-cause classification record) | `VE-V001-2026-12` | `obligation_id` | true_up_id, root_cause |
| CashForecastLine (Treasury) | `CF-V001-2026-12` | `obligation_id` | invoice_id nullable, `expected_amount`, `due_date` |
| AuditFinding | `AF-V001-2026-12-01` | `obligation_id` | any linked record id |
| Exception (non-obligation items, e.g. C07 duplicate 7731-R) | `EXC-INV-V012-004` | `obligation_id` of the original invoice's obligation (`OBL-V012-2026-11`) | invoice_id, duplicate_of |
| Policy candidate / Replay report / ReplayResult row / policy approval | `POL-0001` / `RPL-POL-0001` / `RPL-POL-0001-OBL-V001-2026-12` / `APR-POL-0001` | `source_obligation_ids[]` / `obligation_id` | policy_id, baseline and replay evaluation_ids |
