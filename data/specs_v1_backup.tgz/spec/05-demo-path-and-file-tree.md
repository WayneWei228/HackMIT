## 5. Three-minute demo path, fixture file tree and build delta

All paths are relative to the fixture root `data/northstar/` unless they start with `data/`.
Existing visible files keep their current relative paths (`gl_entries.csv`, `ap_queue.csv`, `vendors.json`, `invoices/invoices.json`, ...). Only new sources get new paths.

### Part A. Demo script (11 beats, 180 seconds)

Screens are the six product-spec screens: S1 Close Command Center, S2 Vendor Obligation Workpaper, S3 Outreach and Resolution Queue, S4 Invoice and True-Up View, S5 Learning and Controls View, S6 Audit Packet.

Rules for the run:
- The demo starts from checkpoint `CP-DEC` (November close already run, clock at `2027-01-04T09:00`). The presenter never runs November live.
- The demo is its own run with its own send times. The evaluation harness in section 3 sends the same DataForge outreach at pass 1 (2027-01-02T10:00). Replies are keyed to send time plus `delay_hours`, so both runs are valid; `CP-DEC` is built with no December outreach sent yet.
- Every clock stop is at 09:00 or later, so any event released on that calendar date is already visible.
- The December cutoff instant is `2027-01-05T23:59:59`; the January cutoff instant is `2027-02-05T23:59:59`.
- Dollar amounts on screen come from deterministic code. Model calls only interpret evidence, draft outreach, explain root cause and propose the policy.
- Fallback mode: `TRUEUP_DEMO_MODE=cached` makes the LLM client return the recorded response `runtime/demo_cache/beat-NN.json` for that beat. The cache file holds the exact typed output of a prior successful live run. Beats marked "none" make no model call.

| # | Sec | Sim clock | Screen | Records and files shown | Presenter says | Fallback |
|---|---|---|---|---|---|---|
| 1 | 12 | 2027-01-04T09:00 | S1 | Period 2026-12 inventory. Row `OBL-V001-2026-12` with `invoice_status = MISSING`, status `IN_EVIDENCE_GATHERING`, expected amount class "material". `ap_queue.csv` has no row for `INV-V001-008`. C01 OfficeNest row shows `CLOSE_READY`. | "It is day three of the December close and the DataForge bill, our largest data vendor, has not arrived." | none |
| 2 | 15 | 2027-01-04T09:00 | S2 | Evidence timeline for `OBL-V001-2026-12`: `contracts/CTR-001.pdf` (order form "$50,000.00 per month (Contract Year 1)"), `PO-1029`, `evidence/service_activity.csv` row V001/2026-12, invoice history `INV-V001-001`..`INV-V001-007` at $50,000, GL history on 6100. `erp/accrual_schedule_prior.csv` has no V001 rows: DataForge was never accrued in history. | "TrueUp built one obligation and pulled the contract, PO, service activity, seven prior invoices and the ledger by itself." | `beat-02.json` (extracted ContractFeatures and evidence citations) |
| 3 | 18 | 2027-01-04T09:00 | S2 | Calculation trace: method `FIXED_CONTRACT_FEE`, $50,000.00. Proposal `PRP-V001-2026-12-01`, draft entry `JE-ACR-V001-2026-12`: Dr 6100 / Cr 2100 $50,000, dated 2026-12-31, auto-reversal 2027-01-01. Verifier checklist under policy v1.0: contract attached PASS, service period evidenced PASS, result `REVIEW_REQUIRED`, approval level `CONTROLLER`. | "Policy version 1.0 asks for a contract and proof of service; both are attached, so the verifier passes it to the Controller at fifty thousand dollars." | none (estimator and verifier are deterministic) |
| 4 | 12 | 2027-01-04T09:05 | S3 | Uncertainty card: "Invoice normally received by day 2; none received; cutoff 2027-01-05." Missing fact `INVOICE_WHEREABOUTS`. Selected recipient Amira Khan, `billing@dataforge.example`, role `VENDOR_BILLING`. | "The only open question TrueUp sees is where the invoice is, so it picks the vendor billing contact, not the budget owner." | `beat-04.json` (recipient choice and reason) |
| 5 | 15 | send 2027-01-04T09:30, reply 2027-01-05T15:30 | S3 | Drafted request `OUT-V001-2026-12-01`, sent through `send_outreach` and shown as row `MSG-OUT-V001-2026-12-01-O` in `inbox/messages.jsonl`. Click "advance to reply". Reply `MSG-OUT-V001-2026-12-01-R` in the same file (scripted reply `RSP-008`, an id that never appears in the visible tree): "December invoices will go out around Jan 11", fact `expected_issue_date = 2027-01-11`. Next action stays `POST_ACCRUAL`. | "Billing answers thirty hours later: the invoice is late, not cancelled, so the accrual stands." | `beat-05.json` (drafted email text and reply interpretation); the reply itself is scripted data, not a model call |
| 6 | 12 | 2027-01-05T16:00 | S2 | Approval panel: amount $50,000 >= $25,000 so `CONTROLLER`. Decision `APPROVED` by E001 Dana Whitfield. `JE-ACR-V001-2026-12` posted to the simulated ledger. | "A human is asked only because the amount is material; Dana approves and December closes." | none |
| 7 | 12 | 2027-01-12T09:00 | S4 | Click "advance clock". Event `INVOICE_RECEIVED` materialises `INV-V001-008`, number DF-2256, dated 2026-12-31, $52,500.00, PDF `invoices/pdf/INV-V001-008.pdf`. | "A week later the real invoice lands: fifty-two thousand five hundred, not fifty thousand." | none |
| 8 | 22 | 2027-01-12T09:00 | S4 | Match `INV-V001-008` to `OBL-V001-2026-12`. True-up $2,500.00 (5.0%), over tolerance max($500, 2% = $1,000). `root_cause = SCHEDULED_PRICE_CHANGE`, process cause `PROCEDURE_GAP_REQUIRED_EVIDENCE`: `contracts/pricing_schedules/PS-001.pdf` (CY2 2026-12-01..2027-11-30 $52,500) was in the repository at close, and policy v1.0 did not require it. Outputs: AP-ready coding, cash due 2027-01-30, variance note, audit entry. | "The evidence was there at close; our procedure never required anyone to look at it, and that is what TrueUp names as the root cause." | `beat-08.json` (root-cause explanation with evidence ids); the $2,500 is deterministic |
| 9 | 25 | 2027-01-13T11:00 then 2027-01-15T10:00 | S5 | Candidate `POL-0001` `VERIFY_EFFECTIVE_CONTRACT_PRICE`, shown as data: scope `method = FIXED_CONTRACT_FEE AND has_scheduled_price_change = true`, adds required evidence `pricing_schedule_effective`. No vendor id in scope. Replay panel `RPL-POL-0001` over all 35 obligations of 2026-11 and 2026-12: fixed `OBL-V001-2026-12` ($50,000 to $52,500), regressions 0, touched list. Approval E001 on 2027-01-15, policy version 1.1 `PROVISIONAL`. | "TrueUp proposes a rule about contract features, not about DataForge, replays it on every past obligation with zero regressions, and only the Controller can switch it on." | `beat-09.json` (candidate policy JSON); replay is deterministic and runs live |
| 10 | 25 | 2027-02-05T09:00 then 2027-02-12T09:00 | S1 to S2 | `OBL-V018-2027-01` SignalStack, first time in AP (`VENDOR_ONBOARDED` 2027-01-08, `PO-1063`). Split view. Left, v1.0: $12,000 from `contracts/CTR-018.pdf` order form, corroborated by two `CARD_EXPENSE` GL rows. Right, v1.1: verifier `BLOCK` "pricing schedule effective for the service period not attached", agent attaches `contracts/pricing_schedules/PS-018.pdf` (Production 2027-01-01..2027-12-31 $30,000), accrual $30,000, `CONTROLLER` approval. Advance to 2027-02-12: `INV-V018-001` SS-10031 $30,000. Errors: -$18,000 vs $0. | "Here is a vendor TrueUp has never seen with a pilot-to-production step, not an anniversary percentage, and the learned rule blocks the twelve-thousand-dollar guess until the right schedule is attached." | `beat-10.json` (ContractFeatures for CTR-018 and the evidence-retrieval action); both dollar amounts are deterministic |
| 11 | 12 | 2027-02-12T12:00 | S5 then S6 | Held-out price-change rows, static v1.0 vs policy v1.1 absolute error: V018 $18,000 to $0, V001 Jan $2,500 to $0, V004 $720 to $0, V005 $352 to $0 after safe escalation to vendor billing (C12). Total $21,572 to $0. Regressions 0. Unsupported autonomous postings 0. Then the audit packet for `OBL-V018-2027-01`: evidence ids, policy version 1.1, verifier result, approval by E001. | "Twenty-one thousand dollars of held-out error goes to zero, nothing regressed, and every action carries its evidence, policy version and approver." | none (metrics read from the run log) |

Beat times sum to 180 (12+15+18+12+15+12+12+22+25+25+12).

Demo checkpoints (created by `data/simulate.py checkpoint`, restored by `data/simulate.py restore`):

| Checkpoint | Clock | State | Used when |
|---|---|---|---|
| `CP-DEC` | 2027-01-04T09:00 | November close complete under v1.0 | Demo start |
| `CP-REVEAL` | 2027-01-12T09:00 | December closed, `JE-ACR-V001-2026-12` posted, `INV-V001-008` visible | Beats 1-6 overran; jump to beat 7 |
| `CP-JAN` | 2027-02-05T09:00 | `POL-0001` active as v1.1, January obligations discovered | Beat 9 overran; jump to beat 10 |

### Part B. File tree

```
data/
  README.md                       data dictionary; rewritten after the build delta lands
  generate.py                     entry point: builds world/, then runs leak tests, exits non-zero on a leak
  simulate.py                     CLI over the section 3.6 API: init = reset(), advance --to = advance_to(), checkpoint, restore
  spec/                           these specification files (01..05)
  gen/
    __init__.py
    world.py                      company, employees, 19 vendors, fees, pricing schedules, termination, T0 constant
    features.py                   NEW. true ContractFeatures per contract; imported only by truth.py
    records.py                    invoices, POs, change orders, usage, seats, timesheets, hires, deliveries, service_activity
    ledger.py                     gl_entries (incl. CARD_EXPENSE), ap_queue, accrual_schedule_prior
    docs.py                       contract text, pricing schedules, notices, policy manual, policies.json, PDF rendering
    truth.py                      obligations truth, case rubrics, policy replay expectation, scripted inbox
    events.py                     NEW. splits every dated record at T0 into seed rows or events.jsonl rows
    simulator.py                  NEW. owns the clock; materialises released events and inbox replies into runtime/visible
    leakcheck.py                  NEW. static checks that seed and visible trees contain no private fact
  tests/
    test_leaks.py                 the L1-L10 tests of section 3.7; runs leakcheck against a fresh build and against runtime/visible at each snapshot
    test_demo_path.py             asserts every id, amount and date in Part A exists at the stated clock time
  northstar/
    world/
      seed/                       everything visible at T0 = 2026-12-01T00:00
        company.json              entities, cost centers, chart of accounts, close calendar
        org_directory.json        employees and vendor billing contacts (no V018 contact at T0)
        vendors.json              18 vendors at T0 (V001-V017, V019; V018 absent); spend_type, no pricing_model
        purchase_orders.json      POs issued before T0, incl. Beacon PO-0962 (PO-1063 absent)
        change_orders.json        change orders dated before T0 (CO-1 absent)
        policies.json             policy v1.0 as data
        close_policy_manual.md    policy v1.0 in prose
        gl_entries.csv            history 2026-05..2026-10 plus rows posted before T0, incl. SignalStack card entry JE-CARD-0001 of 2026-11-03
        ap_queue.csv              AP rows with received_date before T0
        erp/
          accrual_schedule_prior.csv   human team's accrual rollforward for 2026-05..2026-10
        contracts/
          CTR-001..CTR-017, CTR-019 (.pdf, .txt)   MSAs and order forms (CTR-018 absent at T0)
          pricing_schedules/
            PS-001.pdf, PS-001.txt     DataForge Exhibit B, doc_type PRICING_SCHEDULE
          notices/
            TN-019.pdf, TN-019.txt     Beacon termination notice sent 2026-11-14
          index.json                   one row per document, section 2 schema (doc_id, doc_type, contract_id, ..., filed_date, files[])
        invoices/
          invoices.json           invoices with received_date before T0
          pdf/                    one PDF per seed invoice
        evidence/
          usage_daily.csv         rows dated before T0
          seat_snapshots.csv      rows dated before T0
          timesheets.csv          rows with approval state as of T0
          hr_hires.csv            rows dated before T0
          goods_receipts.csv      rows dated before T0
          service_activity.csv    monthly platform activity per application, periods 2026-05..2026-10 (no SignalStack row in seed)
      private/                    never mounted into TrueUp
        events.jsonl              every fact after T0, one JSON object per line, sorted by release_at
        documents/                files that events copy into visible: contracts/ (CTR-018, PS-018), invoices/ (later invoice PDFs), inbox/ (PagerLoop notice)
        inbox/
          scripted_responses.json replies keyed by vendor_id + period + target_role + missing_fact, with delay_hours
        truth/                    file set and schemas are defined in section 4
          obligations_truth.csv   answer key, one row per obligation; features, rubric and expected agent results are JSON cells
          future_invoices.csv     every invoice received on or after 2026-12-01
          expected_matches.csv    correct invoice-to-obligation links with allocated dollars
          seeded_root_causes.json why each seeded miss happens
          extra_exceptions.json   PrintWorks duplicate, TalentBridge prior-period fee
          learning_proof/         TU-V001-2026-12, VE-V001-2026-12, POL-0001, RPL-POL-0001, APR-POL-0001 (one JSON each)
    runtime/                      git-ignored; created by simulate.py init
      sim_state.json              clock, released_event_ids, pending_deliveries (section 3.6); written only by the simulator
      outreach_log.jsonl          every send_outreach call; written only by the simulator
      visible/                    copy of world/seed plus materialised events; the only root TrueUp tools receive; read-only to TrueUp
        inbox/messages.jsonl      OUTBOUND and INBOUND rows, both written by the simulator (section 2 schema)
        inbox/attachments/        reply attachments copied from private/documents
      snapshots/                  2026-11-cutoff, 2026-12-cutoff, 2027-01-open, 2027-01-cutoff (copies of visible/, section 3.6)
      checkpoints/CP-DEC|CP-REVEAL|CP-JAN/   demo only: copy of sim_state.json, outreach_log.jsonl, visible/ and the TrueUp SQLite file
      demo_cache/beat-NN.json     recorded model outputs for fallback mode
```

`contracts/index.json` literal rows (section 2 schema; every `CTR-0NN` file has `doc_type = MSA`):

```json
{"doc_id": "PS-001", "doc_type": "PRICING_SCHEDULE", "contract_id": "CTR-001", "counterparty_name": "DataForge Inc.", "vendor_id": "V001", "title": "Exhibit B - Pricing Schedule", "effective_date": "2025-12-01", "filed_date": "2025-11-24", "filed_by": "E030", "files": ["contracts/pricing_schedules/PS-001.pdf", "contracts/pricing_schedules/PS-001.txt"], "supersedes": null}
{"doc_id": "TN-019", "doc_type": "TERMINATION_NOTICE", "contract_id": "CTR-019", "counterparty_name": "Beacon Survey Tools", "vendor_id": "V019", "title": "Notice of termination", "effective_date": "2026-12-15", "filed_date": "2026-11-14", "filed_by": "E013", "files": ["contracts/notices/TN-019.pdf", "contracts/notices/TN-019.txt"], "supersedes": null}
```

### Part C. Build delta (ordered checklist)

Steps 1-9 make the DataForge-to-SignalStack demo work. Steps 10-12 add the other planted cases. Steps 13-15 are background and hardening. Each step leaves `python3 data/generate.py` passing.

| # | Module | Change | Acceptance check |
|---|---|---|---|
| 1 | `generate.py` | Write to `northstar/world/seed/` and `northstar/world/private/`. Move `ground_truth/` to `world/private/truth/`. Move `inbox/scripted_responses.json` and `inbox/attachments/DOC-PAGERLOOP-UPLIFT-NOTICE.txt` to `world/private/inbox/` and `world/private/documents/`. Delete the stray `northstar/invoices 2/` folder on rebuild. Add `northstar/runtime/` to `.gitignore`. | `find world/seed -name '*truth*' -o -name 'scripted_responses.json'` returns nothing. |
| 2 | `world.py` | Add `T0 = datetime(2026, 12, 1, 0, 0)`. In `_v(...)` replace `pricing_model` with `spend_type` using the map below. Blank the `notes` field of V007. Keep the old fine-grained value in a module dict `PRICING_MODEL_TRUE` that only `truth.py` and `records.py` read. | `grep -c pricing_model world/seed/vendors.json` is 0; every vendor has `spend_type` in {SUBSCRIPTION, USAGE, SERVICES, RENT, OTHER}. |
| 3 | `world.py` | Add V018 SignalStack Inc. (6120, CC-190, owner E019, requester E019, CTR-018, PO-1063, billing contact "SignalStack Billing", `billing@signalstack.example`, Net 30, `onboarded_date = 2027-01-08`, `status = ACTIVE`). Add `onboarded_date` and `status` to every vendor. Add `PRICING_SCHEDULES = {"PS-001": [("2025-12-01","2026-11-30",50000.0),("2026-12-01","2027-11-30",52500.0)], "PS-018": [("2026-11-01","2026-12-31",12000.0),("2027-01-01","2027-12-31",30000.0)]}`. Add `FIXED_FEES["V018"] = [("2026-11",12000.0),("2027-01",30000.0)]`. | `len(VENDORS) == 19` after step 10; `PRICING_SCHEDULES["PS-001"][1][2] == FIXED_FEES["V001"][1][1]`. |
| 4 | `docs.py` | CTR-001 text: order form line "$50,000.00 per month (Contract Year 1)"; s4.3 "Fees for each Contract Year are set out in the Pricing Schedule (Exhibit B)"; remove any 5% wording from the MSA body. New `pricing_schedule_text(ps_id)` renders PS-001 and PS-018 as `.txt` and `.pdf`. CTR-018 text: order form "Pilot Fee $12,000.00 per month", same s4.3 sentence. Emit `contracts/index.json`. | `grep -c "52,500" CTR-001.txt` is 0 and `grep -c "52,500" PS-001.txt` is 1; `grep -c "30,000" CTR-018.txt` is 0. |
| 5 | `records.py` | `build_invoices()`: add V018 with `PREFIX["V018"] = "SS"`, one invoice only: `INV-V018-001`, number SS-10031, dated 2027-01-31, received 2027-02-12, $30,000, PO-1063. No V018 invoices for 2026-11 or 2026-12. `build_pos()`: add PO-1063, $360,000, `issued_date` 2027-01-08. Add `issued_date` to every PO. | Invoice count for V018 is 1; `INV-V001-008` unchanged (DF-2256, 2027-01-12, 52500.0). |
| 6 | `ledger.py` | `build_gl()`: add account 2050 Corporate Card Payable, the trailing `obligation_id` column and two balanced `CARD_EXPENSE` entries `JE-CARD-0001` and `JE-CARD-0002`: Dr 6120 / Cr 2050 (never touches 2000 AP), CC-190, `vendor_id` empty, references `CARD-4417-20261103` and `CARD-4417-20261202`, memo `Corp card x4417 (E019) SIGNALSTACK INC pilot fee Nov 2026` / `... Dec 2026`, $12,000 each, posting dates 2026-11-03 and 2026-12-02, `posted_by` `CARD_FEED`. `build_ap_queue()`: no V018 row before 2027-02-12. | GL still balances per `entry_id`; exactly 4 GL lines have `entry_type = CARD_EXPENSE`, all with blank `vendor_id` and memo containing `SIGNALSTACK`; every credit line is on 2050. |
| 7 | `records.py` | New `build_service_activity()` writing `evidence/service_activity.csv` with the section 2 columns (`activity_id, period, application, vendor_id, source_system, active_users, active_days, api_calls, first_activity_date, last_activity_date, service_status`). One row per application per month for V001, V004, V005, V009, V015, V018, V019. SignalStack rows exist from 2026-11; `vendor_id` is blank on the 2026-11 and 2026-12 rows and `V018` from 2027-01. | V001 has 9 rows (2026-05..2027-01); V019 2026-12 is PARTIAL with `last_activity_date` 2026-12-15 and 2027-01 is INACTIVE with zeros; example row `SA-DATAFORGE-2026-12,2026-12,DataForge Platform,V001,okta-sso+dataforge-admin-api,41,31,1284000,2026-12-01,2026-12-31,ACTIVE`. |
| 8 | `events.py` (new), `generate.py` | `split(records, date_field)` sends rows dated before `T0` to seed and the rest to `events.jsonl` in the section 3.4 schema (`event_id, event_type, release_at, record_id, vendor_id, period, target, op, key_field, payload, files, side_effects`). Event types: INVOICE_RECEIVED (invoice + ap_queue row + PDF), USAGE_EXPORT, EVIDENCE_UPDATE (seats, timesheets, hires, receipts, service_activity, GL rows posted after T0 incl. `JE-CARD-0002`), CONTRACT_DOC_ADDED (CTR-018, PS-018 at 2027-01-08), VENDOR_ONBOARDED (V018 vendor record and billing contact at 2027-01-08), PO_ISSUED (PO-1063, CO-1), PERIOD_STATUS_CHANGE (target `company.json`). Event ids are `EVT-` plus a five-digit sequence in `release_at` order. | Seed `invoices.json` max `received_date` < 2026-12-01; seed + events invoice count equals the pre-split count; no seed file contains the string `V018` or `SignalStack` except the 2026-11-03 card memo. |
| 9 | `simulator.py` (new), `simulate.py` | `init` copies seed to `runtime/visible/` and sets clock to T0. `advance --to ISO` appends every event with `release_at <= now` into the matching visible file, idempotently. `send_outreach` (section 3.5) appends the OUTBOUND row to `visible/inbox/messages.jsonl`, matches `world/private/inbox/scripted_responses.json` on (`vendor_id`, `period`, `target_role`, `missing_fact`), and appends the INBOUND row once `now >= sent_at + delay_hours`. No match means no reply. The clock never moves backward except through `restore`. `checkpoint NAME` and `restore NAME` as in Part A. | `test_demo_path.py`: at 2027-01-05T23:59:59 `INV-V001-008` is not visible; at 2027-01-12T09:00 it is; outreach sent 2027-01-04T09:30 yields `MSG-OUT-V001-2026-12-01-R` at 2027-01-05T15:30 and not one minute earlier; at 2027-02-05T23:59:59 `INV-V018-001` is not visible and `PS-018` is. |
| 10 | `world.py`, `docs.py`, `records.py` | Add V019 Beacon Survey Tools (6120, CC-130, owner E013, requester E013, CTR-019, PO-0962 ($45,600, 2026-04-01..2027-03-31, left `OPEN`), `accounts@beaconsurvey.example`, Net 30, invoice prefix `BS`, vendor `status` stays `ACTIVE`). `FIXED_FEES["V019"] = [("2025-04",3800.0)]`, `TERMINATION["V019"] = {"notice_id":"TN-019","sent":"2026-11-14","effective":"2026-12-15"}`. `docs.py` renders TN-019. Invoices: history and 2026-11 at $3,800 on time; final `INV-V019-008` (BS-2256) for 2026-12-01..2026-12-15 at $1,838.71, received 2027-01-07; none for 2027-01. | `round(3800*15/31, 2) == 1838.71` equals the invoice amount; no V019 invoice has a service period after 2026-12-15. |
| 11 | `ledger.py` | New `build_accrual_schedule_prior()` writing `erp/accrual_schedule_prior.csv` with the section 2 columns (`vendor_id, vendor_name, period, gl_account, cost_center, basis, accrued, actual, variance, invoice_number, invoice_received, je_ref, preparer, reviewer, note`). No rows for V001, V018 or V019. Derived from the same history accrual logic as `build_gl()` (including `HIST_ACCRUAL_OVERRIDE`), so the spreadsheet and the GL agree. Two planted conflicts live in the notes: the V002 rows say "accrue at commit, overage immaterial" (false for 2026-12), and the V011 2026-10 row shows `accrued = 0` with note "no fee expected" while `hr_hires.csv` shows an October hire. Preparer is E004 and reviewer E002 for all rows. | For every (vendor, period) in history, `accrued` equals the GL `ACCRUAL` credit to 2100; the V002 and V011 2026-10 notes are the only notes that conflict with evidence. Example: `V007,Meridian Legal LLP,2026-10,6210,CC-150,owner estimate,12000.0,12750.0,750.0,ML-2228,2026-11-20,ACR-V007-2026-10,E004,E002,Owner estimate low; final bill included filing fees`. |
| 12 | `truth.py`, `features.py` (new) | `features.py` holds true ContractFeatures for CTR-001..CTR-019. `truth.py`: obligations for V018 (2027-01 only) and V019 (2026-11, 2026-12, 2027-01). Add the section 4 columns `case_id` (C01-C12 or blank), `policy_enabled_estimate`, `true_contract_features`, `expected_safe_actions`, `frozen_agent_expected`, `policy_agent_expected`. Rename `root_cause` value `SCHEDULED_ESCALATOR` to `SCHEDULED_PRICE_CHANGE` and `CHANGE_ORDER_SEAT_EXPANSION` to `SCOPE_CHANGE`; the process cause `PROCEDURE_GAP_REQUIRED_EVIDENCE` lives in `seeded_root_causes.json`. Rows: `OBL-V018-2027-01` split `HELDOUT`, static 12000.0, policy-enabled 30000.0, true 30000.0; `OBL-V019-2026-12` method `PRORATED_FEE`, true 1838.71, static 1838.71, trailing 3800.0; `OBL-V019-2027-01` `needs_estimate = N`, true 0.0, static 0.0, trailing 3146.24 (v1.0 gets Beacon right; only the run-rate baseline fails). Write `future_invoices.csv`, `expected_matches.csv`, `seeded_root_causes.json` and the five `learning_proof/` files. Append new scripted replies after RSP-062 so ids RSP-001..RSP-062 do not change. | 12 distinct non-blank `case_id` values; obligation count is 54 (50 + 1 + 3); `learning_proof/replay_RPL-POL-0001.json` has one `touched` row (`OBL-V001-2026-12`, `IMPROVED`), `"improved": 1` and `"regressed": 0`. |
| 13 | `leakcheck.py` (new), `tests/test_leaks.py` | Checks: (a) no path under `world/seed` or `runtime/visible` contains `truth`, `private` or `scripted_responses`; (b) no visible JSON or CSV has a key named `pricing_model`, `pricing_structure`, `has_scheduled_price_change`, `split`, `scenario`, `root_cause`, `case_id` or `true_expense`; (c) no seed text file contains `52,500`, `52500` outside `contracts/pricing_schedules/PS-001.*`; (d) no seed file contains `30,000`/`30000` on a line mentioning SignalStack; (e) the rate `5.5` does not appear in any seed file mentioning PagerLoop; (f) `simulator.py` is the only module that opens `world/private`. `generate.py` runs (a)-(e) and exits 1 on failure. | `python3 data/generate.py` prints `leaks=0`; planting `"pricing_model"` in `vendors.json` makes the build fail. |
| 14 | `truth.py`, `records.py` | Background rows unchanged in substance: StreamGrid, Helpline change order, PayCircle mismatch, Thames wrong entity, SecureLayer prepaid, TalentBridge, Lumen. Only re-verify that their invoices, replies and evidence pass through the seed/event split with correct `release_at`. | For each background vendor, `true_expense`, `static_rules_estimate` and `actual_invoice_total` in the new truth file equal the values in the current `obligations_truth.csv`. |
| 15 | `README.md`, `simulate.py` | Rewrite the data dictionary for the three trees. Record `demo_cache/beat-02,04,05,08,09,10.json` from one clean live run. Create `CP-DEC`, `CP-REVEAL`, `CP-JAN`. | `TRUEUP_DEMO_MODE=cached` runs Part A end to end with the network off in under 180 seconds. |

`spend_type` map for step 2:

| spend_type | Vendors |
|---|---|
| SUBSCRIPTION | V001, V003, V004, V005, V009, V010, V015, V018, V019 |
| USAGE | V002, V013 |
| SERVICES | V006, V007, V011, V014 |
| RENT | V008, V017 |
| OTHER | V012, V016 |

Literal `vendors.json` record after step 3 (materialised by `VENDOR_ONBOARDED` on 2027-01-08, not in seed):

```json
{"vendor_id": "V018", "name": "SignalStack Inc.", "category": "SAAS_OR_DATA", "gl_account": "6120", "cost_center": "CC-190", "legal_entity_id": "NS-US", "operational_owner": "E019", "requester": "E019", "billing_contact": "SignalStack Billing", "billing_email": "billing@signalstack.example", "spend_type": "SUBSCRIPTION", "contract_id": "CTR-018", "po_id": "PO-1063", "payment_terms": "Net 30", "onboarded_date": "2027-01-08", "status": "ACTIVE", "notes": "Onboarded from corporate card to AP"}
```

Literal `events.jsonl` rows the demo depends on:

```json
{"event_id": "EVT-00045", "event_type": "VENDOR_ONBOARDED", "release_at": "2027-01-08T09:00:00", "record_id": "V018", "target": "vendors.json", "op": "UPSERT_RECORD", "key_field": "vendor_id"}
{"event_id": "EVT-00046", "event_type": "CONTRACT_DOC_ADDED", "release_at": "2027-01-08T10:00:00", "record_id": "PS-018", "target": "contracts/index.json", "op": "UPSERT_RECORD", "key_field": "doc_id"}
{"event_id": "EVT-00047", "event_type": "CONTRACT_DOC_ADDED", "release_at": "2027-01-08T10:00:00", "record_id": "CTR-018", "target": "contracts/index.json", "op": "UPSERT_RECORD", "key_field": "doc_id"}
{"event_id": "EVT-00048", "event_type": "PO_ISSUED", "release_at": "2027-01-08T11:00:00", "record_id": "PO-1063", "target": "purchase_orders.json", "op": "UPSERT_RECORD", "key_field": "po_id"}
{"event_id": "EVT-00052", "event_type": "INVOICE_RECEIVED", "release_at": "2027-01-12T09:00:00", "record_id": "INV-V001-008", "target": "invoices/invoices.json", "op": "UPSERT_RECORD", "key_field": "invoice_id"}
{"event_id": "EVT-00088", "event_type": "INVOICE_RECEIVED", "release_at": "2027-02-12T09:00:00", "record_id": "INV-V018-001", "target": "invoices/invoices.json", "op": "UPSERT_RECORD", "key_field": "invoice_id"}
```

Rows are abbreviated: `vendor_id`, `period`, `payload`, `files` and `side_effects` are as in section 3.4. The `EVT-` sequence numbers above are illustrative; the generator assigns them in `release_at` order. All other ids, amounts and dates are exact.
