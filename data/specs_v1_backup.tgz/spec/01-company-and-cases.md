## 1. Northstar company model and planted cases

Scope: the static company world that every other section builds on. Source of truth in code is `data/gen/world.py`; this section lists what stays, what is added, and what changes. Anything not mentioned here stays as it is today.

Terms used once and then assumed:
- **Accrual**: an expense booked at month-end for service received but not yet invoiced. It auto-reverses on day 1 of the next month.
- **True-up**: the difference between the later actual invoice and the accrual (`actual - accrued`).
- **Cutoff**: the last moment an invoice counts as "on hand" for a period.
- **In arrears / in advance**: invoiced after / before the service period.

### 1.1 Entities, departments and cost centers

| entity_id | name | country | currency |
|---|---|---|---|
| NS-US | Northstar Analytics, Inc. | US | USD |
| NS-UK | Northstar Analytics UK Ltd | GB | USD (books kept in USD; no FX anywhere) |

Cost centers are unchanged (13 rows). Each has exactly one budget owner. No new employees are needed.

| cost_center | department | budget owner | vendors charged here |
|---|---|---|---|
| CC-100 | Data Engineering | E010 Priya Raman | V001 |
| CC-110 | Platform / SRE | E011 Sam Okafor | V002, V005, V013 |
| CC-120 | Customer Support | E012 Maria Santos | V003 |
| CC-130 | Sales | E013 Jordan Blake | V004, **V019** |
| CC-140 | PMO | E014 Nina Petrov | V006 |
| CC-150 | Legal | E015 Rachel Kim | V007 |
| CC-160 | Workplace | E016 Omar Farouk | V008, V014 |
| CC-170 | People / HR | E017 Grace Liu | V009, V011 |
| CC-180 | Security | E018 Victor Hale | V010 |
| CC-190 | Marketing | E019 Elena Rossi | V012, **V018** |
| CC-200 | Business Intelligence | E020 Dev Patel | V015 |
| CC-210 | IT | E021 Chris Novak | V016 |
| CC-300 | UK Operations (NS-UK) | E022 Harriet Cole | V017 |

Requesters (the person who raised the PO) stay: E030 Ben Adler (V001), E031 Yuki Tanaka (V003), E032 Luis Moreno (V006). For every other vendor, including V018 and V019, `requester = operational_owner`.

### 1.2 Finance roles and who approves what

| employee_id | name | role tag | Does | Approves |
|---|---|---|---|---|
| E001 | Dana Whitfield | CONTROLLER | Signs off each close. Owns every ESCALATED item. | Accruals >= $25,000; all ESCALATE decisions; prior-period items >= $25,000; every learned policy |
| E002 | Marcus Oyelaran | ACCOUNTING_MANAGER | Reviews workpapers. | Accruals $10,000.00 to $24,999.99; any accrual with confidence < 0.85 under $25,000 |
| E003 | Sofia Brandt | AP_SPECIALIST | Owns the AP queue, mailbox, duplicate holds, vendor onboarding. | Nothing. Answers `AP_STATUS` outreach. Places and releases `HOLD_DO_NOT_POST`. |
| E004 | Ken Ito | CLOSE_ACCOUNTANT | Prepared all history accruals by hand (`posted_by = E004`). Preparer of `erp/accrual_schedule_prior.csv`. | Nothing. TrueUp takes over his preparer work from 2026-11. |
| E005 | Laila Haddad | FPA | Background only. | Nothing |
| E006 | Tom Reyes | TREASURY | Background only. | Nothing |

Rules: preparer and approver are never the same person. TrueUp is the preparer for 2026-11 onward and writes `posted_by = "TRUEUP"`. The enum for approval level is `NONE | REVIEWER | CONTROLLER`; `REVIEWER` always resolves to E002, `CONTROLLER` to E001.

### 1.3 Chart of accounts (15 rows: existing 14 plus one)

| account | name | type | used by |
|---|---|---|---|
| 1000 | Cash | asset | not posted to; kept for completeness |
| 1300 | Prepaid Expenses | asset | V010 annual prepaid, V015 January portion ($4,200) |
| 2000 | Accounts Payable | liability | credit side of every `INVOICE` entry |
| **2050** | **Corporate Card Payable** | liability | **new**; credit side of `CARD_EXPENSE` entries |
| 2100 | Accrued Expenses | liability | credit side of every `ACCRUAL` entry |
| 6100 | Data Services Expense | expense | V001 |
| 6110 | Cloud Hosting Expense | expense | V002, V013 |
| 6120 | Software Subscriptions | expense | V003, V004, V005, V009, V010, V015, V018, V019 |
| 6200 | Professional Services | expense | V006 |
| 6210 | Legal Fees | expense | V007 |
| 6300 | Rent and Facilities | expense | V008, V017 |
| 6310 | Facilities Maintenance | expense | V014 |
| 6400 | Recruiting Fees | expense | V011 |
| 6500 | Marketing Programs | expense | V012 |
| 6600 | Telecom | expense | V016 |

`gl_entries.csv` keeps its columns and gains one trailing column, `obligation_id` (blank on seed and card rows, required on every `TRUEUP` row). `entry_type` enum becomes: `INVOICE, ACCRUAL, ACCRUAL_CARRYFORWARD, ACCRUAL_REVERSAL, AMORTIZATION, CARD_EXPENSE, TRUE_UP`. `posted_by` is an employee id, `CARD_FEED` or `TRUEUP`.

**CARD_EXPENSE clearing approach.** A corporate-card charge is expensed directly: Dr expense / Cr 2050. It never touches 2000 Accounts Payable, has no invoice, no PO and an empty `vendor_id`. The only vendor clue is the merchant descriptor in `memo`. Settlement of 2050 against cash is not emitted (same as AP payments, which are also not emitted). The two SignalStack pilot entries, exact rows:

```csv
entry_id,line_no,posting_date,period,legal_entity_id,account,cost_center,vendor_id,debit,credit,entry_type,reference,memo,reversal_of,posted_by,obligation_id
JE-CARD-0001,1,2026-11-03,2026-11,NS-US,6120,CC-190,,12000.0,0.0,CARD_EXPENSE,CARD-4417-20261103,Corp card x4417 (E019) SIGNALSTACK INC pilot fee Nov 2026,,CARD_FEED,
JE-CARD-0001,2,2026-11-03,2026-11,NS-US,2050,CC-190,,0.0,12000.0,CARD_EXPENSE,CARD-4417-20261103,Corp card x4417 (E019) SIGNALSTACK INC pilot fee Nov 2026,,CARD_FEED,
JE-CARD-0002,1,2026-12-02,2026-12,NS-US,6120,CC-190,,12000.0,0.0,CARD_EXPENSE,CARD-4417-20261202,Corp card x4417 (E019) SIGNALSTACK INC pilot fee Dec 2026,,CARD_FEED,
JE-CARD-0002,2,2026-12-02,2026-12,NS-US,2050,CC-190,,0.0,12000.0,CARD_EXPENSE,CARD-4417-20261202,Corp card x4417 (E019) SIGNALSTACK INC pilot fee Dec 2026,,CARD_FEED,
```

JE-CARD-0001 is in the T0 seed. JE-CARD-0002 is a future fact released at `2026-12-02T09:00` (event type `EVIDENCE_UPDATE`, target `gl_entries.csv`). There is no card row for January: production service is invoiced. No SignalStack obligation exists for 2026-11 or 2026-12.

### 1.4 Close calendar and period statuses

Period status enum (field `company.json.close_calendar[].status`): `FUTURE` (month still running or not started; postings allowed), `OPEN` (month ended, TrueUp is closing it), `CLOSED` (Controller signed off; no postings allowed). Cutoff is `23:59:59` on the cutoff date. The period goes `CLOSED` at the cutoff instant; all approvals for the period happen on or before the cutoff date.

**Snapshot rule:** an invoice with `received_date` after the cutoff is never booked into the period just cut off. It is booked in the next period and matched to the accrual. This covers the Beacon invoice of 2027-01-07.

| period | type | OPEN from | cutoff date | CLOSED at | policy version in force at cutoff |
|---|---|---|---|---|---|
| 2026-05..2026-10 | history | n/a | n/a | CLOSED at T0 | human process |
| 2026-11 | warm-up | 2026-12-01T00:00 (= T0) | 2026-12-05 | 2026-12-05T23:59:59 | 1.0 |
| 2026-12 | the failure (TRAIN) | 2027-01-01T00:00 | 2027-01-05 | 2027-01-05T23:59:59 | 1.0 |
| 2027-01 | held-out | 2027-02-01T00:00 | 2027-02-05 | 2027-02-05T23:59:59 | 1.1 (learned arm) or 1.0 (frozen arm) |

Each `OPEN from` and `CLOSED at` cell is one `PERIOD_STATUS_CHANGE` event (six events in total; the first fires at T0 and is already applied in the seed). `company.json.close_calendar` at T0:

```json
[{"period":"2026-11","cutoff":"2026-12-05","status":"OPEN"},
 {"period":"2026-12","cutoff":"2027-01-05","status":"FUTURE"},
 {"period":"2027-01","cutoff":"2027-02-05","status":"FUTURE"}]
```

January reveal timeline (all between the December cutoff and the January cutoff):

| when | what |
|---|---|
| 2027-01-07 | Beacon final invoice INV-V019-008 received, $1,838.71 |
| 2027-01-08 | V018 vendor master record created (09:00); CTR-018 and PS-018 filed in the contract repository (10:00); PO-1063 issued ($360,000, 11:00) |
| 2027-01-12 | DataForge INV-V001-008 (DF-2256) received, $52,500; true-up +$2,500, outside tolerance ($1,000) |
| 2027-01-13 | POL-0001 candidate created and replay-tested over all 2026-11 and 2026-12 obligations |
| 2027-01-15 | E001 approves POL-0001; policy version 1.1 provisionally active |
| 2027-01-22 | Meridian INV-V007-006 received, $41,870 (accrued $40,000; +$1,870, outside tolerance of $800, explained as Controller judgement) |
| 2027-02-05 | January cutoff. Invoice missing for: V001, V002, V004, V005, V006, V011, V012, V013, V014, V018 |

### 1.5 Control policy v1.0 (compact)

| rule | value |
|---|---|
| Cutoff day | 5th of the following month |
| Auto-prepare with no human (`NONE`) | amount < $10,000 **and** confidence >= 0.85 |
| Reviewer approval (`REVIEWER`, E002) | $10,000.00 to $24,999.99, or confidence < 0.85 below $25,000 |
| Controller approval (`CONTROLLER`, E001) | amount >= $25,000; any verifier result `ESCALATE`; prior-period item >= $25,000 |
| Threshold basis | absolute accrual amount per obligation, USD |
| True-up tolerance | greater of $500 or 2% of the accrued amount; outside tolerance opens a root-cause review |
| Outreach wait | 48 hours, then next-best owner |
| Accrual reversal | auto-reverse on day 1 of the next period |
| Conflicting evidence or no allowed method | never post; `ESCALATE` to Controller |

Allowed estimation methods and the evidence each one requires in v1.0 (the DataForge gap is the first row):

| method | required evidence (v1.0) | limits |
|---|---|---|
| `FIXED_CONTRACT_FEE` | `contract`, `service_period` | none. **Does not require the pricing schedule.** |
| `USAGE_X_RATE` | `usage_record`, `contract_rate` | rate card must cover the usage tier |
| `PRORATED_FEE` | `contract`, `service_dates` | day-count basis: actual days in month |
| `PO_BASED` | `purchase_order`, `service_receipt` | estimate <= remaining PO balance |
| `HISTORICAL_RUN_RATE` | `prior_invoices_min_3` | amount <= $10,000 and variation <= 10%; confidence capped at 0.70 |

Version 1.1 = version 1.0 plus POL-0001. Nothing else changes.

### 1.6 Vendor master: 19 vendors

`vendors.json` columns after the change: `vendor_id, name, category, spend_type, gl_account, cost_center, legal_entity_id, operational_owner, requester, billing_contact, billing_email, contract_id, po_id, payment_terms, onboarded_date, status, notes`. `status` enum is `ACTIVE | TERMINATED`; every vendor, including V019, is `ACTIVE` in all three periods (procurement never updated Beacon, the same deliberate conflict as the open PO-0962). The `pricing_model` column is **deleted**. `spend_type` enum: `SUBSCRIPTION | USAGE | SERVICES | RENT | OTHER`. `onboarded_date` is new (ISO date). V018 is absent from the seed `vendors.json` and appears through a `VENDOR_ONBOARDED` event on 2027-01-08.

In the table below, **cadence** and **typical monthly** are design facts for the generator and the truth tree only. They are never written to `vendors.json`.

| vendor_id | name | sells | spend_type | entity | CC | owner | GL | cadence (truth only) | contract | PO | typical monthly (truth only) | role in dataset |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| V001 | DataForge Inc. | market data feed | SUBSCRIPTION | NS-US | CC-100 | E010 | 6100 | monthly, arrears; on time in history and 2026-11, ~11 days late for 2026-12 and 2027-01 | CTR-001 + PS-001 | PO-1029 | $50,000 then $52,500 from 2026-12 | **C03** train; Jan precedent |
| V002 | CloudHarbor LLC | cloud compute | USAGE | NS-US | CC-110 | E011 | 6110 | monthly, arrears | CTR-002 | PO-1011 | $36,000 + overage | **C05** |
| V003 | Helpline Desk Co. | support desk seats | SUBSCRIPTION | NS-US | CC-120 | E012 | 6120 | monthly, arrears | CTR-003 | PO-1017 | $10,200 (120 x $85) | background: change order CO-1 |
| V004 | Lumen CRM Corp. | CRM | SUBSCRIPTION | NS-US | CC-130 | E013 | 6120 | monthly, arrears | CTR-004 | PO-1008 | $18,000 then $18,720 | held-out extra (footnote uplift) |
| V005 | PagerLoop Inc. | on-call alerting | SUBSCRIPTION | NS-US | CC-110 | E011 | 6120 | monthly, arrears | CTR-005 | PO-1021 | $6,400 then $6,752 | **C12** |
| V006 | Brightwork Consulting Group | PMO consulting, T&M | SERVICES | NS-US | CC-140 | E014 | 6200 | monthly, arrears, ~15 days late | CTR-006 | PO-1042 | $17,760 to $29,600 | **C09** |
| V007 | Meridian Legal LLP | outside counsel | SERVICES | NS-US | CC-150 | E015 | 6210 | irregular | CTR-007 (engagement letter) | none | $4,100 to $41,870 | **C10** |
| V008 | OfficeNest Properties | HQ rent | RENT | NS-US | CC-160 | E016 | 6300 | monthly, advance | CTR-008 | none | $22,500 | **C01** |
| V009 | PayCircle Inc. | payroll SaaS | SUBSCRIPTION | NS-US | CC-170 | E017 | 6120 | monthly, arrears | CTR-009 | PO-1005 | $4,150 | background: $830 mismatch |
| V010 | SecureLayer Systems | security platform | SUBSCRIPTION | NS-US | CC-180 | E018 | 6120 | annual prepaid | CTR-010 | PO-1033 | $8,000 amortization | background: not an accrual |
| V011 | TalentBridge Partners | contingent recruiting | SERVICES | NS-US | CC-170 | E017 | 6400 | per hire | CTR-011 | none | $0 or 20% of salary | background: unaccrued Oct fee |
| V012 | PrintWorks Studio | print jobs | OTHER | NS-US | CC-190 | E019 | 6500 | per job, one PO per job | CTR-012 | PO-0977, PO-1002, PO-1046, PO-1058 | $0 to $7,850 | **C07** |
| V013 | StreamGrid Networks | CDN egress | USAGE | NS-US | CC-110 | E011 | 6110 | monthly, arrears | CTR-013 | PO-1014 | $8,000 + overage | background: tiered overage |
| V014 | Atlas Facilities Services | janitorial and maintenance | SERVICES | NS-US | CC-160 | E016 | 6310 | quarterly, arrears | CTR-014 | PO-1019 | $4,500 | **C02** |
| V015 | Quantive BI Ltd. | BI tool | SUBSCRIPTION | NS-US | CC-200 | E020 | 6120 | monthly, advance, from the 15th | CTR-015 | PO-1051 | $9,300 | **C08** |
| V016 | Northwind Telecom | voice and internet | OTHER | NS-US | CC-210 | E021 | 6600 | monthly, arrears | CTR-016 | none | $5,350 to $5,520 | **C11** |
| V017 | Thames Workspace Ltd | UK office | RENT | NS-UK | CC-300 | E022 | 6300 | monthly, arrears | CTR-017 | none | $6,900 | background: wrong entity |
| **V018** | **SignalStack Inc.** | product analytics SaaS | SUBSCRIPTION | NS-US | CC-190 | E019 | 6120 | pilot by card; production monthly, arrears | CTR-018 + PS-018 | PO-1063 (2027-01-08) | $12,000 pilot, $30,000 production | **C04** held-out transfer |
| **V019** | **Beacon Survey Tools** | survey SaaS | SUBSCRIPTION | NS-US | CC-130 | E013 | 6120 | monthly, arrears | CTR-019 + TN-019 | PO-0962 | $3,800 | **C06** |

New vendor master records, literal:

```json
{"vendor_id":"V018","name":"SignalStack Inc.","category":"SAAS_OR_DATA","spend_type":"SUBSCRIPTION","gl_account":"6120","cost_center":"CC-190","legal_entity_id":"NS-US","operational_owner":"E019","requester":"E019","billing_contact":"SignalStack Billing","billing_email":"billing@signalstack.example","contract_id":"CTR-018","po_id":"PO-1063","payment_terms":"Net 30","onboarded_date":"2027-01-08","status":"ACTIVE","notes":"Onboarded from corporate card to AP"}
{"vendor_id":"V019","name":"Beacon Survey Tools","category":"SAAS_OR_DATA","spend_type":"SUBSCRIPTION","gl_account":"6120","cost_center":"CC-130","legal_entity_id":"NS-US","operational_owner":"E013","requester":"E013","billing_contact":"Beacon Accounts","billing_email":"accounts@beaconsurvey.example","contract_id":"CTR-019","po_id":"PO-0962","payment_terms":"Net 30","onboarded_date":"2025-03-18","status":"ACTIVE","notes":""}
```

New POs: `PO-1063` V018, blanket, $360,000, issued 2027-01-08, covers 2027-01-01..2027-12-31 (released by a `PO_ISSUED` event). `PO-0962` V019, blanket, $45,600 (12 x $3,800), issued 2026-03-20, covers 2026-04-01..2027-03-31, status `OPEN` and never closed. The open PO is deliberate: it conflicts with TN-019.

Invoice number prefixes for the new vendors: V018 `SS`, V019 `BS`. Beacon invoices: INV-V019-001..006 for history, INV-V019-007 for 2026-11 (BS-2249, dated 2026-11-30, received 2026-12-03, $3,800), INV-V019-008 final (BS-2256, dated 2026-12-31, received 2027-01-07, service 2026-12-01..2026-12-15, $1,838.71).

### 1.7 The twelve planted cases

Obligation key format everywhere: `OBL-{vendor_id}-{period}`. "Frozen" means the v1.0 agent with no learned policy. Spec required-case names are quoted from the product spec section "Required cases"; SC-16 is success criterion 16 ("improves or safely escalates a held-out future case").

| case | obligation | what is planted | files that carry the conflict | expected TrueUp behaviour | spec required case |
|---|---|---|---|---|---|
| C01 | OBL-V008-2026-11, -12, -2027-01 | Rent $22,500, invoiced in advance (ON-2249 received 2026-10-25, ON-2256 2026-11-25, ON-2263 2026-12-25). | none. Invoice, contract CTR-008 and AP row agree. | Match invoice to contract. `ACTUAL_INVOICE`, verifier `PASS`, outcome `CLOSE_READY`. No accrual, no outreach, approval `NONE`. | Exact recurring invoice match |
| C02 | OBL-V014-2026-11 (also -12, -2027-01) | $4,500/month. One quarterly invoice for Nov to Jan arrives 2027-02-08, so all three cutoffs have no invoice. | CTR-014 (quarterly in arrears) vs AP queue (no row) vs `accrual_schedule_prior.csv` (E004 accrued $4,500 monthly with zero variance). | `FIXED_CONTRACT_FEE` $4,500, confidence >= 0.85, approval `NONE`, outcome `ACCRUED`. Dr 6310 / Cr 2100. On 2027-02-08 split the $13,500 invoice three ways; true-up $0 each. | Missing invoice, high-confidence fixed contract |
| C03 | OBL-V001-2026-12 (TRAIN) | Order form says $50,000 "(Contract Year 1)". PS-001 says CY2 from 2026-12-01 is $52,500. v1.0 does not require the pricing schedule. | `contracts/CTR-001` order form vs `contracts/pricing_schedules/PS-001`; PO-1029 and six history invoices all say $50,000. | Outreach to VENDOR_BILLING about timing only (reply after 30 h: invoices go out around Jan 11). Accrue $50,000 Dr 6100 / Cr 2100 dated 2026-12-31, approval `CONTROLLER`, reverse 2027-01-01. On 2027-01-12 match DF-2256, true-up +$2,500, outside tolerance, `root_cause = SCHEDULED_PRICE_CHANGE` with process cause `PROCEDURE_GAP_REQUIRED_EVIDENCE`, propose POL-0001. | DataForge 5% escalator |
| C04 | OBL-V018-2027-01 (HELDOUT) | Order form "Pilot Fee $12,000.00 per month". PS-018: production $30,000 from 2027-01-01. Two $12,000 card charges corroborate the wrong number. Invoice SS-10031 arrives 2027-02-12. | `contracts/CTR-018` order form + GL `CARD_EXPENSE` rows vs `contracts/pricing_schedules/PS-018` + PO-1063 ($360,000 = 12 x $30,000). | Frozen: accrues $12,000, approval `REVIEWER`, error -$18,000. With POL-0001: features show `has_scheduled_price_change = true`, verifier returns `BLOCK` (PS-018 is in the repository but not attached) until PS-018 is attached, then `FIXED_CONTRACT_FEE` $30,000, approval `CONTROLLER`. Dr 6120 / Cr 2100. True-up $0. | SC-16, improves |
| C05 | OBL-V002-2026-12 | 352,000 hours. Correct: $36,000 + 52,000 x $0.15 = $43,800. Shortcut 352,000 x $0.12 = $42,240. Invoice CH-2256 arrives 2027-01-08. | `evidence/usage_daily.csv` vs CTR-002 rate card (commit, included hours, overage rate in separate clauses); prior schedule shows flat $36,000 for six months. | `USAGE_X_RATE` with tiered rate, $43,800, approval `CONTROLLER`, `ACCRUED`. True-up $0. Never uses run rate. | extra (usage-based spend) |
| C06 | OBL-V019-2026-12 and OBL-V019-2027-01 | Service ends 2026-12-15. Final invoice $1,838.71 arrives 2027-01-07. Run rate says $3,800 for both months. | `contracts/notices/TN-019` vs open PO-0962 (through 2027-03-31), vendor master `status = ACTIVE`, seven straight $3,800 invoices, `service_activity.csv` (activity stops 2026-12-15). | Dec: `PRORATED_FEE` 3,800 x 15/31 = $1,838.71, approval `NONE`, `ACCRUED`; true-up $0. Jan: classification `NO_INVOICE_SERVICE_NOT_RECEIVED`, outcome `NO_ACCRUAL_DOCUMENTED`, reason cites TN-019. | extra (termination) |
| C07 | exception on OBL-V012-2026-11 | Invoice 7731 ($7,850, received 2026-12-01) re-sent as 7731-R, dated 2026-12-17, received 2026-12-18. Same PO-1046, amount, service period. | `invoices/` and `ap_queue.csv` hold both; `goods_receipts.csv` has one receipt for PO-1046; PO balance covers one. | 7731: `CLOSE_READY`. 7731-R: `invoice_status = DUPLICATE_SUSPECTED`, exception `EXC-INV-V012-004`, verifier `BLOCK`, status `HOLD_DO_NOT_POST`, notify E003. No second expense, no accrual in December. | Duplicate invoice |
| C08 | OBL-V015-2026-12 and OBL-V015-2027-01 | INV-V015-001 $9,300 covers 2026-12-15..2027-01-14. AP coded the full amount to December. | invoice service period vs `ap_queue.csv` coding (`period = 2026-12`, full $9,300 to 6120). | Allocate by days: 17/31 x 9,300 = $5,100 to December, $4,200 to 1300 Prepaid then January. Flag AP coding, approval `NONE`, `CLOSE_READY` with allocation. January expense = $4,200 + $5,100 (from QB-2214) = $9,300. | Multi-period invoice |
| C09 | OBL-V006-2026-12 | T&M $185/hour. 142 hours = $26,270. Last two weekly timesheets (weeks ending 2026-12-18 and 2026-12-25, 38 + 36 hours) are `PENDING`, not `APPROVED`. Invoice BW-2221 arrives 2027-01-15. | `evidence/timesheets.csv` approved hours (68) vs all logged hours (142); PO-1042 balance. | Verifier `OUTREACH_REQUIRED`, fact `SERVICE_RECEIVED`, target OPERATIONAL_OWNER E014 (reply after 20 h confirms 142 h). Then `USAGE_X_RATE` (142 h x $185) $26,270, approval `CONTROLLER`, `ACCRUED`. True-up $0. | Missing service confirmation |
| C10 | OBL-V007-2026-12 | Owner E015 says $35,000 to $45,000. Vendor WIP report says $58,000 before write-downs. No PO, no rate card, history too volatile for run rate. | inbox reply from E015 vs inbox reply from Meridian billing; CTR-007 engagement letter has no cap. | No amount from TrueUp. Verifier `ESCALATE`, outcome `ESCALATED` to E001 with both figures and sources. Controller decides $40,000; TrueUp records it with `estimator_method = NONE` and the Controller reply (`response_type = DECISION`) as evidence, Dr 6210 / Cr 2100. Invoice $41,870 on 2027-01-22; true-up +$1,870. | Unknown/conflicting evidence |
| C11 | OBL-V016-2026-11 | NT-2249 $5,480, dated 2026-11-30, was sent to retired mailbox `ap-old@northstar.example`. Without outreach it surfaces 2026-12-09, after cutoff. | `ap_queue.csv` (no row) vs vendor reply (invoice sent 2026-11-30, PDF attached). | Outreach VENDOR_BILLING, fact `INVOICE_WHEREABOUTS` (reply after 5 h with the invoice). Book the actual $5,480, `ACTUAL_INVOICE`, `CLOSE_READY`. No estimate. Tell E003 about the mailbox. | Missing invoice response from vendor |
| C12 | OBL-V005-2027-01 (HELDOUT) | CTR-005 allows an annual uplift "as notified by vendor". The rate is in no internal file. Actual 5.5%: $6,400 to $6,752. Invoice PL-2263 arrives 2027-02-09. | CTR-005 clause vs PO-1021 and history ($6,400); no pricing schedule exists. | Frozen: accrues $6,400, error -$352. With POL-0001: `has_scheduled_price_change = true`, evidence missing, `OUTREACH_REQUIRED` to VENDOR_BILLING, fact `SCOPE_OR_RATE_CHANGE` (reply after 9 h: 5.5%). Then $6,752, approval `NONE`. If no reply by cutoff: `ESCALATED` to E001 (the Controller owns every escalation), never a silent $6,400. | SC-16, safely escalates |

Coverage check: all eight spec required cases are hit (C01, C02, C03, C07, C08, C09, C10, C11). C04 and C12 cover success criterion 16. C05 and C06 are extra coverage for the usage and prorated methods. Background scenarios (V003, V004, V009, V010, V011, V013, V017, and DataForge January) keep their existing rows and carry `case_id = ""` in the truth tree.
