## 3. Three close periods, visibility timing and leakage prevention

Terms. **Cutoff**: the last moment an invoice counts as "received in time" for a period's close. **Accrual**: an estimated expense booked because the invoice is missing at cutoff. **True-up**: actual invoice minus accrual, computed when the invoice lands.

### 3.1 Clock conventions

| Item | Rule |
|---|---|
| Timestamp format | Naive company-local ISO 8601, `YYYY-MM-DDTHH:MM:SS`. No time zones anywhere. |
| T0 | `2026-12-01T00:00:00`. T_END = `2027-02-15T23:59:59` (last background invoice, Brightwork Jan, lands 2027-02-15). |
| Cutoff instant | `23:59:59` on the cutoff date. A record released on the cutoff date is on time. |
| Seed rule | Generator gives every record a `release_at`. `release_at <= T0` goes to `world/seed/`; everything else becomes one line in `world/private/events.jsonl`. |
| Default release time | INVOICE_RECEIVED 09:00; USAGE_EXPORT and monthly `service_activity` 06:00 on the 1st of the next month; VENDOR_ONBOARDED 09:00, CONTRACT_DOC_ADDED 10:00, PO_ISSUED 11:00; PERIOD_STATUS_CHANGE 00:00:00 on day 1 of the next month (OPEN) and 23:59:59 on the cutoff date (CLOSED). |
| Period status | `FUTURE -> OPEN -> CLOSED`, stored in `company.json.close_calendar[].status`. At T0: 2026-05..2026-10 CLOSED (`closed_periods`), 2026-11 OPEN, 2026-12 and 2027-01 FUTURE. |
| Harness passes per close | P1 = day 2 at 10:00 (detect, send outreach). P2 = day 4 at 10:00 (read replies, escalate). P3 = day 5 at 17:00 (final actions, propose entries). All outreach times below assume this schedule. |

Source column in the timeline: **W** = line in `events.jsonl`, **I** = triggered inbox reply, **T** = TrueUp or harness action (never in `events.jsonl`; shown for ordering only).

### 3.2 Master timeline

| When | Src | Event type | Record id | What becomes visible | Case |
|---|---|---|---|---|---|
| T0 | seed | SEED | - | GL history 2026-05..10; invoices received <= 2026-11-30 incl. INV-V008-007 (Nov rent), INV-V008-008 (Dec rent, received 2026-11-25), INV-V014-002 (Aug-Oct); CTR-001..017, CTR-019; PS-001; TN-019 (filed 2026-11-14); GL `JE-CARD-0001` CARD_EXPENSE $12,000 posted 2026-11-03; `erp/accrual_schedule_prior.csv` (2026-05..10); usage and service_activity through 2026-10 | all |
| 2026-12-01 06:00 | W | USAGE_EXPORT | USG-V002-2026-11 | CloudHarbor Nov daily rows, 296,000 h | C05 |
| 2026-12-01 06:00 | W | EVIDENCE_UPDATE | SVC-2026-11 | `service_activity` Nov rows (V001, V004, V005, V009, V019, plus `SA-SIGNALSTACK-2026-11` with blank `vendor_id`) | C03 C06 |
| 2026-12-01 09:00 | W | INVOICE_RECEIVED | INV-V012-003 | PrintWorks 7731, $7,850 | C07 |
| 2026-12-02 09:00 | W | INVOICE_RECEIVED | INV-V001-007 | DataForge DF-2249, $50,000 (CY1 rate) | C03 |
| 2026-12-02 09:00 | W | EVIDENCE_UPDATE | JE-CARD-0002 | GL CARD_EXPENSE $12,000, Dr 6120 / Cr 2050, memo contains `SIGNALSTACK INC`, `vendor_id` blank | C04 |
| 2026-12-02 10:00 | T | OUTREACH_SENT | - | P1 requests, incl. V016 VENDOR_BILLING INVOICE_WHEREABOUTS | C11 |
| 2026-12-02 15:00 | I | INBOX_REPLY | V016/2026-11 | Northwind reply (+5 h); early-releases INV-V016-007 NT-2249 $5,480 | C11 |
| 2026-12-03 09:00 | W | INVOICE_RECEIVED | INV-V019-007 | Beacon BS-2249, $3,800 (November, full month) | C06 |
| 2026-12-04 09:00 | W | INVOICE_RECEIVED | INV-V005-007 | PagerLoop Nov, $6,400 | C12 |
| 2026-12-05 23:59:59 | W | PERIOD_STATUS_CHANGE | PER-2026-11 | 2026-11 CLOSED; snapshot `2026-11-cutoff` | - |
| 2026-12-08 09:00 | W | INVOICE_RECEIVED | INV-V002-007 | CloudHarbor Nov, $36,000 | C05 |
| 2026-12-09 09:00 | W | INVOICE_RECEIVED | INV-V016-007 | Fallback only; skipped if already early-released | C11 |
| 2026-12-16 09:00 | W | INVOICE_RECEIVED | INV-V015-001 | Quantive $9,300, service 2026-12-15..2027-01-14 | C08 |
| 2026-12-18 09:00 | W | INVOICE_RECEIVED | INV-V012-004 | PrintWorks 7731-R, $7,850, note "Statement copy" | C07 |
| 2026-12-19, 12-26 09:00 | W | EVIDENCE_UPDATE | TS-V006-2026-12-18, TS-V006-2026-12-25 | Brightwork timesheets, `approval_status=PENDING` | C09 |
| 2026-12-25 09:00 | W | INVOICE_RECEIVED | INV-V008-009 | OfficeNest Jan rent $22,500 | C01 |
| 2027-01-01 00:00 | W | PERIOD_STATUS_CHANGE | PER-2026-12 | 2026-12 OPEN | - |
| 2027-01-01 06:00 | W | USAGE_EXPORT | USG-V002-2026-12 | CloudHarbor Dec, 352,000 h | C05 |
| 2027-01-01 06:00 | W | EVIDENCE_UPDATE | SVC-2026-12 | service_activity Dec: V001 active 31 days; V019 PARTIAL, `last_activity_date=2026-12-15`; SignalStack row still with blank `vendor_id` | C03 C06 |
| 2027-01-02 10:00 | T | OUTREACH_SENT | - | P1 requests for V001, V006, V007 | C03 C09 C10 |
| 2027-01-02 16:00 | I | INBOX_REPLY | V006/REQUESTER | E032: 142 h, two sheets unapproved (+6 h) | C09 |
| 2027-01-02 20:00 | I | INBOX_REPLY | V007/OPERATIONAL_OWNER | E015: $35-45k (+10 h) | C10 |
| 2027-01-03 06:00 | I | INBOX_REPLY | V006/OPERATIONAL_OWNER | E014 confirms 142 h (+20 h); early-releases timesheet patch to APPROVED | C09 |
| 2027-01-03 12:00 | I | INBOX_REPLY | V007/VENDOR_BILLING | WIP $58,000 before write-downs (+26 h) | C10 |
| 2027-01-03 16:00 | I | INBOX_REPLY | V001/VENDOR_BILLING | Timing only: invoices go out around Jan 11 (+30 h). No amount | C03 |
| 2027-01-04 10:00 / 14:00 | T / I | OUTREACH_SENT / INBOX_REPLY | V007/CONTROLLER | Escalation; E001 decides $40,000 (+4 h) | C10 |
| 2027-01-05 17:00 | T | ENTRIES_PROPOSED | - | Accruals dated 2026-12-31, reversal 2027-01-01: V001 $50,000 (Controller), V002 $43,800, V014 $4,500, V019 $1,838.71, V006 $26,270, V007 $40,000; V015 $5,100 expense + $4,200 prepaid; INV-V012-004 HOLD_DO_NOT_POST | C02-C10 |
| 2027-01-05 23:59:59 | W | PERIOD_STATUS_CHANGE | PER-2026-12 | 2026-12 CLOSED; snapshot `2026-12-cutoff` | - |
| 2027-01-07 09:00 | W | INVOICE_RECEIVED | INV-V019-008 | Beacon final BS-2256, $1,838.71, service 2026-12-01..12-15 | C06 |
| 2027-01-08 09:00 | W | INVOICE_RECEIVED | INV-V002-008 | CloudHarbor Dec, $43,800 | C05 |
| 2027-01-08 09:00 | W | EVIDENCE_UPDATE | TS-V006-PATCH | Fallback timesheet approval; skipped if early-released | C09 |
| 2027-01-08 09:00 | W | VENDOR_ONBOARDED | V018 | SignalStack row in `vendors.json`, billing contact in `org_directory.json` | C04 |
| 2027-01-08 10:00 | W | CONTRACT_DOC_ADDED | CTR-018, PS-018 | MSA + order form ("Pilot Fee $12,000.00 per month"); pricing schedule as separate PRICING_SCHEDULE doc | C04 |
| 2027-01-08 11:00 | W | PO_ISSUED | PO-1063 | $360,000, valid 2027-01-01..2027-12-31 | C04 |
| 2027-01-12 09:00 | W | INVOICE_RECEIVED | INV-V001-008 | DataForge DF-2256, dated 2026-12-31, $52,500 | C03 |
| 2027-01-12 09:05 | T | TRUE_UP | OBL-V001-2026-12 | $2,500 variance; tolerance is max($500, 2% x $50,000) = $1,000; exceeds | C03 |
| 2027-01-13 | T | POLICY_CANDIDATE, REPLAY | POL-0001 | Candidate, then replay over 2026-11 and 2026-12 obligations | loop |
| 2027-01-15 09:00 | W | INVOICE_RECEIVED | INV-V006-003 | Brightwork Dec, $26,270 | C09 |
| 2027-01-15 10:00 | T | POLICY_APPROVED | POL-0001 | Harness acts as E001; policy version 1.1 provisionally active | loop |
| 2027-01-16 09:00 | W | INVOICE_RECEIVED | INV-V015-002 | Quantive $9,300, service 2027-01-15..02-14 | C08 |
| 2027-01-22 09:00 | W | INVOICE_RECEIVED | INV-V007-006 | Meridian Dec, $41,870 | C10 |
| 2027-02-01 00:00 | W | PERIOD_STATUS_CHANGE | PER-2027-01 | 2027-01 OPEN; snapshot `2027-01-open` (fork point, 3.7 L4) | - |
| 2027-02-01 06:00 | W | USAGE_EXPORT, EVIDENCE_UPDATE | USG-V002-2027-01, SVC-2027-01 | CloudHarbor 310,000 h; service_activity Jan: `SA-SIGNALSTACK-2027-01` (first row with `vendor_id` V018) and V001 ACTIVE, V019 INACTIVE with zeros | C04 C05 C06 |
| 2027-02-02 10:00 / 19:00 | T / I | OUTREACH_SENT / INBOX_REPLY | V005/VENDOR_BILLING | Reply (+9 h): 5.5%, $6,752; early-releases DOC-PAGERLOOP-UPLIFT-NOTICE | C12 |
| 2027-02-05 23:59:59 | W | PERIOD_STATUS_CHANGE | PER-2027-01 | 2027-01 CLOSED; snapshot `2027-01-cutoff` | - |
| 2027-02-08 09:00 | W | INVOICE_RECEIVED | INV-V014-003, INV-V002-009 | Atlas Nov-Jan $13,500 (3 x $4,500); CloudHarbor Jan $37,500 | C02 C05 |
| 2027-02-09 09:00 | W | INVOICE_RECEIVED | INV-V005-009 | PagerLoop Jan, $6,752 | C12 |
| 2027-02-10 09:00 | W | INVOICE_RECEIVED | INV-V001-009 | DataForge DF-2263, $52,500 | C03 |
| 2027-02-11 09:00 | W | INVOICE_RECEIVED | INV-V004-009 | Lumen Jan, $18,720 | bg |
| 2027-02-12 09:00 | W | INVOICE_RECEIVED | INV-V018-001 | SignalStack SS-10031, dated 2027-01-31, $30,000 | C04 |

### 3.3 Snapshots

**A. November cutoff (2026-12-05T23:59:59).** Visible: seed plus rows above through 2026-12-05.

| Case | Visible evidence | Missing | Expected state |
|---|---|---|---|
| C01 | INV-V008-007 | - | CLOSE_READY. INV-V008-008 is December rent; not a November expense |
| C02 | CTR-014, INV-V014-002 | Nov invoice | Accrue $4,500, FIXED_CONTRACT_FEE |
| C03 | INV-V001-007 $50,000, PS-001 | - | CLOSE_READY |
| C04 | Two CARD_EXPENSE rows, `SA-SIGNALSTACK-2026-11` (blank `vendor_id`) | vendor, contract, PO | No obligation exists. The string `V018` is not in any file |
| C05 | 296,000 h (under 300,000) | INV-V002-007 | Accrue $36,000 |
| C06 | INV-V019-007, TN-019 | - | CLOSE_READY $3,800 |
| C11 | INV-V016-007 only if outreach was sent | - | CLOSE_READY at actual $5,480; without outreach a run-rate accrual is the wrong action |

**B. December cutoff (2027-01-05T23:59:59).** Added since A: rows 2026-12-08..2027-01-05. Not yet visible: INV-V001-008, INV-V002-008, INV-V019-008, INV-V006-003, INV-V007-006, INV-V014-003, every V018 record except the two card rows and the SignalStack service_activity rows (blank `vendor_id`). PS-001 has been visible since T0, so the $52,500 rate is discoverable at close; policy v1.0 does not require it.

**C. Revealed 2027-01-06..2027-02-04 (the "January reveal").** INV-V019-008 (01-07), INV-V002-008 (01-08), V018 vendor record + CTR-018 + PS-018 + PO-1063 (01-08), INV-V001-008 (01-12), INV-V006-003 (01-15), INV-V015-002 (01-16), INV-V007-006 (01-22), January usage and activity exports (02-01). TrueUp-side: true-up 01-12, POL-0001 candidate and replay 01-13, approval and v1.1 activation 01-15.

**D. January cutoff (2027-02-05T23:59:59).**

| Obligation | Missing at cutoff | v1.0 frozen action | v1.1 expected safe action |
|---|---|---|---|
| OBL-V001-2027-01 | INV-V001-009 | Accrue $50,000 (error -$2,500) | Attach PS-001 CY2, accrue $52,500, Controller |
| OBL-V018-2027-01 | INV-V018-001 | Accrue $12,000 (error -$18,000) | Attach PS-018 Production, accrue $30,000, Controller |
| OBL-V004-2027-01 | INV-V004-009 | Accrue $18,000 | Apply footnote 4%, accrue $18,720, reviewer |
| OBL-V005-2027-01 | INV-V005-009 | Accrue $6,400 | OUTREACH_REQUIRED; with reply accrue $6,752; without reply ESCALATED to E001 |
| OBL-V014-2027-01 | INV-V014-003 | Accrue $4,500 | Same |
| OBL-V019-2027-01 | none expected | Run-rate would accrue $3,800 | NO_ACCRUAL_DOCUMENTED, reason TN-019 |
| OBL-V015-2027-01 | - | $4,200 released from prepaid + $5,100 of INV-V015-002 | Same ($9,300) |
| OBL-V008-2027-01 | - | CLOSE_READY | Same |

Scoring actuals for D arrive 2027-02-08..02-12 (rows above); the harness advances to T_END before scoring.

### 3.4 `world/private/events.jsonl` schema

One JSON object per line, sorted by (`release_at` nulls last, `event_id`).

| Field | Type | Notes |
|---|---|---|
| `event_id` | string `EVT-00001` | Private. Never written to the visible tree |
| `event_type` | enum | INVOICE_RECEIVED, USAGE_EXPORT, EVIDENCE_UPDATE, CONTRACT_DOC_ADDED, VENDOR_ONBOARDED, PO_ISSUED, PERIOD_STATUS_CHANGE |
| `release_at` | timestamp or null | null = released only by an inbox reply (3.5) |
| `record_id` | string | Primary key of the visible record |
| `vendor_id`, `period` | string or null | For filtering and tests |
| `target` | string | Path relative to the visible root |
| `op` | enum | UPSERT_RECORD (JSON array file, key = `key_field`; for `company.json` the array is `close_calendar`), APPEND_ROWS (CSV), PATCH_ROWS (CSV, match on `key_field`), ADD_FILE (files only) |
| `key_field` | string | e.g. `invoice_id`, `vendor_id`, `po_id`, `week_ending` |
| `payload` | object or array | The record(s), in the section 2 schema of the target file. Carries no `received_date` or `filed_date`; the simulator stamps those (and `sent_at` on inbox rows) with the actual release time |
| `files` | array of `{from, to}` | `from` relative to `world/private/` (always under `documents/`), `to` under the visible root |
| `side_effects` | array of events without ids | e.g. the `ap_queue.csv` row for an invoice |

```json
{"event_id":"EVT-00052","event_type":"INVOICE_RECEIVED","release_at":"2027-01-12T09:00:00","record_id":"INV-V001-008","vendor_id":"V001","period":"2026-12","target":"invoices/invoices.json","op":"UPSERT_RECORD","key_field":"invoice_id","payload":{"invoice_id":"INV-V001-008","invoice_number":"DF-2256","vendor_id":"V001","invoice_date":"2026-12-31","service_period_start":"2026-12-01","service_period_end":"2026-12-31","po_id":"PO-1029","currency":"USD","amount":52500.00,"line_items":[{"description":"DataForge Platform subscription - December 2026","quantity":1,"unit_price":52500.00,"amount":52500.00}],"received_channel":"ap@northstar.example"},"files":[{"from":"documents/invoices/INV-V001-008.pdf","to":"invoices/pdf/INV-V001-008.pdf"}],"side_effects":[{"target":"ap_queue.csv","op":"APPEND_ROWS","payload":[{"ap_id":"AP-V001-008","invoice_id":"INV-V001-008","status":"PENDING_APPROVAL","coded_account":"6100"}]}]}
{"event_id":"EVT-00045","event_type":"VENDOR_ONBOARDED","release_at":"2027-01-08T09:00:00","record_id":"V018","vendor_id":"V018","period":null,"target":"vendors.json","op":"UPSERT_RECORD","key_field":"vendor_id","payload":{"vendor_id":"V018","name":"SignalStack Inc.","category":"SAAS_OR_DATA","spend_type":"SUBSCRIPTION","gl_account":"6120","cost_center":"CC-190","legal_entity_id":"NS-US","operational_owner":"E019","requester":"E019","billing_contact":"SignalStack Billing","billing_email":"billing@signalstack.example","contract_id":"CTR-018","po_id":"PO-1063","payment_terms":"Net 30","status":"ACTIVE","notes":"Onboarded from corporate card to AP"},"side_effects":[{"target":"org_directory.json","op":"UPSERT_RECORD","payload":{"vendor_id":"V018","name":"SignalStack Billing","email":"billing@signalstack.example","role":"VENDOR_BILLING"}}]}
{"event_id":"EVT-00046","event_type":"CONTRACT_DOC_ADDED","release_at":"2027-01-08T10:00:00","record_id":"PS-018","vendor_id":"V018","period":null,"target":"contracts/index.json","op":"UPSERT_RECORD","key_field":"doc_id","payload":{"doc_id":"PS-018","doc_type":"PRICING_SCHEDULE","contract_id":"CTR-018","counterparty_name":"SignalStack Inc.","vendor_id":"V018","title":"Exhibit B - Pricing Schedule","effective_date":"2026-11-01","filed_by":"E019","files":["contracts/pricing_schedules/PS-018.pdf","contracts/pricing_schedules/PS-018.txt"],"supersedes":null},"files":[{"from":"documents/contracts/PS-018.pdf","to":"contracts/pricing_schedules/PS-018.pdf"},{"from":"documents/contracts/PS-018.txt","to":"contracts/pricing_schedules/PS-018.txt"}]}
{"event_id":"EVT-00048","event_type":"PO_ISSUED","release_at":"2027-01-08T11:00:00","record_id":"PO-1063","vendor_id":"V018","period":null,"target":"purchase_orders.json","op":"UPSERT_RECORD","key_field":"po_id","payload":{"po_id":"PO-1063","vendor_id":"V018","owner":"E019","requester":"E019","cost_center":"CC-190","legal_entity_id":"NS-US","authorized_amount":360000.00,"type":"BLANKET_ANNUAL","valid_from":"2027-01-01","valid_to":"2027-12-31","issued_date":"2027-01-08","status":"OPEN","description":"SignalStack product analytics, 2027"}}
{"event_id":"EVT-00031","event_type":"USAGE_EXPORT","release_at":"2027-01-01T06:00:00","record_id":"USG-V002-2026-12","vendor_id":"V002","period":"2026-12","target":"evidence/usage_daily.csv","op":"APPEND_ROWS","key_field":"date","payload":[{"vendor_id":"V002","date":"2026-12-01","metric":"compute_hours","quantity":11480,"source":"usage-export"},{"vendor_id":"V002","date":"2026-12-02","metric":"compute_hours","quantity":11212,"source":"usage-export"}]}
{"event_id":"EVT-00009","event_type":"EVIDENCE_UPDATE","release_at":"2026-12-02T09:00:00","record_id":"JE-CARD-0002","vendor_id":null,"period":"2026-12","target":"gl_entries.csv","op":"APPEND_ROWS","key_field":"entry_id","payload":[{"entry_id":"JE-CARD-0002","line_no":1,"posting_date":"2026-12-02","period":"2026-12","legal_entity_id":"NS-US","account":"6120","cost_center":"CC-190","vendor_id":"","debit":12000.00,"credit":0.00,"entry_type":"CARD_EXPENSE","reference":"CARD-4417-20261202","memo":"Corp card x4417 (E019) SIGNALSTACK INC pilot fee Dec 2026","reversal_of":"","posted_by":"CARD_FEED","obligation_id":""},{"entry_id":"JE-CARD-0002","line_no":2,"posting_date":"2026-12-02","period":"2026-12","legal_entity_id":"NS-US","account":"2050","cost_center":"CC-190","vendor_id":"","debit":0.00,"credit":12000.00,"entry_type":"CARD_EXPENSE","reference":"CARD-4417-20261202","memo":"Corp card x4417 (E019) SIGNALSTACK INC pilot fee Dec 2026","reversal_of":"","posted_by":"CARD_FEED","obligation_id":""}]}
{"event_id":"EVT-00040","event_type":"PERIOD_STATUS_CHANGE","release_at":"2027-01-05T23:59:59","record_id":"PER-2026-12","vendor_id":null,"period":"2026-12","target":"company.json","op":"UPSERT_RECORD","key_field":"period","payload":{"period":"2026-12","cutoff":"2027-01-05","status":"CLOSED"}}
{"event_id":"EVT-00090","event_type":"CONTRACT_DOC_ADDED","release_at":null,"record_id":"DOC-PAGERLOOP-UPLIFT-NOTICE","vendor_id":"V005","period":"2027-01","target":"contracts/index.json","op":"UPSERT_RECORD","key_field":"doc_id","payload":{"doc_id":"DOC-PAGERLOOP-UPLIFT-NOTICE","doc_type":"VENDOR_NOTICE","contract_id":"CTR-005","counterparty_name":"PagerLoop Inc.","vendor_id":"V005","title":"2027 renewal notice","effective_date":"2027-01-01","filed_by":"E003","files":["inbox/attachments/DOC-PAGERLOOP-UPLIFT-NOTICE.txt"],"supersedes":null},"files":[{"from":"documents/inbox/DOC-PAGERLOOP-UPLIFT-NOTICE.txt","to":"inbox/attachments/DOC-PAGERLOOP-UPLIFT-NOTICE.txt"}]}
```

This section introduces no file of its own. Period status lives in `company.json.close_calendar`; `contracts/index.json` and `inbox/messages.jsonl` use the section 2 schemas. GL account 2050 = Corporate Card Payable. Event ids in the examples are illustrative; the generator numbers events in `release_at` order, nulls last. All other `target` paths follow the file layout section; if that section moves a file, `target` values move with it.

### 3.5 Triggered inbox

Replies live in `world/private/inbox/scripted_responses.json` (moved out of the visible tree; the current location is a leak). Existing fields stay. Two fields are added: `releases` (array of `event_id` to release at delivery) and `once` (always true).

```json
{"response_id":"RSP-008","vendor_id":"V001","period":"2026-12","target_role":"VENDOR_BILLING","missing_fact":"INVOICE_WHEREABOUTS","responder":"Amira Khan","delay_hours":30,"response_type":"DATA","body":"We are migrating billing systems, so December invoices will go out around Jan 11. Apologies for the delay.","structured_facts":{"expected_issue_date":"2027-01-11"},"attachments":[],"releases":[]}
{"response_id":"RSP-001","vendor_id":"V016","period":"2026-11","target_role":"VENDOR_BILLING","missing_fact":"INVOICE_WHEREABOUTS","responder":"Northwind Business Billing","delay_hours":5,"response_type":"DATA","body":"Invoice NT-2249 was issued Nov 30 and emailed to ap-old@northstar.example. Re-sending to your current AP address now.","structured_facts":{"invoice_number":"NT-2249","issued":"2026-11-30"},"attachments":["INV-V016-007"],"releases":["EVT-00014"]}
```

Mechanism:
1. The tool layer calls `simulator.send_outreach({outreach_id, obligation_id, vendor_id, period, target_role, to, missing_fact, subject, body})` with `outreach_id` = `OUT-<vendor_id>-<period>-NN`. The simulator stamps `sent_at = clock`, appends the OUTBOUND row `MSG-<outreach_id>-O` to `runtime/visible/inbox/messages.jsonl` and logs the call in `runtime/outreach_log.jsonl`. The return value is always `{"outreach_id": ..., "accepted": true}`; it never says whether a reply exists.
2. Match key is exactly (`vendor_id`, `period`, `target_role`, `missing_fact`). Match found and `response_type != NO_RESPONSE`: schedule delivery at `sent_at + delay_hours`. Otherwise nothing is ever delivered.
3. When `advance_to` passes the delivery time, the simulator appends the INBOUND row `MSG-<outreach_id>-R` to `runtime/visible/inbox/messages.jsonl` and releases each event in `releases` with the delivery timestamp. A released event's later absolute `release_at` becomes a no-op.
4. A second request with the same key gets no second reply. `target_role` enum: VENDOR_BILLING, OPERATIONAL_OWNER, REQUESTER, AP_SPECIALIST, CONTROLLER. `missing_fact` enum: INVOICE_WHEREABOUTS, SERVICE_RECEIVED, SCOPE_OR_RATE_CHANGE, AP_STATUS, TREATMENT.

Delivered message (visible), in the section 2 `inbox/messages.jsonl` schema. `response_id` and `event_id` are dropped:
```json
{"message_id":"MSG-OUT-V001-2026-12-01-R","thread_id":"OUT-V001-2026-12-01","obligation_id":"OBL-V001-2026-12","direction":"INBOUND","from":"billing@dataforge.example","to":"close@northstar.example","target_role":"VENDOR_BILLING","missing_fact":"INVOICE_WHEREABOUTS","sent_at":"2027-01-03T16:00:00","response_type":"DATA","body":"We are migrating billing systems, so December invoices will go out around Jan 11. Apologies for the delay.","structured_facts":{"expected_issue_date":"2027-01-11"},"attachments":[]}
```

New replies to add (all other existing replies unchanged):

| Key | Responder, delay | Body rule | `releases` |
|---|---|---|---|
| V001 / 2027-01 / VENDOR_BILLING / INVOICE_WHEREABOUTS | Amira Khan, 24 h | Timing only ("around Feb 10"). No amount | - |
| V018 / 2027-01 / VENDOR_BILLING / INVOICE_WHEREABOUTS | SignalStack Billing, 18 h | Timing only ("onboarding paperwork pending, invoice around Feb 12"). No amount, no plan name | - |
| V018 / 2027-01 / OPERATIONAL_OWNER / SERVICE_RECEIVED | E019, 6 h | "Yes, SignalStack was in use all of January." No mention of pilot or production | - |
| V019 / 2026-12 / OPERATIONAL_OWNER / SERVICE_RECEIVED | E013, 6 h | "We stopped using Beacon on Dec 15 per the termination notice." `{"service_received":true,"service_end_date":"2026-12-15"}` | - |
| V019 / 2027-01 / OPERATIONAL_OWNER / SERVICE_RECEIVED | E013, 6 h | "Not in use in January." `{"service_received":false}` | - |
| V006 / 2026-12 / OPERATIONAL_OWNER (existing RSP-002) | E014, 20 h | unchanged | timesheet PATCH_ROWS event |
| V005 / 2027-01 / VENDOR_BILLING (existing RSP-006) | Tessa Byrne, 9 h | unchanged | EVT for DOC-PAGERLOOP-UPLIFT-NOTICE |

### 3.6 Simulator clock contract

The simulator is a separate process. It alone receives `world/private`. State lives in `runtime/sim_state.json` (`clock`, `released_event_ids`, `pending_deliveries`, `delivered_response_ids`) and `runtime/outreach_log.jsonl`, both outside `runtime/visible/`.

| Call | Contract |
|---|---|
| `reset()` | Deletes `runtime/`. Copies `world/seed/` to `runtime/visible/`. Sets clock = T0. |
| `now()` | Returns the clock. The only time source TrueUp may use. |
| `advance_to(ts)` | `ts < clock` raises `ClockRegressionError`. `ts == clock` is a no-op. Otherwise applies, in one merged time order, every event with `clock < release_at <= ts` and every inbox delivery due in that window; ties break by `event_id`. Stamps `received_date`, `filed_date` and inbox `sent_at` from the release time. Sets clock = ts. Returns the list of released `record_id`s to the harness only. |
| `send_outreach(req)` | See 3.5. Does not move the clock. |
| `snapshot(label)` | Copies `runtime/visible/` to `runtime/snapshots/{label}/`. Called automatically when `advance_to` crosses a cutoff instant or `2027-02-01T00:00:00`. |
| `fork(label, dest)` | Creates a new runtime at `dest` from a snapshot plus the matching `sim_state`. Used for frozen vs policy-enabled runs. |

Idempotence and determinism:
- Each event is applied at most once (`released_event_ids`). Every `op` is an upsert on `key_field`, so re-applying after a crash changes nothing.
- `advance_to(a); advance_to(b)` yields byte-identical `runtime/visible/` to `advance_to(b)` when no outreach happens in between. JSON arrays are written sorted by key, CSV rows in release order, files written atomically (temp + rename).
- Same `world/` plus same `outreach_log.jsonl` gives the same visible-tree hash. Hash = sha256 over sorted `(relative path, file sha256)` pairs.
- `runtime/visible/` is read-only to TrueUp. TrueUp's accruals, reversals, true-ups, policies and replay reports live in its own store, seeded by importing visible `gl_entries.csv`.

### 3.7 Leakage checklist and enforcing tests

Tests live in `data/tests/test_leaks.py` and run against a scripted full run (reset, the P1-P3 schedule, advance to T_END).

| # | Rule | Automated test |
|---|---|---|
| L1 | No visible record is dated after the clock. Checked fields: `received_date`, `sent_at`, `invoice_date`, `posting_date`, `date`, `snapshot_date`, `week_ending`, `approved_date`, `delivery_date`, `filed_date`, `issued_date`, `onboarded_date`, `last_activity_date`. Forward-looking contract fields are exempt: `service_period_end`, `valid_to`, term and pricing-tier dates, `effective_date` of TN-019, `expected_issue_date`. | `test_no_future_dated_records`: at each of the four snapshots and at 20 random clocks, parse every JSON/CSV/JSONL under `runtime/visible/` and assert each checked field <= clock. |
| L2 | Seed contains nothing with `release_at > T0`. | `test_seed_is_t0_clean`: same scan on `world/seed/` with clock = T0; also asserts no V018 string, no `SignalStack` outside GL memo text, no invoice with id in the events file. |
| L3 | No private path is reachable from the tool layer. Tools receive a `VisibleRoot` object; it resolves paths, rejects absolute paths, `..`, and symlinks leaving the root. The TrueUp process has no `TRUEUP_WORLD_DIR` env var; only the simulator does. | `test_visible_root_rejects_escape` (tries `../sim_state.json`, `../../world/private/events.jsonl`, an absolute path, a planted symlink); `test_tool_source_has_no_private_refs` (greps the TrueUp package for `world/`, `private`, `truth`, `events.jsonl`, `scripted_responses`, `sim_state`). |
| L4 | Frozen v1.0 and policy-enabled v1.1 January runs start from identical visible state. Both are `fork("2027-01-open", ...)` of one canonical run. | `test_fork_parity`: visible hash, `sim_state.json` and `outreach_log.jsonl` are equal at fork; the two TrueUp stores differ only by POL-0001 and the policy version. |
| L5 | Ids do not reveal future facts. `invoice_id` = `INV-{vendor_id}-{seq}` with `seq` per vendor in release order, contiguous among visible invoices. `invoice_number` follows the vendor's own series (`DF-` step 7, `SS-10031`, `BS-` step 7) and never encodes amount or tier. File names carry ids only. `event_id`, `response_id`, case ids and split labels never appear in visible files. | `test_invoice_ids_contiguous_per_vendor` at every snapshot; `test_no_banned_tokens`: regex over all visible text for `EVT-\d`, `RSP-\d`, `\bC(0[1-9]|1[0-2])\b`, `TRAIN`, `HELDOUT`, `true_expense`, `static_`, `scenario`, `root_cause`, `pricing_model`, `has_scheduled_price_change`. |
| L6 | Future amounts appear only in the documents that legitimately state them. | `test_amount_allowlist`: before the release of the matching invoice, `52500`/`52,500` occurs only in `contracts/pricing_schedules/PS-001.*`; `30000`/`30,000` with V018 only in `PS-018.*`; `1838.71`, `18720`, `41870` nowhere; `6752` and `5.5` nowhere until the PagerLoop reply is delivered. |
| L7 | Replies never leak more than the asked fact. Timing replies for V001 and V018 contain no dollar amount. | `test_timing_replies_have_no_amount`: regex `\$?\d{2,3}(,\d{3})` on bodies and `structured_facts` of INVOICE_WHEREABOUTS replies for V001 and V018. |
| L8 | Replay uses only what was visible at replay time. Replay at clock 2027-01-13 reads obligation evidence from snapshots `2026-11-cutoff` and `2026-12-cutoff`, and actuals from the live visible tree at 2027-01-13. Obligations with no actual yet (OBL-V014-2026-11, OBL-V014-2026-12, OBL-V006-2026-12, OBL-V007-2026-12) are compared on action only and counted in the replay report field `compared_on_action_only`. | `test_replay_inputs`: the replay report's obligation set equals TrueUp's stored obligations for 2026-11 and 2026-12; contains no `2027-01` period and no V018; every cited evidence id exists in the snapshot for its period; every cited actual has `received_date <= 2027-01-13`. |
| L9 | Vendor master does not leak contract features. | `test_vendor_master_columns`: `vendors.json` keys contain `spend_type` in {SUBSCRIPTION, USAGE, SERVICES, RENT, OTHER} and none of `pricing_model`, `pricing_structure`, `escalator`, `uplift`. |
| L10 | Determinism. | `test_rebuild_matches`: `reset()` then replaying `outreach_log.jsonl` with the same `advance_to` sequence reproduces the same visible hash at every snapshot. |
