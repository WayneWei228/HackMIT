# TrueUp Close: interactive judge demo specification

Status: specification only, no code changed. Built on `data/WORLD_SPEC.md` (frozen world) and the TrueUp product spec. Source request: `data/demo_spec/BRIEF.md`. Sections are also kept separately under `data/demo_spec/`.

# 00 Decisions: shared contract for the interactive judge demo

Scope: names, control catalogue, state machine, the three judge scenarios, endpoint and table lists, section ownership.
Binding on sections 01 to 05. Product spec and `data/WORLD_SPEC.md` are frozen. Every id, amount and date below is reused from WORLD_SPEC or derived from it by the arithmetic shown.

**Declared departure from WORLD_SPEC, stated once.** `WORLD_SPEC.md` line 263 sets PO-1063 `authorized_amount` to $360,000.00, and `360000.00 / 12 = 30000.00` is exactly the held-out answer, so the PO back-solves the price the agent is supposed to earn. This specification pins PO-1063 at `authorized_amount = 415000.00`, a not-to-exceed blanket PO for 2027 that authorises spend and states no price. `415000.00 / 12 = 34583.33`; the nearest offered monthly fee is $33,000.00, a gap of $1,583.33, wider than the $500.00 tolerance on any V018 accrual. The baseline production fee of $30,000.00 per month is stated only by PS-018. Every judge parameter must satisfy `12 x monthly_fee <= 415000.00`. This is the only value this specification changes in the frozen world; leakage test LK11 (`02-state-machine-and-time.md` section 5) asserts the property for every offered parameter value.

## 1. Glossary

### 1.1 Services and roots

| Name | Process | Owns | Never sees |
|---|---|---|---|
| Simulator (`sim`) | FastAPI, port 8100 | `world/seed`, `world/private`, the clock, the Scenario Lab, ScenarioOverrides, regeneration, `runtime/mutation_log.jsonl` | TrueUp state and the playbook database |
| TrueUp (`trueup`) | FastAPI, port 8000 | agents, deterministic estimator, verifier, `trueup_state.db`, `trueup_playbook.db`, the web page | `world/`, `sim_state.json`, `mutation_log.jsonl`, any event with `release_at` later than the clock |

The Lab belongs to `sim`. TrueUp tools receive `runtime/visible/` only (WORLD_SPEC 3.7 L3).
`trueup` exposes `/api/lab/*` as a byte passthrough proxy to `sim`, so the browser has one origin. The proxy module imports nothing from `data/gen`.

### 1.2 UI panels (one web page, `GET /`)

`#clock-bar` "Clock and World" (header: simulated clock, period statuses, playbook version badge, 12 hex world hash, `LIVE` or `RECORDED` badge); `#lab-panel` "Scenario Lab"; `#diff-panel` "What Changed"; `#close-board` "Close Command Center" (S1); `#workpaper` "Vendor Obligation Workpaper" (S2); `#outreach-queue` "Outreach and Resolution" (S3); `#trueup-panel` "Invoice and True-Up" (S4); `#evidence-trail` "Evidence Trail" (live tool-call stream); `#learning-panel` "Learning and Controls" (S5); `#transfer-panel` "Frozen vs Learned"; `#audit-panel` "Audit Packet" (S6).

### 1.3 Buttons

`btn-apply-mutation` "Apply Change"; `btn-undo-mutation` "Undo Change"; `btn-run-close` "Run Close"; `btn-approve-accrual` "Approve Accrual"; `btn-advance-time` "Advance Time"; `btn-investigate` "Investigate Variance"; `btn-run-replay` "Run Replay"; `btn-approve-policy` "Approve Policy"; `btn-reject-policy` "Reject Policy"; `btn-run-transfer` "Run Transfer Compare"; `btn-reset-world` "Reset World"; `btn-reset-demo` "Reset Demo".

### 1.4 ScenarioOverride

One JSON object per judge change. Lives only in `runtime/mutation_log.jsonl` and `sim_state.json.overrides`. Never written under `runtime/visible/`.

```json
{"override_id":"OVR-0001","control_id":"CTL-ESCALATOR-PCT","validator":"VAL-ESCALATOR-PCT",
 "target":{"kind":"PRICING_SCHEDULE","doc_id":"PS-001","vendor_id":"V001","contract_id":"CTR-001"},
 "param":{"escalator_pct":8.0},"baseline_param":{"escalator_pct":5.0},
 "visible_doc_changed":"contracts/pricing_schedules/PS-001.txt",
 "hidden_records_rederived":["INV-V001-008","INV-V001-009"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"9f2c41ab77d0"}
```

Rules. One override per run by default; `POST /sim/overrides/apply` rejects a second staged override unless `allow_multi=true`. A control parameter never edits a truth file. The simulator re-runs `world.py` pricing functions with the override applied, then rebuilds `world/seed`, `world/private/events.jsonl` and `world/private/truth/`, so a contract schedule and its hidden invoice can never disagree. Regeneration renders a PDF only for `visible_doc_changed`; all other PDFs are copied from `world/pdf_cache/`. Budget: under 2 seconds.

### 1.5 Hashes

- `world_hash` = sha256 over the newline joined sorted list of `"<relative path> <sha256 of file bytes>"` for every file under `runtime/visible/` (WORLD_SPEC 3.6).
- `fixture_hash` = the same function over `world/seed/`, `world/private/events.jsonl` and `world/private/truth/`.
- `BASELINE_FIXTURE_HASH` = the `fixture_hash` of an override free build. Pinned in `data/demo_spec/BASELINE_HASH.txt`, printed in `#clock-bar`, re-verified by Reset Demo.
- The UI shows the first 12 hex characters of each hash.

### 1.6 Additive deltas to frozen schemas

Only these. Nothing else in the product spec or WORLD_SPEC changes.
`VendorObligation.root_cause` gains `UNKNOWN`. VarianceExplanation `process_cause` gains `NO_OBSERVABLE_FEATURE` and `NO_CONTRACTUAL_BASIS`. The policy status enum is `CANDIDATE`, `BLOCKED`, `ACTIVE_PROVISIONAL`, `ACTIVE`, `REJECTED`, `REVOKED`. New record types: ScenarioOverride, AgentRun, ToolCall, EscalationNote.

### 1.7 Policy scope whitelist

A candidate policy predicate may reference only `estimator_method` and these ContractFeatures fields: `contract_type`, `pricing_structure`, `billing_cadence`, `has_scheduled_price_change`, `has_pricing_exhibit`, `has_usage_component`, `termination_notice_on_file`, `auto_renews`, `notice_days`.
Banned anywhere in a policy record: `vendor_id`, vendor name, `contract_id`, `category`, `cost_center`, `po_id`, and any post cutoff fact (`invoice_id`, `true_up_amount`, `actual_invoice_total`, `root_cause`).

## 2. Control catalogue

Whitelist matrix: a control is offered only for the vendors listed. Every row has one validator that keeps the world internally consistent after regeneration.

| control_id | Eligible vendors | Parameter enum | Visible document diff | Hidden records re-derived | v1.0 behaviour | Learned behaviour | Flag |
|---|---|---|---|---|---|---|---|
| `CTL-ESCALATOR-PCT` | V001, V004, V018 | V001 `escalator_pct` 0 / 5 / 8 / 12 (on $50,000.00); V004 `escalator_pct` 0 / 4 / 6 / 10 (on $18,000.00); V018 `production_monthly_fee` 12000 / 24000 / 30000 / 33000 | `contracts/pricing_schedules/PS-001.txt`, `contracts/CTR-004.txt` footnote, `contracts/pricing_schedules/PS-018.txt` | INV-V001-008, INV-V001-009, INV-V004-009, INV-V018-001 | accrues the order form fee, misses by the uplift | attaches `pricing_schedule_effective`, accrues the effective fee | demo-path |
| `CTL-ESCALATOR-DATE` | V001, V018 | V001 `cy2_effective_date` 2026-12-01 / 2027-01-01 / 2027-02-01; V018 `production_effective_date` 2027-01-01 / 2027-02-01 | same PS files, Start and End cells | same invoices | accrues the order form fee regardless of date | reads the row covering the service period, so a later date correctly yields the old price | demo-path |
| `CTL-SURCHARGE` | V006, V007 | `surcharge_amount` 0.00 / 900.00 / 2400.00 / 6000.00 | none by design | INV-V006-003, INV-V007-006 (amount plus one line item) | accrues from timesheets or the Controller decision | identical: no predicate matches, root cause `UNKNOWN`, `ESCALATED`, no candidate | demo-path |
| `CTL-INVOICE-DELAY` | V001, V002, V019 | `delay_days` 0 / 7 / 21 / 35 | none | `release_at` of the INVOICE_RECEIVED event | accrues at cutoff, trues up when the invoice lands | same | lab extra 1 |
| `CTL-SVC-CONFIRM` | V001, V006 | `service_evidence` CONFIRMED / PENDING / ABSENT | `evidence/timesheets.csv` `approval_status`, `evidence/service_activity.csv` row | scripted reply availability, timesheet patch event | PENDING triggers `OUTREACH_REQUIRED`; ABSENT triggers `ESCALATE`, never a silent accrual | same | lab extra 2 |
| `CTL-USAGE-SPIKE` | V002, V013 | `spike_multiplier` 1.0 / 1.25 / 1.5 / 2.0 on December daily rows | `evidence/usage_daily.csv` December rows | INV-V002-008, INV-V013-008 | `USAGE_X_RATE` over the full rate card, correct at any multiplier | same | lab extra 3 |
| `CTL-DUP-INVOICE` | V008, V012 | `duplicate` NONE / EXACT_COPY / NEW_NUMBER | `invoices/invoices.json`, `ap_queue.csv` | the duplicate INVOICE_RECEIVED event | `DUPLICATE_SUSPECTED`, verifier `BLOCK`, `HOLD_DO_NOT_POST`, notify E003 | same | lab extra 4 |
| `CTL-TERMINATE` | V005, V019 | `termination_effective` NONE / 2026-11-30 / 2026-12-15 / 2026-12-31 | `contracts/notices/TN-019.txt` effective line, or new `TN-005` | final prorated invoice, later invoices deleted, `service_activity` last activity date | `PRORATED_FEE` for the served days, `NO_ACCRUAL_DOCUMENTED` afterwards | same | lab extra 5 |
| `CTL-CADENCE` | V008, V014 | `billing_cadence` MONTHLY_ARREARS / MONTHLY_ADVANCE / QUARTERLY_ARREARS | `contracts/CTR-008.txt`, `contracts/CTR-014.txt` billing clause | invoice service periods and release dates | cadence changes which months need an accrual, amounts unchanged | same | lab extra 6 |

Cut order if time runs out: drop `CTL-CADENCE` first, then `CTL-TERMINATE`, `CTL-DUP-INVOICE`, `CTL-USAGE-SPIKE`, `CTL-SVC-CONFIRM`, `CTL-INVOICE-DELAY`. The three demo-path controls are never cut.

Validators, one per control, except `CTL-ESCALATOR-PCT`, which uses `VAL-ESCALATOR-PCT` for V001 and V004 and `VAL-PRODUCTION-FEE` for V018: `VAL-ESCALATOR-PCT` (new fee > 0; every invoice on or after the effective date re-derived from the same pricing function; PO amounts untouched), `VAL-PRODUCTION-FEE` (`12 x fee <= 415000.00`), `VAL-ESCALATOR-DATE` (first of a month; V001 not earlier than 2026-12-01 so no closed period changes; V018 not earlier than 2027-01-01 because V018 is not in the vendor master before 2027-01-08), `VAL-SURCHARGE` (a new invoice line, no contract text change, no pre-cutoff evidence change), `VAL-INVOICE-DELAY` (`release_at <= 2027-02-15T23:59:59`, invoice still matches its obligation), `VAL-SVC-CONFIRM` (either another source still evidences the period or the expected outcome becomes outreach or escalation), `VAL-USAGE-SPIKE` (daily rows scale, monthly total equals the sum, invoice re-derived from the rate card), `VAL-DUP-INVOICE` (same PO, amount and service period, distinct `invoice_id`, still one goods receipt), `VAL-TERMINATE` (effective date inside the term and not earlier than 2026-12-01; final fee `= monthly_fee x days_served / days_in_month`, half-up to 2 decimals), `VAL-CADENCE` (annual fee constant; service periods tile the term with no gap or overlap).

The Lab shows a diff for `PS-018` and `TN-005` with the label "not visible to the agent until <release timestamp>". Showing the judge a future document is not a leak: it never enters `runtime/visible/` before its event releases.

## 3. Demo state machine

States are UPPER_SNAKE and stored in `demo_state.state`. The clock column is the simulator clock on entry.

| State | Clock on entry | Enabled buttons |
|---|---|---|
| `IDLE_BASELINE` | 2027-01-04T09:00:00 | Apply Change (after staging), Run Close, Reset World, Reset Demo |
| `MUTATION_STAGED` | 2027-01-04T09:00:00 | Apply Change, Undo Change |
| `MUTATION_APPLIED` | 2027-01-04T09:00:00 | Run Close, Undo Change |
| `CLOSE_RUNNING` | 2027-01-04T09:00:00 to 2027-01-05T15:30:00 | none |
| `CLOSE_AWAITING_APPROVAL` | 2027-01-05T16:00:00 | Approve Accrual |
| `CLOSE_POSTED` | 2027-01-05T23:59:59 | Advance Time |
| `TRUEUP_COMPUTED` | 2027-01-12T09:00:00 (SCN-A), 2027-01-15T09:00:00 (SCN-C) | Investigate Variance |
| `NO_MISS` | same | Advance Time, Reset World, Reset Demo |
| `INVESTIGATING` | 2027-01-13T09:00:00 (SCN-A), 2027-01-15T11:00:00 (SCN-C) | none |
| `ROOT_CAUSE_FOUND` | 2027-01-13T09:00:00 | Run Replay |
| `ROOT_CAUSE_UNKNOWN` | 2027-01-15T11:00:00 | none |
| `ESCALATED` | 2027-01-15T12:00:00 | Reset World, Reset Demo |
| `CANDIDATE_READY` | 2027-01-13T09:30:00 | Run Replay |
| `CANDIDATE_BLOCKED` | 2027-01-13T09:30:00 (guard G1) or 2027-01-13T11:00:00 (guard G2) | Reject Policy, Reset World |
| `REPLAY_REPORT_READY` | 2027-01-13T11:00:00 | Approve Policy, Reject Policy |
| `POLICY_APPROVED` | 2027-01-15T10:00:00 | Advance Time, Run Transfer Compare |
| `POLICY_REJECTED` | 2027-01-15T10:00:00 | Advance Time, Run Transfer Compare |
| `TRANSFER_RUNNING` | 2027-02-05T09:00:00 | none |
| `TRANSFER_COMPARED` | 2027-02-12T09:00:00 | Reset World, Reset Demo |

Transitions.

| From | Event | Guard | To |
|---|---|---|---|
| `IDLE_BASELINE` | Lab selection changed | control, vendor and parameter all set | `MUTATION_STAGED` |
| `MUTATION_STAGED` | `btn-apply-mutation` | validator passes | `MUTATION_APPLIED` |
| `MUTATION_STAGED` / `MUTATION_APPLIED` | `btn-undo-mutation` | - | `IDLE_BASELINE` |
| `IDLE_BASELINE` / `MUTATION_APPLIED` | `btn-run-close` | period 2026-12 status is OPEN | `CLOSE_RUNNING` |
| `CLOSE_RUNNING` | agent emits `POST_ACCRUAL` proposal | verifier `required_approval_level != NONE` | `CLOSE_AWAITING_APPROVAL` |
| `CLOSE_RUNNING` | verifier result `ESCALATE` | conflicting or absent evidence | `ESCALATED` |
| `CLOSE_AWAITING_APPROVAL` | `btn-approve-accrual` | actor E001 for `CONTROLLER`, E002 for `REVIEWER` | `CLOSE_POSTED` |
| `CLOSE_POSTED` | `btn-advance-time` | target clock greater than current clock | `TRUEUP_COMPUTED` |
| `TRUEUP_COMPUTED` | automatic | `abs(variance) <= tolerance` | `NO_MISS` |
| `TRUEUP_COMPUTED` | `btn-investigate` | `abs(variance) > tolerance` | `INVESTIGATING` |
| `INVESTIGATING` | classifier returns a root cause in the enum | a pre cutoff observable feature supports it | `ROOT_CAUSE_FOUND` |
| `INVESTIGATING` | classifier returns `UNKNOWN` | no contractual basis and no pre cutoff observable feature | `ROOT_CAUSE_UNKNOWN` |
| `ROOT_CAUSE_UNKNOWN` | automatic | - | `ESCALATED` (EscalationNote to E001, no candidate policy) |
| `ROOT_CAUSE_FOUND` | `POST /api/policy/candidate`, guard G1 | `evidence_existed_at_close` is true and every predicate is on the 1.7 whitelist | `CANDIDATE_READY` |
| `ROOT_CAUSE_FOUND` | automatic | `evidence_existed_at_close` is false (Controller judgement) | `ESCALATED` |
| `ROOT_CAUSE_FOUND` | `POST /api/policy/candidate`, guard G1 | any predicate outside the 1.7 whitelist, or a post cutoff field | `CANDIDATE_BLOCKED` |
| `CANDIDATE_READY` | `btn-run-replay` | G1 passed | `REPLAY_REPORT_READY` |
| `REPLAY_REPORT_READY` | guard G2 | `regressed > 0` or `abs_error_after >= abs_error_before` | `CANDIDATE_BLOCKED` |
| `REPLAY_REPORT_READY` | `btn-approve-policy` | G1 and G2 passed, actor E001 | `POLICY_APPROVED` |
| `REPLAY_REPORT_READY` / `CANDIDATE_BLOCKED` | `btn-reject-policy` | - | `POLICY_REJECTED` |
| `POLICY_APPROVED` / `POLICY_REJECTED` / `NO_MISS` | `btn-run-transfer` | clock at or after 2027-02-01T00:00:00 | `TRANSFER_RUNNING` |
| `TRANSFER_RUNNING` | both arms finish | - | `TRANSFER_COMPARED` |
| any | `btn-reset-world` | - | `IDLE_BASELINE` |
| any | `btn-reset-demo` | `fixture_hash == BASELINE_FIXTURE_HASH` after rebuild | `IDLE_BASELINE` |

`btn-approve-policy` is rendered disabled in `CANDIDATE_BLOCKED`, with the failing guard named on the button.
Reset World clears overrides, rebuilds the baseline world, resets the runtime to T0, fast-forwards to 2027-01-04T09:00:00, wipes `trueup_state.db` and keeps `trueup_playbook.db`. The playbook badge in `#clock-bar` therefore still reads 1.1 after a Reset World that follows an approval.
Reset Demo does all of that and also drops and re-seeds `trueup_playbook.db` at version 1.0, then prints `BASELINE_FIXTURE_HASH`.

## 4. The three judge scenarios

Common accounts: accrual is `Dr <expense> / Cr 2100`, dated the last day of the service month, reversed on day 1 of the next month. The invoice posts `Dr <expense> / Cr 2000` for the accrued amount, and the true-up posts `Dr <expense> / Cr 2000` for the variance. A zero variance produces no `JE-TRU-` row. Tolerance is `max(500.00, 0.02 x accrued amount)`.

### SCN-A learnable failure

Vendor V001 DataForge, obligation `OBL-V001-2026-12`, control `CTL-ESCALATOR-PCT`, accounts Dr 6100 / Cr 2100 and Cr 2000, CC-100, entry 2026-12-31, reversal 2027-01-01, true-up dated 2027-01-12.
Accrual under v1.0 is always the CTR-001 order form Contract Year 1 fee of $50,000.00. Tolerance is `max(500.00, 0.02 x 50000.00) = 1000.00`.
CY2 fee is `50000.00 x (1 + pct/100)`: 0 percent 50,000.00; 5 percent 52,500.00; 8 percent 54,000.00; 12 percent 56,000.00.

| `escalator_pct` | v1.0 accrual (JE-ACR) | Hidden INV-V001-008 | Variance | vs $1,000.00 | JE-TRU amount | Approval | Branch |
|---|---|---|---|---|---|---|---|
| 0 | 50,000.00 | 50,000.00 | 0.00 | inside | none | CONTROLLER E001 | `NO_MISS`, root cause `TIMING_ONLY`, no candidate |
| 5 | 50,000.00 | 52,500.00 | +2,500.00 | outside | 2,500.00 | CONTROLLER E001 | POL-0001 candidate |
| 8 | 50,000.00 | 54,000.00 | +4,000.00 | outside | 4,000.00 | CONTROLLER E001 | POL-0001 candidate |
| 12 | 50,000.00 | 56,000.00 | +6,000.00 | outside | 6,000.00 | CONTROLLER E001 | POL-0001 candidate |

Under the learned playbook the same obligation accrues the CY2 fee and the variance is 0.00 in every row. Replay at 2027-01-13 over the 35 obligations of 2026-11 and 2026-12 touches `OBL-V001-2026-12` only: `abs_error_before` equals the variance above, `abs_error_after` 0.00, improved 1, regressed 0.

### SCN-B transfer to an unseen vendor

Vendor V018 SignalStack, obligation `OBL-V018-2027-01`, accounts Dr 6120 / Cr 2100 and Cr 2000, CC-190, entry 2027-01-31, reversal 2027-02-01, true-up dated 2027-02-12. Frozen and learned arms both fork snapshot `2027-01-open` at 2027-02-01T00:00:00, so the visible state is byte identical.
Frozen v1.0 always accrues the CTR-018 order form pilot fee of $12,000.00, corroborated by `JE-CARD-0001` and `JE-CARD-0002`. Tolerance is `max(500.00, 0.02 x 12000.00 = 240.00) = 500.00`.

Control `CTL-ESCALATOR-PCT`, parameter `production_monthly_fee`:

| Fee | Frozen accrual | Hidden INV-V018-001 | Frozen variance | vs $500.00 | Frozen JE-TRU | Learned accrual | Learned variance | Learned approval |
|---|---|---|---|---|---|---|---|---|
| 12,000.00 | 12,000.00 | 12,000.00 | 0.00 | inside | none | 12,000.00 | 0.00 | REVIEWER E002 |
| 24,000.00 | 12,000.00 | 24,000.00 | +12,000.00 | outside | 12,000.00 | 24,000.00 | 0.00 | REVIEWER E002 |
| 30,000.00 | 12,000.00 | 30,000.00 | +18,000.00 | outside | 18,000.00 | 30,000.00 | 0.00 | CONTROLLER E001 |
| 33,000.00 | 12,000.00 | 33,000.00 | +21,000.00 | outside | 21,000.00 | 33,000.00 | 0.00 | CONTROLLER E001 |

Control `CTL-ESCALATOR-DATE`, parameter `production_effective_date`:

| Date | January is priced as | Frozen accrual | Hidden invoice | Frozen variance | Learned accrual | Learned variance |
|---|---|---|---|---|---|---|
| 2027-01-01 | production | 12,000.00 | 30,000.00 | +18,000.00 | 30,000.00 | 0.00 |
| 2027-02-01 | pilot | 12,000.00 | 12,000.00 | 0.00 | 12,000.00 | 0.00 |

The 2027-02-01 row is the proof that transfer is not memorised: the learned agent reads the PS-018 row covering 2027-01-01 to 2027-01-31 and books the pilot fee.
`#transfer-panel` prints the predicate match for the learned arm: `estimator_method = FIXED_CONTRACT_FEE` matched, `has_scheduled_price_change = true` matched, `pricing_structure = SCHEDULED_STEP` in the allowed list, and a line stating that POL-0001 contains no vendor identifier, with the serialized policy record beside it.

### SCN-C refuse to learn

Control `CTL-SURCHARGE`. The invoice gains one line, "Year end expedite premium", with no clause in CTR-006 or CTR-007 and no pre cutoff observable feature. Root cause `UNKNOWN`, process cause `NO_CONTRACTUAL_BASIS`, outcome `ESCALATED`, `EscalationNote` to E001, no candidate policy.

V006 Brightwork, `OBL-V006-2026-12`, Dr 6200 / Cr 2100 and Cr 2000, CC-140, entry 2026-12-31, reversal 2027-01-01, true-up dated 2027-01-15. Accrual is `142 x 185.00 = 26,270.00` by `USAGE_X_RATE`, approval CONTROLLER. Tolerance is `max(500.00, 0.02 x 26270.00 = 525.40) = 525.40`.

| `surcharge_amount` | v1.0 accrual | Hidden INV-V006-003 | Variance | vs $525.40 | JE-TRU amount | Outcome |
|---|---|---|---|---|---|---|
| 0.00 | 26,270.00 | 26,270.00 | 0.00 | inside | none | RECONCILED, no review |
| 900.00 | 26,270.00 | 27,170.00 | +900.00 | outside | 900.00 | `UNKNOWN`, ESCALATED, no candidate |
| 2,400.00 | 26,270.00 | 28,670.00 | +2,400.00 | outside | 2,400.00 | same |
| 6,000.00 | 26,270.00 | 32,270.00 | +6,000.00 | outside | 6,000.00 | same |

V007 Meridian, `OBL-V007-2026-12`, Dr 6210 / Cr 2100 and Cr 2000, CC-150, entry 2026-12-31, reversal 2027-01-01, true-up dated 2027-01-22. Accrual is the Controller decision of 40,000.00 with `estimator_method = NONE`. Tolerance is `max(500.00, 0.02 x 40000.00 = 800.00) = 800.00`.

| `surcharge_amount` | v1.0 accrual | Hidden INV-V007-006 | Variance | vs $800.00 | JE-TRU amount | Outcome |
|---|---|---|---|---|---|---|
| 0.00 | 40,000.00 | 41,870.00 | +1,870.00 | outside | 1,870.00 | `ESTIMATE_JUDGMENT`, ESCALATED, no candidate |
| 900.00 | 40,000.00 | 42,770.00 | +2,770.00 | outside | 2,770.00 | `UNKNOWN`, ESCALATED, no candidate |
| 2,400.00 | 40,000.00 | 44,270.00 | +4,270.00 | outside | 4,270.00 | same |
| 6,000.00 | 40,000.00 | 47,870.00 | +7,870.00 | outside | 7,870.00 | same |

Second guard, independent of the classifier: guard G1 blocks any candidate whose predicates leave the 1.7 whitelist or reference a post cutoff fact, and guard G2 blocks any candidate with `regressed > 0` or no reduction in absolute error. A blocked candidate never reaches `btn-approve-policy`.

## 5. Endpoints, tables and id formats

Simulator, base `/sim`:

| Method and path | Purpose |
|---|---|
| `GET /sim/health` | liveness and build version |
| `GET /sim/controls` | the whitelist matrix of section 2 |
| `POST /sim/overrides/stage` | validate a ScenarioOverride and return the document diff, no world change |
| `POST /sim/overrides/apply` | regenerate world, reset runtime, fast-forward to `start_clock` |
| `GET /sim/overrides` | active overrides |
| `DELETE /sim/overrides` | clear overrides |
| `GET /sim/clock` | current simulated clock and period statuses |
| `POST /sim/advance` | `advance_to(ts)`, returns released `record_id`s |
| `POST /sim/outreach` | `send_outreach(req)` |
| `POST /sim/snapshot` | `snapshot(label)` |
| `POST /sim/fork` | `fork(label, dest)` for the frozen and learned arms |
| `GET /sim/hash` | `world_hash`, `fixture_hash`, `BASELINE_FIXTURE_HASH` |
| `POST /sim/reset/world` | baseline world, runtime reset, fast-forward |
| `POST /sim/reset/demo` | baseline world plus fixture hash verification |

TrueUp, base `/api`:

| Method and path | Purpose |
|---|---|
| `GET /api/state` | demo state, clock mirror, playbook version, world hash, LIVE or RECORDED |
| `GET /api/obligations` | S1 inventory for a period |
| `GET /api/obligations/{obligation_id}` | S2 workpaper with evidence, trace and verifier checklist |
| `POST /api/close/run` | run the close for a period |
| `POST /api/accrual/approve` | Controller or Reviewer approval, posts the accrual |
| `POST /api/trueup/run` | deterministic match, variance and tolerance test |
| `POST /api/investigate` | root-cause classification |
| `POST /api/policy/candidate` | create the candidate policy, apply guard G1 |
| `POST /api/policy/replay` | run replay, apply guard G2 |
| `POST /api/policy/approve` | approve, write playbook 1.1 |
| `POST /api/policy/reject` | reject, playbook stays 1.0 |
| `GET /api/playbook` | versions, policies and policy events |
| `POST /api/transfer/run` | run the frozen and learned arms from one fork |
| `GET /api/transfer/compare` | split view payload including the predicate match |
| `GET /api/audit/{obligation_id}` | audit packet |
| `GET /api/evidence-trail` | server-sent stream of tool calls for a run |
| `POST /api/reset/world` | proxy Reset World, keep the playbook database |
| `POST /api/reset/demo` | proxy Reset Demo, re-seed the playbook at 1.0 |
| `ANY /api/lab/{path}` | byte passthrough proxy to `sim` |

`trueup_playbook.db`, survives Reset World:

| Table | Columns |
|---|---|
| `playbook_versions` | `version` PK, `parent_version`, `status`, `created_at`, `activated_at`, `policies_json`, `fixture_hash` |
| `policies` | `policy_id` PK, `policy_type`, `trigger`, `scope_json`, `required_evidence_json`, `before_action`, `verifier_result_if_missing_json`, `outreach_if_missing_json`, `behavior_change`, `autonomy_limit`, `derived_from_json`, `status`, `created_at`, `policy_version_target` |
| `policy_events` | `event_id` PK, `policy_id`, `event_type`, `actor`, `decided_at`, `from_status`, `to_status`, `comment`, `replay_id` |
| `replay_reports` | `replay_id` PK, `policy_id`, `run_at`, `periods_json`, `obligations_replayed`, `improved`, `regressed`, `unchanged`, `extra_outreach`, `extra_reviews`, `abs_error_before`, `abs_error_after`, `touched_json`, `feature_matched_json`, `compared_on_action_only_json`, `forward_scope_preview_json`, `recommendation` |

`trueup_state.db`, wiped by both resets: `obligations`, `contract_features`, `evidence_facts`, `proposals`, `evaluations`, `workpapers`, `approvals`, `outreach_tasks`, `journal_entries`, `invoice_matches`, `trueups`, `variance_explanations`, `escalation_notes`, `agent_runs`, `tool_calls`, `demo_state`.

Id formats for new records: `OVR-0001` ScenarioOverride, `MUT-0001` mutation log line, `RUN-0001` AgentRun, `TC-0001-007` ToolCall, `ESC-V006-2026-12-01` EscalationNote, `PEV-0001` policy event, `REC-<first 12 of world_hash>` recorded run, `SCN-A` to `SCN-C` scenarios, `CTL-<SLUG>` controls, `VAL-<SLUG>` validators. Existing formats (`OBL-`, `PRP-`, `PE-`, `WP-`, `APR-`, `OUT-`, `JE-`, `IM-`, `TU-`, `VE-`, `EXC-`, `POL-`, `RPL-`) are unchanged.

Live-LLM risk. Every agent run streams its tool calls to `#evidence-trail` over `GET /api/evidence-trail`. A recorded run exists only for the override-free baseline world, identified by `fixture_hash == BASELINE_FIXTURE_HASH`; it is stored at `runtime/recorded/REC-<hash12>.jsonl` where `hash12` is the first 12 hex characters of that world's `world_hash`, and `#clock-bar` shows the `RECORDED` badge while it plays. Any mutated world runs live only. If a live model call fails, the state machine goes to `ESCALATED` with the error shown; it never substitutes a recorded answer.

## 6. Section ownership

| Section | File | Owns |
|---|---|---|
| 01 | `01-scenario-lab-and-mutations.md` | Scenario Lab layout, control widgets, the per control data mutation detail, diff rendering, regeneration budget; button semantics for `btn-apply-mutation` and `btn-undo-mutation` |
| 02 | `02-state-machine-and-time.md` | state machine detail, clock handling, hidden-data protection; button semantics for `btn-run-close`, `btn-advance-time`, `btn-reset-world`, `btn-reset-demo` |
| 03 | `03-playbook-memory-and-api.md` | playbook memory, policy lifecycle, replay, frozen vs learned arms, API and state change detail; button semantics for `btn-approve-accrual`, `btn-investigate`, `btn-run-replay`, `btn-approve-policy`, `btn-reject-policy`, `btn-run-transfer` |
| 04 | `04-scenarios-and-demo-flow.md` | the three scenarios end to end and the 3 minute judge flow |
| 05 | `05-weaknesses-and-fixes.md` | attacks a Maximor judge could make and the smallest fixes |

The twelve buttons of section 1.3 are covered exactly once across sections 01 to 03.


---

# 01: Judge Scenario Lab UI and mutations

Scope: deliverables 1 and 2 of BRIEF.md. Binding on this file: `00-decisions.md`. Every id, amount and date below is reused from `WORLD_SPEC.md` or derived from it by the arithmetic shown once.

## 1. Judge Scenario Lab UI (deliverable 1)

### 1.1 Page layout

```
+----------------------------------------------------------------------------+
| #clock-bar  Clock 2027-01-04T09:00:00 | 2026-12 OPEN | Playbook v1.0       |
|             World hash 9f2c41ab77d0 | Fixture hash a10efc9b2d31  [LIVE]    |
+----------------------------------------------------------------------------+
| #lab-panel  SCENARIO LAB                | #diff-panel  WHAT CHANGED        |
| Scenario control  [ dropdown v ]        | contracts/pricing_schedules/     |
| Vendor  [ dropdown v ] (disabled until   |   PS-001.txt                    |
|          control chosen)                | - CY2 ... $52,500.00             |
| Parameter ( radio group ) (disabled     | + CY2 ... $54,000.00             |
|          until vendor chosen)           | Hidden records re-derived        |
| [ Apply Change ]  [ Undo Change ]       | (not shown): 2 -> INV-V001-008,  |
|                                          | INV-V001-009, rel. 01-12 / 02-10 |
+----------------------------------------------------------------------------+
| #close-board  CLOSE COMMAND CENTER (S1)  | #evidence-trail  tool calls     |
| #workpaper  VENDOR OBLIGATION WP (S2)    |                                  |
| #outreach-queue  OUTREACH (S3)           | [ Run Close ] [ Advance Time ]  |
| #trueup-panel  INVOICE / TRUE-UP (S4)    |                                  |
+----------------------------------------------------------------------------+
| #learning-panel  LEARNING (S5)  [Investigate][Run Replay]                  |
|                                  [Approve Policy][Reject Policy]           |
| #transfer-panel  FROZEN vs LEARNED  [ Run Transfer Compare ]               |
+----------------------------------------------------------------------------+
| #audit-panel  AUDIT PACKET (S6)   |  [ Reset World ]  [ Reset Demo ]       |
+----------------------------------------------------------------------------+
```

### 1.2 Lab controls, exactly as rendered

Selecting the control populates the vendor dropdown from the control's whitelist (`00-decisions.md` section 2). Selecting the vendor populates the parameter widget's choice set and default. Any selection change auto-calls `POST /sim/overrides/stage` (debounced 300ms) and repaints `#diff-panel`; nothing under `runtime/visible/` changes until `btn-apply-mutation`.

| control_id | Label text | Widget | Choices | Default |
|---|---|---|---|---|
| `CTL-ESCALATOR-PCT` | "Contract escalator" | radio group | V001: 0% / 5% / 8% / 12%; V004: 0% / 4% / 6% / 10%; V018: $12,000 / $24,000 / $30,000 / $33,000 | V001 5%, V004 4%, V018 $30,000 |
| `CTL-ESCALATOR-DATE` | "Escalator effective date" | radio group | V001: 2026-12-01 / 2027-01-01 / 2027-02-01; V018: 2027-01-01 / 2027-02-01 | V001 2026-12-01, V018 2027-01-01 |
| `CTL-SURCHARGE` | "Year-end surcharge" | radio group | $0.00 / $900.00 / $2,400.00 / $6,000.00 | $0.00 |
| `CTL-INVOICE-DELAY` | "Delay the invoice" | radio group | 0 / 7 / 21 / 35 days | 0 days |
| `CTL-SVC-CONFIRM` | "Service confirmation on file" | radio group | CONFIRMED / PENDING / ABSENT | CONFIRMED |
| `CTL-USAGE-SPIKE` | "December usage spike" | radio group | 1.0x / 1.25x / 1.5x / 2.0x | 1.0x |
| `CTL-DUP-INVOICE` | "Duplicate this invoice" | radio group | NONE / EXACT_COPY / NEW_NUMBER | NONE |
| `CTL-TERMINATE` | "Terminate the contract" | radio group | NONE / 2026-11-30 / 2026-12-15 / 2026-12-31 | V019 2026-12-15, V005 NONE |
| `CTL-CADENCE` | "Billing cadence" | radio group | MONTHLY_ARREARS / MONTHLY_ADVANCE / QUARTERLY_ARREARS | V008 MONTHLY_ADVANCE, V014 QUARTERLY_ARREARS |

Disabled states, exact tooltip text:
- Vendor dropdown: disabled, "Choose a scenario control first" until `control_id` is set.
- Parameter widget: disabled, "Choose a vendor first" until `vendor_id` is set.
- `btn-apply-mutation`: disabled until `POST /sim/overrides/stage` returns `valid: true`; disabled label reason "Validator VAL-... failed: <message>" when the staged parameter fails.
- Whole `#lab-panel`: disabled, "One change per run. Reset World to try another." once `demo_state.state` leaves `IDLE_BASELINE` / `MUTATION_STAGED` (i.e. after Apply), unless `allow_multi=true` was set on the override call.
- `CTL-DUP-INVOICE` for V012: parameter widget disabled, "No December print job on file (V012 has no obligation for 2026-12 in the baseline); duplicate is only offered on an obligation that already has an on-hand invoice" whenever the staged vendor is V012 and no `OBL-V012-2026-12` exists. V008 is unaffected (Dec rent invoice `INV-V008-008` is always on hand).
- `CTL-TERMINATE` choice `2026-11-30` and `CTL-ESCALATOR-DATE` choices before `2026-12-01` for V001: option rendered but disabled, "Would edit a CLOSED period (2026-11)."

### 1.3 What Changed panel

Two blocks, always both present after a stage call:
1. **Visible document diff.** A unified text diff of the one file in `visible_doc_changed` (`00-decisions.md` 1.4), old lines prefixed `-`, new lines `+`. For controls with no visible diff by design (`CTL-SURCHARGE`), the panel reads "No visible document changes. The surcharge only appears on the invoice that has not been released yet."
2. **Hidden records that will be re-derived.** A count and a list of `evidence_id`s only, taken from `hidden_records_rederived`, each annotated with its `release_at` timestamp and the text "not visible to the agent until <timestamp>". No amount, no file content, no diff for these rows. `PS-018` and `TN-005` previews use the same label even though the judge is looking at a document the agent cannot yet see; the label makes clear this is not a leak (`00-decisions.md` section 2, last paragraph).

### 1.4 What the judge can and cannot see

Can see: every file currently under `runtime/visible/`, `world_hash`, `fixture_hash`, `BASELINE_FIXTURE_HASH`, the simulated clock, the staged override's before/after of the one visible document it touches, the list (not content) of hidden records it will touch, and the full `#evidence-trail` of what the agent reads once a close is run.
Cannot see, ever, from the Lab: `world/private/events.jsonl`, `world/private/truth/`, `runtime/mutation_log.jsonl`, `runtime/sim_state.json`, or any file's content dated after the current clock. The hidden invoice for the active mutation (e.g. `INV-V001-008` at $54,000.00) is invisible until `btn-advance-time` releases it; the Lab shows only its id and release timestamp, never its `amount` or `line_items`.

## 2. Control mutation specifications (deliverable 2)

Every row calls `POST /sim/overrides/apply` with the `ScenarioOverride` shape of `00-decisions.md` 1.4. `override_id` and `world_hash` are illustrative 12-hex placeholders. Regeneration re-runs `world.py`'s pricing functions and rebuilds `world/seed`, `world/private/events.jsonl` and `world/private/truth/obligations_truth.csv`; a control parameter never writes a truth file directly.

### 2.1 `CTL-ESCALATOR-PCT`

ScenarioOverride (worked example, V001 5% -> 8%):
```json
{"override_id":"OVR-0001","control_id":"CTL-ESCALATOR-PCT","validator":"VAL-ESCALATOR-PCT",
 "target":{"kind":"PRICING_SCHEDULE","doc_id":"PS-001","vendor_id":"V001","contract_id":"CTR-001"},
 "param":{"escalator_pct":8.0},"baseline_param":{"escalator_pct":5.0},
 "visible_doc_changed":"contracts/pricing_schedules/PS-001.txt",
 "hidden_records_rederived":["INV-V001-008","INV-V001-009"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"7a1c9e0b44d2"}
```
World parameters changed: `world.py` pricing function input `escalator_pct` for `CTR-001` CY2 (was 5.0). Arithmetic: `52500.00 = 50000.00 x 1.05` (unchanged baseline) becomes `50000.00 x 1.08 = 54000.00`.
Derived visible records/files: `contracts/pricing_schedules/PS-001.txt` CY2 row `$52,500.00` -> `$54,000.00`; `contracts/pricing_schedules/PS-001.pdf` re-rendered; `ContractFeatures` for `CTR-001` unchanged (`has_scheduled_price_change` stays true; the exhibit's stated fee is not extracted pre-invoice).
Hidden events/truth re-derived: `events.jsonl` `INVOICE_RECEIVED` payload for `INV-V001-008` amount `52500.00` -> `54000.00`; same event for `INV-V001-009` (Feb, same CY2 rate); `obligations_truth.csv` row `OBL-V001-2026-12`: `true_expense` `52500.00`->`54000.00`, `static_error` `-2500.00`->`-4000.00`, `policy_enabled_estimate` `52500.00`->`54000.00`.
Before/after: JE-ACR-V001-2026-12 (Dr 6100/Cr 2100) stays $50,000.00 under v1.0 either way. `JE-TRU-V001-2026-12` amount `2500.00` -> `4000.00`. Variance vs tolerance $1,000.00 stays outside.

### 2.2 `CTL-ESCALATOR-DATE`

ScenarioOverride (worked example, V018 production effective 2027-01-01 -> 2027-02-01):
```json
{"override_id":"OVR-0002","control_id":"CTL-ESCALATOR-DATE","validator":"VAL-ESCALATOR-DATE",
 "target":{"kind":"PRICING_SCHEDULE","doc_id":"PS-018","vendor_id":"V018","contract_id":"CTR-018"},
 "param":{"production_effective_date":"2027-02-01"},"baseline_param":{"production_effective_date":"2027-01-01"},
 "visible_doc_changed":"contracts/pricing_schedules/PS-018.txt",
 "hidden_records_rederived":["INV-V018-001"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"3f80b6c1a9de"}
```
World parameters changed: `production_effective_date`. The validator moves the Pilot row's End date with it (VAL-ESCALATOR-DATE requires the two rows to tile the term with no gap: Pilot end becomes the day before the new Production start).
Derived visible files: `PS-018.txt` rows `Pilot | 2026-11-01 | 2026-12-31 | $12,000.00` / `Production | 2027-01-01 | ...` become `Pilot | 2026-11-01 | 2027-01-31 | $12,000.00` / `Production | 2027-02-01 | 2027-12-31 | $30,000.00`.
Hidden events/truth re-derived: `INV-V018-001` amount `30000.00` -> `12000.00` (January now falls in the Pilot row); `obligations_truth.csv` `OBL-V018-2027-01`: `true_expense` `30000.00`->`12000.00`, `policy_enabled_estimate` `30000.00`->`12000.00`, `true_contract_features.pricing_structure` stays `SCHEDULED_STEP`.
Before/after: frozen v1.0 accrual is $12,000.00 either way (order form pilot fee, date-blind). Frozen variance goes `+18,000.00` (outside $500.00) -> `0.00` (inside). Learned v1.1 accrual reads the PS-018 row covering the service period, so it also books $12,000.00 after the move; variance `0.00` either way. This is SCN-B's proof row that transfer reads dates, not a memorized number.

### 2.3 `CTL-SURCHARGE`

ScenarioOverride (worked example, V006 $0.00 -> $900.00):
```json
{"override_id":"OVR-0003","control_id":"CTL-SURCHARGE","validator":"VAL-SURCHARGE",
 "target":{"kind":"INVOICE_LINE_ITEM","invoice_id":"INV-V006-003","vendor_id":"V006","contract_id":"CTR-006"},
 "param":{"surcharge_amount":900.00},"baseline_param":{"surcharge_amount":0.00},
 "visible_doc_changed":null,
 "hidden_records_rederived":["INV-V006-003"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"c2d5f19e0a77"}
```
World parameters changed: `surcharge_amount` line item added to the invoice payload only. No contract text, no pricing schedule, no pre-cutoff evidence file changes (VAL-SURCHARGE forbids it), so nothing an agent could inspect before the invoice lands hints at the surcharge.
Derived visible files: none at stage time. `visible_doc_changed` is `null`; `#diff-panel` shows the "no visible document changes" text.
Hidden events/truth re-derived: `events.jsonl` `INVOICE_RECEIVED` payload for `INV-V006-003` gains a line item `{"description":"Year end expedite premium","quantity":1,"unit_price":900.00,"amount":900.00}`, `amount` `26270.00` -> `27170.00`; `obligations_truth.csv` `OBL-V006-2026-12` `true_expense` `26270.00` -> `27170.00`.
Before/after: v1.0 accrual is `142 x 185.00 = 26,270.00` either way (USAGE_X_RATE from timesheets, unaffected). Variance `0.00` -> `+900.00`, outside tolerance `max(500.00, 0.02x26270.00=525.40)=525.40`. `root_cause` stays `UNKNOWN`, outcome `ESCALATED`, no candidate policy (SCN-C).

### 2.4 `CTL-INVOICE-DELAY`

ScenarioOverride (worked example, V001 0 -> 21 days):
```json
{"override_id":"OVR-0004","control_id":"CTL-INVOICE-DELAY","validator":"VAL-INVOICE-DELAY",
 "target":{"kind":"EVENT_RELEASE","record_id":"INV-V001-008","vendor_id":"V001"},
 "param":{"delay_days":21},"baseline_param":{"delay_days":0},
 "visible_doc_changed":null,
 "hidden_records_rederived":["INV-V001-008"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"918d2c4bfa03"}
```
World parameters changed: the `events.jsonl` line's `release_at` for `INV-V001-008` only. Arithmetic: baseline `release_at = 2027-01-12T09:00:00`; `2027-01-12 + 21 days = 2027-02-02` (January has 31 days: day 12 + 21 = day 33 = Feb day 2), so new `release_at = 2027-02-02T09:00:00`. `invoice_date` (2026-12-31, the period end) is untouched; only `received_date` moves with `release_at`.
Derived visible files: none until Advance Time passes the new `release_at`.
Hidden events/truth re-derived: `events.jsonl` `release_at` field only; invoice content (amount, line items) unchanged; `obligations_truth.csv` `invoice_received_dates` `2027-01-12` -> `2027-02-02`.
Consistency: `VAL-INVOICE-DELAY` requires `release_at <= 2027-02-15T23:59:59` (T_END); `2027-02-02` passes. The obligation still resolves in the December close (accrual already posted); the true-up simply computes later, after a second Advance Time.

### 2.5 `CTL-SVC-CONFIRM`

ScenarioOverride (worked example, V001 CONFIRMED -> ABSENT):
```json
{"override_id":"OVR-0005","control_id":"CTL-SVC-CONFIRM","validator":"VAL-SVC-CONFIRM",
 "target":{"kind":"SERVICE_EVIDENCE","vendor_id":"V001","period":"2026-12"},
 "param":{"service_evidence":"ABSENT"},"baseline_param":{"service_evidence":"CONFIRMED"},
 "visible_doc_changed":"evidence/service_activity.csv",
 "hidden_records_rederived":[],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"5b9a0e73dc1f"}
```
World parameters changed: `evidence/service_activity.csv` row `SA-DATAFORGE-2026-12` is removed (not merely zeroed, since a zeroed row is still evidence of *something*); the scripted-inbox entry that would answer a `SERVICE_RECEIVED` outreach for V001/2026-12 is disabled (`response_type` forced to no match).
Derived visible files: before, `evidence/service_activity.csv` has `SA-DATAFORGE-2026-12,2026-12,DataForge Platform,V001,okta-sso+dataforge-admin-api,41,31,1284000,2026-12-01,2026-12-31,ACTIVE`; after, the row is absent from the file.
Hidden events/truth re-derived: no `events.jsonl` row is re-derived, so `hidden_records_rederived` is empty and `#diff-panel` block 2 reads "0 hidden records re-derived". The private scripted-response entry keyed `(V001, 2026-12, OPERATIONAL_OWNER, SERVICE_RECEIVED)` is dropped so `send_outreach` gets no reply; `obligations_truth.csv` `OBL-V001-2026-12` `verifier` `REVIEW_REQUIRED` -> `ESCALATE`, `outcome` `ACCRUED_THEN_RECONCILED` -> `ESCALATED`.
Before/after: with no service evidence and no reply, `PolicyEvaluation` invariant `SERVICE_RECEIPT_SUPPORTED` fails, result `ESCALATE` (control table rule: "ABSENT triggers ESCALATE, never a silent accrual"), routed to E001. `PENDING` (not used in this worked example) instead triggers `OUTREACH_REQUIRED` to the owner, matching the existing Brightwork mechanism.

### 2.6 `CTL-USAGE-SPIKE`

ScenarioOverride (worked example, V002 1.0x -> 1.5x):
```json
{"override_id":"OVR-0006","control_id":"CTL-USAGE-SPIKE","validator":"VAL-USAGE-SPIKE",
 "target":{"kind":"USAGE_DAILY","vendor_id":"V002","period":"2026-12","contract_id":"CTR-002"},
 "param":{"spike_multiplier":1.5},"baseline_param":{"spike_multiplier":1.0},
 "visible_doc_changed":"evidence/usage_daily.csv",
 "hidden_records_rederived":["INV-V002-008"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"a4c0f7e2b615"}
```
World parameters changed: every December `compute_hours` row for V002 multiplied by 1.5, last day absorbing the rounding remainder so the monthly total is exact.
Arithmetic: baseline December total `352,000` hours -> `352,000 x 1.5 = 528,000` hours. CTR-002 rate card: `300,000` included hours in the `$36,000.00` commit, `$0.15`/hour overage. Overage hours `528,000 - 300,000 = 228,000`; overage cost `228,000 x 0.15 = 34,200.00`; total `36,000.00 + 34,200.00 = 70,200.00`.
Derived visible files: `evidence/usage_daily.csv` December rows for V002, each `quantity` scaled (e.g. `2026-12-01` row `11,532` -> `17,298`).
Hidden events/truth re-derived: `INVOICE_RECEIVED` payload for `INV-V002-008` `amount` `43800.00` -> `70200.00`; `obligations_truth.csv` `OBL-V002-2026-12` `true_expense` `43800.00`->`70200.00`, `static_rules_estimate` matches (USAGE_X_RATE is always correct, per section 4.2 note that the deterministic estimator applies the full tiered rate card regardless of spike size); `static_error` stays `0.00`.
Before/after: v1.0 accrual is `USAGE_X_RATE` over the full tiered rate card at either multiplier, so the accrual is always correct and the true-up is always `$0.00`; the control demonstrates that usage-based methods do not miss, unlike the fixed-fee escalator case.

### 2.7 `CTL-DUP-INVOICE`

ScenarioOverride (worked example, V008 NONE -> EXACT_COPY on `INV-V008-008`):
```json
{"override_id":"OVR-0007","control_id":"CTL-DUP-INVOICE","validator":"VAL-DUP-INVOICE",
 "target":{"kind":"INVOICE","invoice_id":"INV-V008-008","vendor_id":"V008","po_id":null},
 "param":{"duplicate":"EXACT_COPY"},"baseline_param":{"duplicate":"NONE"},
 "visible_doc_changed":"invoices/invoices.json",
 "hidden_records_rederived":["INV-V008-008-DUP"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"e6712fbc409a"}
```
World parameters changed: a second `INVOICE_RECEIVED` event is inserted, same PO (none for V008), amount `22500.00`, same service period as `INV-V008-008` (December rent, billed in advance). The original is a seed record (`received_date 2026-11-25`, before T0), so the duplicate cannot be released one day after it without landing in the CLOSED 2026-11 period; its `release_at` is `2027-01-05T09:00:00`, the day after the demo start clock and before the 2026-12 cutoff instant `2027-01-05T23:59:59`, so it arrives inside the open December close.
Derived visible files: `invoices/invoices.json` gains one record; `invoice_id` = `INV-V008-008-DUP` (original id plus suffix, per validator "duplicate gets a new invoice_id with the same number plus suffix"); `invoice_number` stays `ON-2256` for `EXACT_COPY`, or becomes `ON-2256-B` for `NEW_NUMBER`. `ap_queue.csv` gains `AP-V008-008-DUP` with `status = ON_HOLD`.
Hidden events/truth re-derived: `extra_exceptions.json` gains one entry keyed `EXC-INV-V008-008-DUP` (the `EXC-<invoice_id>` form of `EXC-INV-V012-004`); `obligations_truth.csv` is unchanged for `OBL-V008-2026-12` itself (`true_expense` still `22500.00`, one payment) because the duplicate must never post a second time.
Before/after: `PolicyEvaluation` invariant `NO_DUPLICATE_ACCRUAL` fails on the second row, `invoice_status = DUPLICATE_SUSPECTED`, result `BLOCK`, `status = HOLD_DO_NOT_POST`, E003 notified. No second GL entry, no accrual change. `NEW_NUMBER` reaches the same result because `VAL-DUP-INVOICE` matches on PO + amount + service period, not on invoice number.

### 2.8 `CTL-TERMINATE`

ScenarioOverride (worked example, V005 NONE -> 2026-12-15):
```json
{"override_id":"OVR-0008","control_id":"CTL-TERMINATE","validator":"VAL-TERMINATE",
 "target":{"kind":"TERMINATION_NOTICE","doc_id":"TN-005","vendor_id":"V005","contract_id":"CTR-005"},
 "param":{"termination_effective":"2026-12-15"},"baseline_param":{"termination_effective":"NONE"},
 "visible_doc_changed":"contracts/notices/TN-005.txt",
 "hidden_records_rederived":["INV-V005-008-FINAL","INV-V005-009"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"0d4b6a2f8871"}
```
World parameters changed: a new termination notice document `TN-005` is created, `effective_date = 2026-12-15`, filed by the owner E011 with a 30-day notice citation matching the TN-019 pattern.
Arithmetic (final prorated fee): `CTR-005` December fee `$6,400.00`; December has 31 days; days served `1..15 = 15` days. `6400.00 x 15 / 31 = 3096.774...`, half-up to 2 decimals `= 3096.77`.
Derived visible files: `contracts/notices/TN-005.txt` created (new doc, effective line `2026-12-15`); `contracts/index.json` gains one `TERMINATION_NOTICE` row; `evidence/service_activity.csv` V005's `last_activity_date` set to `2026-12-15`, `service_status` `PARTIAL`.
Hidden events/truth re-derived: `INV-V005-008` (December, previously `$6,400.00`) re-derived to `$3,096.77` service `2026-12-01..2026-12-15`; `INV-V005-009` (January, previously `$6,400.00`) deleted from `events.jsonl`; `obligations_truth.csv` `OBL-V005-2026-12` `method` `FIXED_CONTRACT_FEE`->`PRORATED_FEE`, `true_expense` `6400.00`->`3096.77`; `OBL-V005-2027-01` `outcome` `NO_ACCRUAL_DOCUMENTED`, `true_expense` `0.00`.
Before/after: v1.0 books `PRORATED_FEE $3,096.77` for December (contract term and prorated-days basis are both pre-cutoff visible), approval `NONE` (below $10,000.00 with confidence >= 0.85, the same route as Beacon's $1,838.71 proration). January: no invoice expected, classification `NO_INVOICE_SERVICE_NOT_RECEIVED`, cites `TN-005`, outcome `NO_ACCRUAL_DOCUMENTED`.

### 2.9 `CTL-CADENCE`

ScenarioOverride (worked example, V014 QUARTERLY_ARREARS -> MONTHLY_ARREARS):
```json
{"override_id":"OVR-0009","control_id":"CTL-CADENCE","validator":"VAL-CADENCE",
 "target":{"kind":"CONTRACT_CLAUSE","doc_id":"CTR-014","vendor_id":"V014","contract_id":"CTR-014"},
 "param":{"billing_cadence":"MONTHLY_ARREARS"},"baseline_param":{"billing_cadence":"QUARTERLY_ARREARS"},
 "visible_doc_changed":"contracts/CTR-014.txt",
 "hidden_records_rederived":["INV-V014-003-NOV","INV-V014-003-DEC","INV-V014-003-JAN"],
 "staged_at":"2027-01-04T09:00:00","applied_by":"JUDGE",
 "start_clock":"2027-01-04T09:00:00","world_hash":"79f13cd0e4a6"}
```
World parameters changed: `billing_cadence` clause text in `CTR-014.txt` (`ANNUAL_FEE = 12 x $4,500.00 = $54,000.00` held constant, per VAL-CADENCE).
Arithmetic: quarterly invoice was `3 x $4,500.00 = $13,500.00` in one document; monthly cadence gives three invoices of `$54,000.00 / 12 = $4,500.00` each, same figure the vendor table already lists ("typical monthly $4,500"), so no rate changes, only the invoicing pattern.
Derived visible files: `contracts/CTR-014.txt` billing clause paragraph replaced; the single quarterly invoice (`INV-V014-003`, `$13,500.00`, `service 2026-11-01..2027-01-31`, `release_at 2027-02-08`) is replaced in `events.jsonl` by three monthly invoices `$4,500.00` each, service periods `2026-11-01..2026-11-30`, `2026-12-01..2026-12-31`, `2027-01-01..2027-01-31`, released on the 8th of the following month at 09:00, the lag the baseline quarterly invoice already uses (`INV-V014-003` releases `2027-02-08T09:00:00`): `2026-12-08`, `2027-01-08`, `2027-02-08`.
Hidden events/truth re-derived: `obligations_truth.csv` `OBL-V014-2026-11`, `OBL-V014-2026-12`, `OBL-V014-2027-01` each keep `true_expense 4500.00`; `actual_invoice_ids` changes from the one shared `INV-V014-003` to one invoice id per period; `invoice_received_dates` changes from the single quarterly date to three separate dates.
Before/after: v1.0 already accrues `$4,500.00` FIXED_CONTRACT_FEE per month under quarterly cadence (case C02). Under monthly cadence the accrual amount and approval (`NONE`, confidence >= 0.85) are unchanged; only the invoice-matching pattern changes from a single three-way split (`InvoiceMatch` rows with `allocated_amount`) to three one-to-one matches.

## 3. Consistency invariants checked after every mutation

`POST /sim/overrides/apply` runs these checks, in order, against the rebuilt world before it is written to `runtime/visible/`. Any failure rejects the apply, leaves the world unchanged, and returns the failing invariant name to `#lab-panel`.

| # | Invariant | Check |
|---|---|---|
| INV-1 | GL balanced | For every regenerated `entry_id`, sum of `debit` == sum of `credit` across its lines; total debits == total credits across `gl_entries.csv`. |
| INV-2 | Invoice equals pricing function | For every hidden invoice tied to a mutated contract, `amount` == the contract's pricing function evaluated at that invoice's `service_period_start`, to the cent. |
| INV-3 | Effective date inside term | Any `effective_date` or `termination_effective` parameter satisfies `term_start <= date <= term_end` from `ContractFeatures`; `CTL-TERMINATE` additionally requires `date >= 2026-12-01` (no edit to a CLOSED period). |
| INV-4 | Cadence tiles without gap or overlap | `CTL-CADENCE` and the date half of `CTL-ESCALATOR-DATE`: consecutive service periods for one vendor have no gap day and no overlap day across the full contract term. |
| INV-5 | Duplicate keeps its key | `CTL-DUP-INVOICE` output has the same `po_id`, `amount` and service period as the source row, a distinct `invoice_id`, and exactly one `goods_receipts.csv` row (unchanged). |
| INV-6 | No leaked future fact | L1 of `WORLD_SPEC.md` 3.7 re-run against the rebuilt `runtime/visible/`: no checked date field exceeds the current clock; the mutated amount does not appear in any visible file before its own event's `release_at`. |
| INV-7 | Truth re-derived, never edited | `obligations_truth.csv`, `future_invoices.csv` and `expected_matches.csv` are fully regenerated from `world.py` given the new parameters; the applier never writes to these files directly, and a diff of the regeneration touches only rows whose `obligation_key` depends on the mutated `vendor_id`/`contract_id`. |
| INV-8 | Policy scope untouched | The mutation never edits `policies.json`, `trueup_playbook.db`, or any `POL-000N` record; only world facts change. |
| INV-9 | One override, one log line | `runtime/mutation_log.jsonl` gains exactly one `MUT-000N` row per apply, `sim_state.json.overrides` holds the same `override_id`; a second apply without `allow_multi=true` is rejected before any file write. |
| INV-10 | Budget | Stage returns in under 300ms; apply (regeneration plus INV-1..INV-9) completes in under 2 seconds, per `00-decisions.md` 1.4. |


---

# 02 State machine, clock control and hidden-data protection

Scope: deliverables 3 and 4, and the button semantics half of deliverable 6 for `btn-run-close`, `btn-advance-time`,
`btn-reset-world`, `btn-reset-demo`. State names, clocks and transition guards are taken verbatim from
`00-decisions.md` section 3; this file adds the per-state visibility detail, the four buttons' exact contract, and
hidden-data protection. `btn-approve-accrual`, `btn-investigate`, `btn-run-replay`, `btn-approve-policy`,
`btn-reject-policy` and `btn-run-transfer` are owned by `03-playbook-memory-and-api.md`; they are referenced here
only where a state's enabled-button list names them. `btn-apply-mutation` and `btn-undo-mutation` are owned by
`01-scenario-lab-and-mutations.md`.

## 1. State table: clock, buttons, visibility

Every row uses the state name and clock exactly as `00-decisions.md` section 3 gives it.

| State | Clock on entry | Enabled buttons | What is on screen |
|---|---|---|---|
| `IDLE_BASELINE` | 2027-01-04T09:00:00 | Apply Change (disabled until staged), Run Close, Reset World, Reset Demo | `#clock-bar` clock, playbook badge, 12-hex `world_hash`; `#lab-panel` control/vendor/parameter pickers empty; `#close-board` December inventory under the active playbook, `OBL-V001-2026-12` `invoice_status=MISSING` |
| `MUTATION_STAGED` | 2027-01-04T09:00:00 | Apply Change, Undo Change | `#diff-panel` shows the staged document diff from `POST /sim/overrides/stage` (before/after text, no world change yet); `#lab-panel` highlights the chosen control |
| `MUTATION_APPLIED` | 2027-01-04T09:00:00 | Run Close, Undo Change | `#diff-panel` shows the applied diff; `#clock-bar` `world_hash` has changed from baseline; `#close-board` still shows the December inventory, now built from the mutated world |
| `CLOSE_RUNNING` | 2027-01-04T09:00:00 to 2027-01-05T15:30:00 | none | `#evidence-trail` streams `ToolCall` rows live (`GET /api/evidence-trail`); `#close-board` and `#workpaper` are read-only while the run is in flight |
| `CLOSE_AWAITING_APPROVAL` | 2027-01-05T16:00:00 | Approve Accrual (03) | `#workpaper` S2: calculation trace, draft `JE-ACR-*`, verifier checklist, `required_approval_level` |
| `CLOSE_POSTED` | 2027-01-05T23:59:59 | Advance Time | `#workpaper` shows the posted entry and the 2027-01-01 reversal; `#clock-bar` period 2026-12 status `CLOSED` |
| `TRUEUP_COMPUTED` | 2027-01-12T09:00:00 (SCN-A), 2027-01-15T09:00:00 (SCN-C) | Investigate Variance | `#trueup-panel` S4: matched invoice, variance, tolerance test, row highlighted red because `abs(variance) > tolerance` |
| `NO_MISS` | same as above | Advance Time, Reset World, Reset Demo | `#trueup-panel` shows variance 0.00, row highlighted green, no `Investigate Variance` button |
| `INVESTIGATING` | 2027-01-13T09:00:00 (SCN-A), 2027-01-15T11:00:00 (SCN-C) | none | `#evidence-trail` streams the classifier's tool calls (open `PS-001` / `PS-018`, re-read `service_activity`) |
| `ROOT_CAUSE_FOUND` | 2027-01-13T09:00:00 | Run Replay | `#trueup-panel` adds `root_cause`, `process_cause`, cited evidence ids and quotes |
| `ROOT_CAUSE_UNKNOWN` | 2027-01-15T11:00:00 | none | `#trueup-panel` shows `root_cause=UNKNOWN`, `process_cause=NO_CONTRACTUAL_BASIS`; no policy panel content |
| `ESCALATED` | 2027-01-15T12:00:00 | Reset World, Reset Demo | `#audit-panel` shows the `EscalationNote` to E001 with both source figures where applicable; no candidate policy anywhere on screen |
| `CANDIDATE_READY` | 2027-01-13T09:30:00 | Run Replay | `#learning-panel` S5: candidate `POL-0001` JSON, scope, required evidence; no vendor id visible in the record |
| `CANDIDATE_BLOCKED` | 2027-01-13T09:30:00 (guard G1) or 2027-01-13T11:00:00 (guard G2) | Reject Policy (03), Reset World | `#learning-panel` names the failing guard (G1 or G2) next to a disabled `Approve Policy` |
| `REPLAY_REPORT_READY` | 2027-01-13T11:00:00 | Approve Policy (03), Reject Policy (03) | `#learning-panel` replay report: improved/regressed/unchanged counts, `touched[]` list, `abs_error_before/after` |
| `POLICY_APPROVED` | 2027-01-15T10:00:00 | Advance Time, Run Transfer Compare | playbook badge reads 1.1; `#learning-panel` shows the approval record |
| `POLICY_REJECTED` | 2027-01-15T10:00:00 | Advance Time, Run Transfer Compare | playbook badge stays 1.0; `#learning-panel` shows the rejection event, POL-0001 status `REJECTED` |
| `TRANSFER_RUNNING` | 2027-02-05T09:00:00 | none | `#evidence-trail` streams two labeled tool-call streams, `frozen` and `learned` |
| `TRANSFER_COMPARED` | 2027-02-12T09:00:00 | Reset World, Reset Demo | `#transfer-panel` split view and predicate match line; `#audit-panel` packet for `OBL-V018-2027-01` |

## 2. ASCII diagram

```
IDLE_BASELINE -(lab sel.)-> MUTATION_STAGED -(Apply Change)-> MUTATION_APPLIED
     ^   |                       ^  |                                |
     |   '---(Undo Change)------'  '-----------(Undo Change)---------'
     |
     +--(Run Close, 2026-12 OPEN)--> CLOSE_RUNNING --(REVIEW/CONTROLLER)--> CLOSE_AWAITING_APPROVAL
     |                                    |                                        |
     |                             (ESCALATE)                              (Approve Accrual, 03)
     |                                    v                                        v
     |                                ESCALATED <--------------------------- CLOSE_POSTED
     |                                 ^  ^  ^                                     |
     |                                 |  |  |                            (Advance Time)
     |                                 |  |  |                                     v
     |                                 |  |  |                            TRUEUP_COMPUTED --(<=tol)--> NO_MISS
     |                                 |  |  |                                     |
     |                                 |  |  |                            (>tol, Investigate)
     |                                 |  |  |                                     v
     |                                 |  |  '----(cause UNKNOWN)-------- INVESTIGATING
     |                                 |  |                                       |
     |                                 |  '--(evidence_existed_at_close=false)--- ROOT_CAUSE_FOUND <-(cause found)-'
     |                                 |                                          |
     |                          (guard G2 fails)              (evidence_existed_at_close=true, POST /api/policy/candidate)
     |                                 |                                          |
     |                          CANDIDATE_BLOCKED <--------(guard G1 fails)-------+--(G1 passes)--> CANDIDATE_READY
     |                                 ^                                                                  |
     |                                 |                                                          (Run Replay) --> REPLAY_REPORT_READY
     |                                 |                                                                    |         |
     |                        (Reject Policy, 03)                                              (Approve, 03)   (Reject, 03)
     |                                 v                                                                    v         v
     |                          POLICY_REJECTED <---------------------------------------------------  POLICY_APPROVED  POLICY_REJECTED
     |                                 |                                                                    |
     |                     (Run Transfer Compare, clock >= 2027-02-01, also from NO_MISS)------------------'
     |                                 v
     |                          TRANSFER_RUNNING --(both arms finish)--> TRANSFER_COMPARED
     |
     '== Reset World / Reset Demo (fixture_hash check) reachable from every state above, always land on IDLE_BASELINE ==
```

## 3. Button semantics

### 3.1 `btn-run-close` -> `POST /api/close/run`

**Precondition.** State is `IDLE_BASELINE` or `MUTATION_APPLIED`, and `company.json.close_calendar` period `2026-12`
has `status = OPEN`. The button is not rendered in any other state, so the precondition is also enforced client side.

**Side effects.** Creates `AgentRun` `RUN-000N`. Runs Discover, Gather, Classify, Estimate, Verify, Outreach (if the
verifier's `next_action` names one), Work product, in that order, against `runtime/visible/` only. The deterministic
estimator computes `estimated_amount` from `calculation_trace.formula`; the LLM only classifies evidence, drafts
outreach text and reads the verifier checklist to decide `next_action`. Writes `ActionProposal` `PRP-V001-2026-12-01`
and `PolicyEvaluation` `PE-V001-2026-12-01`. Transitions to `CLOSE_AWAITING_APPROVAL` when
`required_approval_level != NONE`, or to `ESCALATED` when the verifier result is `ESCALATE`.

**Idempotency.** While `demo_state.state == CLOSE_RUNNING` the endpoint returns `409 {"state": "CLOSE_RUNNING"}` and
starts no second `AgentRun`. Once posted, calling it again is impossible from the UI (the button is absent in
`CLOSE_AWAITING_APPROVAL` and later states); a direct API call still returns `409` naming the current state.

**Failure handling.** A live model-call failure or a deterministic-code exception moves the state to `ESCALATED`
with the raw error text shown in `#evidence-trail` and an `EscalationNote` with `target_role = CONTROLLER`,
`reason = "AGENT_RUN_FAILED"`. The run never falls back to a cached answer once it has started live (cached answers
only apply to a full run under `TRUEUP_DEMO_MODE=cached` before the run starts).

### 3.2 `btn-advance-time` -> `POST /api/lab/sim/advance` then, when the target crosses a true-up point, `POST /api/trueup/run`

**Precondition.** State is `CLOSE_POSTED` (target state `TRUEUP_COMPUTED`), or `NO_MISS` / `POLICY_APPROVED` /
`POLICY_REJECTED` with the target clock at or after `2027-02-01T00:00:00` (state unchanged; the advance is what
enables `btn-run-transfer`). The button carries a fixed `target_ts` per source state and active scenario; it is
never a free-text field, so a judge cannot jump the clock past the next release point and see a future fact early.
`target_ts` values: `CLOSE_POSTED` -> `2027-01-12T09:00:00` (SCN-A) or `2027-01-15T09:00:00` (SCN-C, second true-up
at `2027-01-22T09:00:00` if the judge re-runs the button); `NO_MISS`/`POLICY_APPROVED`/`POLICY_REJECTED` ->
`2027-02-05T09:00:00`.

**Side effects.** Calls `sim.advance_to(target_ts)`, which applies every `events.jsonl` row with
`clock < release_at <= target_ts` and every inbox delivery due in that window, in one merged time order (ties break
by `event_id`, WORLD_SPEC 3.6). `#diff-panel` lists the released `record_id`s. When the target crosses `2026-12-05`,
`2027-01-05`, `2027-02-05` or `2027-02-01T00:00:00`, the simulator snapshots `runtime/visible/` automatically. Once
the clock lands, and only from `CLOSE_POSTED`, the backend runs deterministic matching and the tolerance test
(section 4) and sets state to `TRUEUP_COMPUTED` (falling straight through to `NO_MISS` inside the same request when
the variance is inside tolerance). From `NO_MISS`, `POLICY_APPROVED` or `POLICY_REJECTED` the state is unchanged and
`btn-run-transfer` becomes enabled; `TRANSFER_RUNNING` is entered only by `btn-run-transfer`
(`00-decisions.md` section 3).

**Idempotency.** `ts == clock` is a no-op per the simulator contract; the endpoint returns the current state
unchanged. `ts < clock` raises `ClockRegressionError`; the API returns `400` and the UI shows "cannot go
backward", state unchanged. The button is disabled once its `target_ts` has been reached.

**Failure handling.** If `sim.advance_to` succeeds but the deterministic match/tolerance step throws (bad match key,
missing invoice), the clock has still moved (the simulator call already committed), but `demo_state.state` stays
`CLOSE_POSTED` and an error banner names the obligation; the judge can retry `Run Replay`-style via a plain retry of
`Advance Time`, which is a no-op on the clock and only retries the matching step.

### 3.3 `btn-reset-world` -> `POST /api/reset/world` -> `POST /sim/reset/world`

**Precondition.** None; enabled in every state.

**Side effects.** Clears all `ScenarioOverride`s, regenerates `world/seed/` and `world/private/` with no override
applied, deletes and rebuilds `runtime/visible/` from that seed, resets `sim_state.json` (`clock`, `released_event_ids`,
`pending_deliveries`) and fast-forwards the clock to `2027-01-04T09:00:00`. Wipes every table in `trueup_state.db`
(`obligations`, `proposals`, `evaluations`, `journal_entries`, `trueups`, `agent_runs`, `tool_calls`,
`demo_state`, ...). Does **not** touch `trueup_playbook.db`: if `POL-0001` was already approved, the playbook badge
still reads 1.1 after this reset. Sets `demo_state.state = IDLE_BASELINE`.

**Idempotency.** Safe to call from any state, any number of times; the result is always the same baseline
`world_hash` (no override survives) and `IDLE_BASELINE`. Calling it twice in a row is a no-op the second time except
for the wall-clock cost of rebuilding.

**Failure handling.** The rebuild writes to a temporary runtime directory and renames it into place atomically, so a
failure mid-rebuild (regeneration exceeds the under-2-second budget, or throws) leaves the previous `runtime/`
untouched; the endpoint returns `500` and the UI keeps the pre-reset state with an error banner. `demo_state.state`
only changes to `IDLE_BASELINE` after the rename succeeds.

### 3.4 `btn-reset-demo` -> `POST /api/reset/demo` -> `POST /sim/reset/demo`

**Precondition.** None; enabled in every state.

**Side effects.** Everything `Reset World` does, plus: drops and re-seeds `trueup_playbook.db` at version 1.0
(`POL-0001`, if it existed, is gone; `playbook_versions` has one row, `1.0`, `FROZEN`, matching the seed row of
`03-playbook-memory-and-api.md` section 9 item 5). Computes `fixture_hash` over
the fresh `world/seed/`, `world/private/events.jsonl` and `world/private/truth/`, and asserts it equals
`BASELINE_FIXTURE_HASH` from `data/demo_spec/BASELINE_HASH.txt`. `#clock-bar` prints both hashes' 12-hex prefixes.

**Idempotency.** Always returns to the identical starting point: `world_hash` = baseline, playbook 1.0, no
overrides, `demo_state.state = IDLE_BASELINE`.

**Failure handling.** The `any -> IDLE_BASELINE` transition guard requires `fixture_hash == BASELINE_FIXTURE_HASH`
after rebuild. If it fails (generator drift, not a runtime condition), the state machine does **not** transition;
the button surfaces "baseline drift" with both hashes side by side and the run is not recoverable live. The
presenter restarts the `sim` process from a clean checkout rather than retrying the button.

## 4. Advance Time: matching, variance, true-up, failure highlight

**Release.** `Advance Time` releases every `events.jsonl` row with `release_at` in `(old_clock, target_ts]` plus any
inbox reply whose `sent_at + delay_hours` falls in that window (WORLD_SPEC 3.4, 3.5). For SCN-A at `target_ts =
2027-01-12T09:00:00` this releases `EVT` rows for `INV-V001-008` (`invoices/invoices.json`, `ap_queue.csv` side
effect) and nothing else pending.

**Match keys.** Deterministic, no LLM call. For a plain vendor-month obligation: `(invoice.vendor_id ==
obligation.vendor_id) AND (invoice.service_period_start == obligation.service_period_start) AND
(invoice.service_period_end == obligation.service_period_end)` -> `ONE_TO_ONE`, `allocated_amount = invoice.amount`.
When an invoice's service period spans more than one `close_period`, allocate by the invoice's own
`allocation_basis` recorded at generation time (`DAILY_PRORATA` for a mid-month start such as Quantive V015,
`EQUAL_MONTHS` for a flat monthly fee billed in one shot such as Atlas V014) and emit one `InvoiceMatch` row per
obligation touched, `allocated_amount`s summing to `invoice.amount`. A second invoice with the same `(vendor_id,
service_period_start, service_period_end, po_id, amount)` as an already-matched one is `NO_MATCH_DUPLICATE`
(`match_type`), never posted, `HOLD_DO_NOT_POST`.

**Variance and tolerance.** `variance = allocated_amount - accrued_amount` (sign: actual minus accrued).
`tolerance = max(500.00, 0.02 * accrued_amount)`. `outside_tolerance = abs(variance) > tolerance`. SCN-A:
`variance = 52500.00 - 50000.00 = 2500.00`; `tolerance = max(500.00, 0.02*50000.00) = 1000.00`; `2500.00 > 1000.00`,
outside.

**True-up JE.** When `variance != 0.00`: `JE-TRU-<vendor_id>-<period>`, `Dr <expense account> / Cr 2000`, amount
`abs(variance)` (sign flips the debit/credit pair if `variance < 0`), dated the invoice's `received_date`,
`entry_type = TRUE_UP`, `obligation_id` set. When `variance == 0.00` no `JE-TRU-` row is created. SCN-A:
`JE-TRU-V001-2026-12`, Dr 6100 / Cr 2000, $2,500.00, dated `2027-01-12`.

**Failure highlight.** `/api/trueup/run` writes `TrueUpAdjustment.within_tolerance = false` when outside tolerance.
`#trueup-panel` renders that obligation's row with a red background, the variance figure in red with a `+`/`-`
sign, and shows the `Investigate Variance` button only on that row. The state machine stays at `TRUEUP_COMPUTED`
(does not auto-advance to `NO_MISS`) exactly when `within_tolerance = false`.

## 5. Hidden-data protection

**Process and directory boundary.** `sim` (port 8100) and `trueup` (port 8000) are separate OS processes. `sim`
alone opens `world/seed/`, `world/private/`, `runtime/sim_state.json`, `runtime/mutation_log.jsonl` and
`runtime/outreach_log.jsonl`. `trueup` has no `TRUEUP_WORLD_DIR` (or any) environment variable pointing at `world/`;
its only channel to `sim` is HTTP, through `ANY /api/lab/{path}`, a byte passthrough proxy that imports nothing from
`data/gen`. `trueup` owns `trueup_state.db` and `trueup_playbook.db`; `sim` never opens either.

**Tool-layer visibility filter.** Every TrueUp tool (`read_file`, `list_dir`, `send_outreach`) is bound to a
`VisibleRoot` object rooted at `runtime/visible/`. It resolves relative paths, rejects absolute paths, `..`
segments, and symlinks that leave the root. Each call is logged as `ToolCall` `TC-0001-007` and streamed to
`#evidence-trail`; the log itself lives in `trueup_state.db`, not under `runtime/visible/`.

**Excluded from the LLM context, always:** `runtime/mutation_log.jsonl`; `sim_state.json` (clock internals,
`released_event_ids`, `pending_deliveries`); every file under `world/private/` (`events.jsonl`, `truth/`,
`inbox/scripted_responses.json`, `documents/` staging area); the Lab's staged/active `ScenarioOverride` list
(`OVR-000N` records) and `overrides.baseline_param` values; any visible record whose `release_at` (or `sent_at`,
`received_date`) is later than the current simulated clock; the full 64-hex `world_hash` (only its 12-hex UI prefix
is shown, and that prefix is UI-only, never passed to a tool call or a prompt).

**Pinned snapshot for Frozen vs Learned.** The fork point is snapshot `2027-01-open`, taken automatically when
`advance_to` crosses `2027-02-01T00:00:00`. `btn-run-transfer` calls `sim.fork("2027-01-open", "frozen")` and
`sim.fork("2027-01-open", "learned")`, producing two runtimes with byte-identical `runtime/visible/` and
`sim_state.json` (asserted by leakage test L4 below). The frozen TrueUp instance is pinned to playbook version
`1.0`; the learned instance to `1.1`. Model, prompts, tool set and estimator code are identical between the two;
`agent_run.agent_build_hash` is logged and compared equal for both arms.

**Automated leakage tests, run after every judge mutation (`Apply Change`), every `Advance Time`, and at demo start.**

| # | Assertion |
|---|---|
| LK1 | `test_no_future_dated_records`: for every JSON/CSV/JSONL under `runtime/visible/`, every date-typed field in WORLD_SPEC L1's checked-field list is `<= demo_state.clock`. Run at every snapshot and after every `Advance Time`. |
| LK2 | `test_visible_root_rejects_escape`: a tool call with path `../sim_state.json`, `../../world/private/events.jsonl`, an absolute path, or a planted symlink leaving `runtime/visible/` raises `PathEscapeError` and is never opened. |
| LK3 | `test_tool_source_has_no_private_refs`: `grep -rE "world/private|sim_state|mutation_log|scripted_responses|outreach_log" trueup/` (the `trueup` package tree) returns zero matches outside the `/api/lab/*` proxy module. |
| LK4 | `test_mutation_log_never_visible`: after every `Apply Change`, `runtime/mutation_log.jsonl` is not present under `runtime/visible/`, and no `ToolCall.result` field contains the string `OVR-` or `override_id`. |
| LK5 | `test_fork_parity`: after `Run Transfer Compare`, the `frozen` and `learned` runtimes have equal `world_hash` and equal `sim_state.json`; their `trueup_state.db` differ only in `policy_version_used` and the rows attributable to `POL-0001`. |
| LK6 | `test_no_banned_tokens`: a regex scan of every file under `runtime/visible/` for `EVT-\d`, `RSP-\d`, `OVR-\d`, `MUT-\d`, `\bC(0[1-9]|1[0-2])\b`, `TRAIN`, `HELDOUT`, `true_expense`, `scenario`, `root_cause`, `has_scheduled_price_change` returns zero matches. |
| LK7 | `test_amount_allowlist_after_mutation`: for a judge-set `CTL-ESCALATOR-PCT` value on V001 (e.g. `escalator_pct=8` -> CY2 fee `54000.00`), the string `54,000`/`54000` occurs only in `contracts/pricing_schedules/PS-001.*` before `INV-V001-008` releases, and nowhere in `runtime/visible/` before the mutation is applied. |
| LK8 | `test_timing_replies_have_no_amount`: the regex `\$?\d{2,3}(,\d{3})+` matches nothing in the `body` or `structured_facts` of any `INVOICE_WHEREABOUTS` reply for V001 or V018, under any staged mutation. |
| LK9 | `test_replay_inputs_bounded`: every obligation cited in a `RPL-POL-0001` replay report belongs to period `2026-11` or `2026-12`; every cited evidence id exists in snapshot `2026-11-cutoff` or `2026-12-cutoff`; every cited actual has `received_date <= run_at`. |
| LK10 | `test_advance_time_no_overshoot`: `POST /sim/advance` rejects (`400`) any `ts` beyond the `target_ts` set named in section 3.2 for the current `demo_state.state` and active scenario; the UI never sends a free-text target. |
| LK11 | `test_no_po_back_solve`: for every offered parameter value of `CTL-ESCALATOR-PCT` and `CTL-ESCALATOR-DATE`, and for every purchase order linked to the affected obligation, `abs(purchase_order.authorized_amount / 12 - resulting_monthly_fee) > max(500.00, 0.02 x resulting_monthly_fee)`. With PO-1063 pinned at `415000.00` (`00-decisions.md` section 1), `415000.00 / 12 = 34583.33` against offered fees 12,000.00 / 24,000.00 / 30,000.00 / 33,000.00 gives a minimum gap of `34583.33 - 33000.00 = 1583.33`, above the $500.00 tolerance. Run after every `Apply Change`. |


---

# 03 Playbook Memory and API

Scope per `00-decisions.md` section 6: playbook memory, policy lifecycle, replay, Approve/Reject semantics, Frozen vs Learned runner, the full API surface (sim and trueup), the evidence-trail SSE stream, backend delta and build checklist. Binding on ids, enums, table and column names in `00-decisions.md` section 5 and `WORLD_SPEC.md` sections 2.3-2.6 and 4.6.

## 1. SQLite DDL

`trueup_playbook.db`, survives Reset World, dropped and re-seeded at version 1.0 only by Reset Demo.

```sql
CREATE TABLE playbook_versions (
  version         TEXT PRIMARY KEY,                 -- '1.0', '1.1'
  parent_version  TEXT REFERENCES playbook_versions(version),
  status          TEXT NOT NULL CHECK (status IN ('FROZEN','PROVISIONAL','ACTIVE')),
  created_at      TEXT NOT NULL,
  activated_at    TEXT,
  policies_json   TEXT NOT NULL,                    -- JSON array of policy_id in force at this version
  fixture_hash    TEXT NOT NULL                     -- fixture_hash this version was built/replayed against
);

CREATE TABLE policies (
  policy_id                       TEXT PRIMARY KEY,          -- 'POL-0001'
  policy_type                     TEXT NOT NULL,
  trigger                         TEXT NOT NULL,
  scope_json                      TEXT NOT NULL,             -- 1.7 whitelist fields only
  required_evidence_json          TEXT NOT NULL,
  before_action                   TEXT NOT NULL,
  verifier_result_if_missing_json TEXT NOT NULL,
  outreach_if_missing_json        TEXT NOT NULL,
  behavior_change                 TEXT NOT NULL,
  autonomy_limit                  TEXT NOT NULL,
  derived_from_json               TEXT NOT NULL,             -- {outcome_id, root_cause_id}
  status                          TEXT NOT NULL CHECK (status IN
                                     ('CANDIDATE','BLOCKED','ACTIVE_PROVISIONAL','ACTIVE','REJECTED','REVOKED')),
  created_at                      TEXT NOT NULL,
  policy_version_target           TEXT NOT NULL REFERENCES playbook_versions(version)
);

CREATE TABLE policy_events (
  event_id     TEXT PRIMARY KEY,               -- 'PEV-0001'
  policy_id    TEXT NOT NULL REFERENCES policies(policy_id),
  event_type   TEXT NOT NULL CHECK (event_type IN
                  ('CANDIDATE_CREATED','GUARD_G1_BLOCKED','REPLAY_RUN','GUARD_G2_BLOCKED',
                   'POLICY_APPROVED','POLICY_REJECTED','POLICY_PROMOTED','POLICY_REVOKED')),
  actor        TEXT NOT NULL,                  -- employee_id or 'SYSTEM'
  decided_at   TEXT NOT NULL,
  from_status  TEXT,
  to_status    TEXT NOT NULL,
  comment      TEXT,
  replay_id    TEXT REFERENCES replay_reports(replay_id)
);

CREATE TABLE replay_reports (
  replay_id                       TEXT PRIMARY KEY,        -- 'RPL-POL-0001'
  policy_id                       TEXT NOT NULL REFERENCES policies(policy_id),
  run_at                          TEXT NOT NULL,
  periods_json                    TEXT NOT NULL,           -- ["2026-11","2026-12"]
  obligations_replayed            INTEGER NOT NULL,
  improved                        INTEGER NOT NULL,
  regressed                       INTEGER NOT NULL,
  unchanged                       INTEGER NOT NULL,
  extra_outreach                  INTEGER NOT NULL,
  extra_reviews                   INTEGER NOT NULL,
  abs_error_before                REAL NOT NULL,
  abs_error_after                 REAL NOT NULL,
  touched_json                    TEXT NOT NULL,           -- [{obligation_key, before, after, result}]
  feature_matched_json            TEXT NOT NULL,
  compared_on_action_only_json    TEXT NOT NULL,
  forward_scope_preview_json      TEXT NOT NULL,
  recommendation                  TEXT NOT NULL CHECK (recommendation IN ('APPROVE_PROVISIONAL','REJECT'))
);
```

`trueup_state.db`, wiped by both Reset World and Reset Demo:

```sql
CREATE TABLE demo_state (
  id                       INTEGER PRIMARY KEY CHECK (id = 1),  -- singleton row
  state                    TEXT NOT NULL,        -- one of the 00-decisions section 3 UPPER_SNAKE states
  scenario_id              TEXT,                 -- 'SCN-A' | 'SCN-B' | 'SCN-C' | NULL
  clock                    TEXT NOT NULL,         -- mirror of sim clock, refreshed on every /api call
  world_hash               TEXT NOT NULL,
  fixture_hash             TEXT NOT NULL,
  playbook_version_loaded  TEXT NOT NULL,         -- app-enforced pointer into trueup_playbook.db.playbook_versions
                                                   -- (no cross-file FK: separate SQLite files)
  run_mode                 TEXT NOT NULL CHECK (run_mode IN ('LIVE','RECORDED')),
  active_override_id       TEXT,
  updated_at               TEXT NOT NULL
);
```

`demo_state` is a single-row table (id=1), upserted, never appended; every state transition in the section-3 machine is one `UPDATE`. `playbook_version_loaded` is written by the close-run loader in section 2 below, not by the UI.

## 2. Typed policy record, in full

`POL-0001`, literal, per `WORLD_SPEC.md` 4.6, unchanged here:

```json
{"policy_id":"POL-0001","policy_type":"VERIFY_EFFECTIVE_CONTRACT_PRICE","trigger":"RECURRING_VENDOR_ACCRUAL",
 "scope":{"estimator_method":"FIXED_CONTRACT_FEE","contract_features":{"has_scheduled_price_change":true,"pricing_structure_in":["SCHEDULED_STEP","ANNIVERSARY_ESCALATOR","VENDOR_NOTIFIED_UPLIFT"]}},
 "required_evidence":[{"evidence_key":"pricing_schedule_effective","must_cover":"service_period","accepted_sources":["PRICING_SCHEDULE","CONTRACT_ESCALATOR_CLAUSE","VENDOR_NOTICE"]}],
 "before_action":"CREATE_DRAFT_ACCRUAL",
 "verifier_result_if_missing":{"in_repository_not_attached":"BLOCK","not_in_repository":"OUTREACH_REQUIRED","no_reply_at_cutoff":"ESCALATE"},
 "outreach_if_missing":{"target_role":"VENDOR_BILLING","missing_fact":"SCOPE_OR_RATE_CHANGE","fallback_target_role":"OPERATIONAL_OWNER"},
 "behavior_change":"retrieve_and_validate_current_rate_before_estimation",
 "autonomy_limit":"controller_review_if_material",
 "derived_from":{"outcome_id":"TU-V001-2026-12","root_cause_id":"VE-V001-2026-12"},
 "status":"CANDIDATE","created_at":"2027-01-13T09:30:00","policy_version_target":"1.1"}
```

The `scope` object may reference only `estimator_method` and the `contract_features.*` keys in the section 1.7 whitelist. No `vendor_id`, vendor name, `contract_id` or `category` appears anywhere in the record; this is a hard field-level check, not a review convention (see G1 below).

## 3. Loading and enforcing the active playbook

Every `POST /api/close/run` starts with a loader, run before any LLM call:

1. `SELECT version FROM playbook_versions WHERE status IN ('ACTIVE','PROVISIONAL') ORDER BY activated_at DESC LIMIT 1` (falls back to `'1.0'` FROZEN if no row). Ties broken by highest semantic version.
2. `SELECT policies_json FROM playbook_versions WHERE version = ?` gives the policy id list; `SELECT * FROM policies WHERE policy_id IN (...) AND status IN ('ACTIVE','ACTIVE_PROVISIONAL')` loads the typed records.
3. The loader writes `demo_state.playbook_version_loaded` and returns a `PolicySet` object: the base `policies.json` rules (section 1.5/2.2 of WORLD_SPEC) plus zero or more typed policy records.
4. The `PolicySet` is handed only to the deterministic verifier (the code that produces `PolicyEvaluation`, invariants `ALLOWED_METHOD`, `EVIDENCE_TRACE_COMPLETE`, `NO_SILENT_POLICY_WEAKENING`). It is never serialized into an LLM system or user message.
5. The LLM (evidence/estimation agent) sees only `ContractFeatures`, the obligation's evidence records and the tool catalogue. It proposes an `ActionProposal` with `calculation_method`, `amount`, `evidence_ids`. It does not see policy predicates and cannot special-case a vendor because no policy text ever enters its context.
6. The verifier evaluates the proposal against the loaded `PolicySet` in code. Each `checks[]` row's `source` field is `"BASE"` or a `policy_id` (e.g. `"POL-0001"`), so the workpaper can show exactly which rule fired, as in `WORLD_SPEC.md` 2.5's `PE-V018-2027-01-01` example (`source: "POL-0001"`).

This is why C04/C12 "transfer" without vendor memorization: the verifier, not the model, applies `has_scheduled_price_change = true` to any `ContractFeatures` row, and the loader step above runs identically for V001 and V018.

## 4. Candidate gate

`POST /api/policy/candidate` runs guard **G1** synchronously before returning:

- Walk `scope.contract_features` keys and `scope.estimator_method`; every key must be in the section 1.7 whitelist (`contract_type`, `pricing_structure`, `billing_cadence`, `has_scheduled_price_change`, `has_pricing_exhibit`, `has_usage_component`, `termination_notice_on_file`, `auto_renews`, `notice_days`, plus `estimator_method` itself).
- Reject any predicate value that is a post-cutoff fact (`invoice_id`, `true_up_amount`, `actual_invoice_total`, `root_cause`) or a banned identifier (`vendor_id`, vendor name, `contract_id`, `category`, `cost_center`, `po_id`).
- All pre-close feature fields fail closed: an unrecognized key is a G1 failure, not a pass-through.

G1 fail: `policies.status = 'BLOCKED'`, `demo_state.state = 'CANDIDATE_BLOCKED'`, `policy_events` row `GUARD_G1_BLOCKED` with `comment` naming the offending field. `btn-run-replay` and `btn-approve-policy` are not reachable; only Reject or Reset are.
G1 pass: `policies.status` stays `'CANDIDATE'`, `demo_state.state = 'CANDIDATE_READY'`, `policy_events` row `CANDIDATE_CREATED`.

`POST /api/policy/replay` runs guard **G2** after computing the `replay_reports` row (procedure in `WORLD_SPEC.md` 4.6.4: rebuild each prior obligation's visible snapshot from `2026-11-cutoff`/`2026-12-cutoff`, run the pipeline under 1.0 and under 1.0+candidate, compare to confirmed outcomes):

- Fail if `regressed > 0` or `abs_error_after >= abs_error_before`.
- Fail if any `touched` row's `approval_level_after` is a lower approval level than `approval_level_before` (no silent weakening).
- Pass sets `recommendation = 'APPROVE_PROVISIONAL'`; fail sets `recommendation = 'REJECT'`.

G2 fail: `demo_state.state = 'CANDIDATE_BLOCKED'`, `policy_events` row `GUARD_G2_BLOCKED`. G2 pass: `demo_state.state = 'REPLAY_REPORT_READY'`, `policy_events` row `REPLAY_RUN`.

**Replay report contents**, shown in `#learning-panel`: `obligations_replayed` (35, all 2026-11 and 2026-12), `feature_matched` (obligations whose `ContractFeatures` satisfy `scope`), `not_triggered` (with reason, e.g. invoice already on hand pre-cutoff so no estimate ran), `touched` (one row per obligation whose action changed, each with `before`/`after` amount, price evidence and `abs_error`), `improved`/`regressed`/`unchanged` counts, `compared_on_action_only` (obligations with no confirmed actual yet), `extra_outreach`/`extra_reviews` (0 required), `abs_error_before`/`abs_error_after`, `forward_scope_preview` (open next-period obligations whose features match `scope`, ids only, no amounts). Signed bias before/after is not a stored column; the UI computes `sum(after.amount - before.amount)` over `touched` on read, which for POL-0001 is `+2,500.00 -> 0.00` (bias eliminated, not just averaged out), and prints it next to `abs_error_before`/`abs_error_after`.

## 5. Approve / Reject

`POST /api/policy/approve`. Precondition: `demo_state.state = 'REPLAY_REPORT_READY'`, actor `E001`, `policies.status = 'CANDIDATE'`, the linked `replay_reports.recommendation = 'APPROVE_PROVISIONAL'`.
1. `UPDATE policies SET status = 'ACTIVE_PROVISIONAL' WHERE policy_id = ?`.
2. `INSERT INTO playbook_versions(version, parent_version, status, created_at, activated_at, policies_json, fixture_hash) VALUES ('1.1','1.0','PROVISIONAL', now, now, '["POL-0001"]', :fixture_hash)`. The policy list is the parent's list plus the newly approved id; nothing else changes (`WORLD_SPEC.md` 1.5: "Version 1.1 = version 1.0 plus POL-0001").
3. `INSERT INTO policy_events(...) VALUES (..., 'POLICY_APPROVED', 'E001', now, 'CANDIDATE', 'ACTIVE_PROVISIONAL', comment, replay_id)`.
4. `demo_state.state = 'POLICY_APPROVED'`; `demo_state.playbook_version_loaded` is refreshed to `'1.1'` on the next close-run loader call, not retroactively rewritten on old runs.

`POST /api/policy/reject`. Precondition: `demo_state.state IN ('REPLAY_REPORT_READY','CANDIDATE_BLOCKED')`. Body carries `{"reason": "..."}` (free text, required, min 10 chars).
1. `UPDATE policies SET status = 'REJECTED' WHERE policy_id = ?`.
2. `INSERT INTO policy_events(...) VALUES (..., 'POLICY_REJECTED', :actor, now, :prior_status, 'REJECTED', :reason, :replay_id_or_null)`.
3. No row is written to `playbook_versions`. The active playbook stays `'1.0'` `FROZEN`.
4. `demo_state.state = 'POLICY_REJECTED'`.

**Rejected path proof.** Because step 3 above never creates version `1.1`, the loader in section 3 keeps returning `'1.0'` for every later run, on both the "Frozen" and "Learned" labels. `POST /api/transfer/run` after a reject pins both arms to `'1.0'`; `GET /api/transfer/compare` returns identical `amount`, `approval_level` and `estimator_method` for both columns and the panel prints `Learned == Frozen (policy rejected 2027-01-15, reason: "<reason>")` instead of a predicate-match line. This is the same code path as an approved-then-unused policy, not a special case: the diff is genuinely empty because both arms loaded the same `playbook_versions` row.

## 6. Frozen vs Learned runner

`POST /api/transfer/run`. Precondition: `demo_state.state IN ('POLICY_APPROVED','POLICY_REJECTED','NO_MISS')` and sim clock `>= 2027-02-01T00:00:00`.
1. Both arms start from the same `sim.fork('2027-01-open', dest)` snapshot (`WORLD_SPEC.md` 3.7 L4): identical `runtime/visible/` bytes, identical `sim_state.json`.
2. Arm `FROZEN` pins `playbook_version = '1.0'` for the whole run regardless of what is active in `trueup_playbook.db`.
3. Arm `LEARNED` pins `playbook_version` to whatever `SELECT version FROM playbook_versions WHERE status IN ('ACTIVE','PROVISIONAL') ORDER BY activated_at DESC LIMIT 1` returns at call time (`'1.1'` if approved, `'1.0'` if rejected).
4. Each arm runs `POST /api/close/run` internally against its own fork and its pinned version (no live re-vote of the loader), then advances its own fork to `2027-02-12T09:00:00`, which releases `INV-V018-001` in that fork only, and runs the deterministic match and tolerance test of `02-state-machine-and-time.md` section 4. The shared demo clock is unaffected; `demo_state.clock` on entry to `TRANSFER_COMPARED` is `2027-02-12T09:00:00`.
5. A `TransferResult` diff record is written per obligation: `{"obligation_id","frozen":{"amount","approval_level","estimator_method","policies_applied"},"learned":{...},"delta":"frozen.amount - learned... == 0 ? 'IDENTICAL' : 'DIFFERENT'","predicate_match":{"has_scheduled_price_change":true,"pricing_structure":"SCHEDULED_STEP","matched_policy_id":"POL-0001"} }`.

`GET /api/transfer/compare` returns the array of `TransferResult` rows plus the literal POL-0001 record (from section 2) so the panel can show "no vendor identifier anywhere in this record" next to the diff, matching `WORLD_SPEC.md` SCN-B.

## 7. API

Error code legend, used by every endpoint below: `400 VALIDATION_ERROR` malformed body or unknown enum; `404 NOT_FOUND` unknown id; `409 STATE_CONFLICT` `demo_state.state` does not allow this call per the section-3 transition table; `422 GUARD_FAILED` G1 or G2 rejected; `423 WORLD_LOCKED` a second override staged without `allow_multi=true`; `502 SIM_UNREACHABLE` the `trueup` to `sim` proxy call failed; `500 LIVE_MODEL_ERROR` the agent call failed, `demo_state.state -> 'ESCALATED'`, no recorded fallback is substituted (`00-decisions.md` section 5, "Live-LLM risk").

### Simulator, base `/sim`

| Endpoint | Precondition | Request | Response (key fields) | Errors |
|---|---|---|---|---|
| `GET /sim/health` | none | - | `{"status":"ok","build":"..."}` | - |
| `GET /sim/controls` | none | - | control catalogue rows, section 2 of `00-decisions.md` | - |
| `POST /sim/overrides/stage` | no staged override, or `allow_multi=true` | `{"control_id":"CTL-ESCALATOR-PCT","vendor_id":"V001","param":{"escalator_pct":5.0}}` | `{"override_id":"OVR-0001","visible_doc_diff":{...},"validator":"VAL-ESCALATOR-PCT","valid":true}` | 400, 423 |
| `POST /sim/overrides/apply` | one staged override exists | `{"override_id":"OVR-0001"}` | `{"world_hash":"9f2c41ab77d0","runtime_reset":true,"clock":"2027-01-04T09:00:00"}` | 404, 400 |
| `GET /sim/overrides` | none | - | `[ScenarioOverride, ...]` | - |
| `DELETE /sim/overrides` | none | - | `{"cleared":1}` | - |
| `GET /sim/clock` | none | - | `{"clock":"...","periods":[{"period":"2026-12","status":"OPEN"}]}` | - |
| `POST /sim/advance` | target `> clock` | `{"to":"2027-01-12T09:00:00"}` | `{"clock":"2027-01-12T09:00:00","released":["INV-V001-008"]}` | 400 (`ClockRegressionError`) |
| `POST /sim/outreach` | obligation exists | `{"obligation_id":"OBL-V001-2026-12","target_role":"VENDOR_BILLING","missing_fact":"INVOICE_WHEREABOUTS"}` | `{"outreach_id":"OUT-V001-2026-12-01","accepted":true}` | 404 |
| `POST /sim/snapshot` | none | `{"label":"2026-12-cutoff"}` | `{"label":"2026-12-cutoff","stored":true}` | - |
| `POST /sim/fork` | snapshot exists | `{"label":"2027-01-open","dest":"learned-run-1"}` | `{"dest":"learned-run-1","world_hash":"..."}` | 404 |
| `GET /sim/hash` | none | - | `{"world_hash":"...","fixture_hash":"...","baseline_fixture_hash":"..."}` | - |
| `POST /sim/reset/world` | none | - | `{"clock":"2027-01-04T09:00:00","world_hash":"..."}` | - |
| `POST /sim/reset/demo` | none | - | `{"clock":"2027-01-04T09:00:00","fixture_hash_matches_baseline":true}` | 500 if hash mismatch after rebuild |

### TrueUp, base `/api`

| Endpoint | Precondition | Request | Response (key fields) | Errors |
|---|---|---|---|---|
| `GET /api/state` | none | - | `{"state":"...","clock":"...","playbook_version":"1.0","world_hash":"...","mode":"LIVE"}` | - |
| `GET /api/obligations` | none | `?period=2026-12` | `[VendorObligation summary, ...]` | 400 |
| `GET /api/obligations/{obligation_id}` | obligation exists | - | full VendorObligation + evidence + verifier checklist | 404 |
| `POST /api/close/run` | `state IN ('IDLE_BASELINE','MUTATION_APPLIED')`, period OPEN | `{"period":"2026-12"}` | `{"run_id":"RUN-0001","state":"CLOSE_RUNNING"}` (async; poll `/api/state`) | 409, 500 |
| `POST /api/accrual/approve` | `state = 'CLOSE_AWAITING_APPROVAL'`, actor matches `required_approval_level` | `{"obligation_id":"OBL-V001-2026-12","actor":"E001"}` | `{"accrual_entry_id":"JE-ACR-V001-2026-12","state":"CLOSE_POSTED"}` | 409, 403 (wrong actor) |
| `POST /api/trueup/run` | `state = 'CLOSE_POSTED'`, invoice now visible | `{"obligation_id":"OBL-V001-2026-12"}` | `{"true_up_amount":2500.00,"within_tolerance":false,"state":"TRUEUP_COMPUTED"}` | 409, 404 |
| `POST /api/investigate` | `state = 'TRUEUP_COMPUTED'`, outside tolerance | `{"obligation_id":"OBL-V001-2026-12"}` | `VarianceExplanation` (`root_cause`, `process_cause`, `evidence_existed_at_close`) | 409 |
| `POST /api/policy/candidate` | `state = 'ROOT_CAUSE_FOUND'` | `{"root_cause_id":"VE-V001-2026-12"}` | `POL-0001` record, `state` `'CANDIDATE_READY'` or `'CANDIDATE_BLOCKED'` | 409, 422 (G1) |
| `POST /api/policy/replay` | `state = 'CANDIDATE_READY'` | `{"policy_id":"POL-0001"}` | `replay_reports` row, `state` `'REPLAY_REPORT_READY'` or `'CANDIDATE_BLOCKED'` | 409, 422 (G2) |
| `POST /api/policy/approve` | section 5 | `{"policy_id":"POL-0001","actor":"E001"}` | `{"policy_version":"1.1","status":"ACTIVE_PROVISIONAL","state":"POLICY_APPROVED"}` | 409, 403 |
| `POST /api/policy/reject` | section 5 | `{"policy_id":"POL-0001","actor":"E001","reason":"..."}` | `{"status":"REJECTED","playbook_version_unchanged":"1.0","state":"POLICY_REJECTED"}` | 409, 400 (missing reason) |
| `GET /api/playbook` | none | - | `{"versions":[...],"policies":[...],"events":[...]}` | - |
| `POST /api/transfer/run` | section 6 | `{}` | `{"run_id":"RUN-0003","state":"TRANSFER_RUNNING"}` (learned arm; the frozen arm is `RUN-0004`) | 409 |
| `GET /api/transfer/compare` | `state = 'TRANSFER_COMPARED'` | - | `[TransferResult, ...]` + `POL-0001` | 409 |
| `GET /api/audit/{obligation_id}` | obligation exists | - | audit packet: proposal, evaluation, approval, JEs, true-up, policy trace | 404 |
| `GET /api/evidence-trail` | run exists | `?run_id=RUN-0001` | SSE stream, section 8 | 404 |
| `POST /api/reset/world` | none | - | proxies `/sim/reset/world`, then wipes `trueup_state.db`, keeps `trueup_playbook.db` | 502 |
| `POST /api/reset/demo` | none | - | proxies `/sim/reset/demo`, wipes `trueup_state.db`, re-seeds `trueup_playbook.db` at `'1.0'` | 502, 500 |
| `ANY /api/lab/{path}` | none | byte passthrough | byte passthrough to `sim` | 502 |

## 8. Evidence-trail SSE stream

`GET /api/evidence-trail?run_id=RUN-0001`, `text/event-stream`, one event per tool call plus lifecycle markers, ids `TC-<run suffix>-<seq>`:

```
event: tool_call_start
data: {"tool_call_id":"TC-0001-007","run_id":"RUN-0001","obligation_id":"OBL-V001-2026-12","tool":"open_document","args":{"doc_id":"CTR-001"},"at":"2027-01-04T09:00:12"}

event: tool_call_result
data: {"tool_call_id":"TC-0001-007","result_summary":"CTR-001 Order Form: $50,000.00 per month (Contract Year 1)","evidence_id":"CTR-001"}

event: proposal_created
data: {"proposal_id":"PRP-V001-2026-12-01","amount":50000.00,"calculation_method":"FIXED_CONTRACT_FEE"}

event: verifier_result
data: {"evaluation_id":"PE-V001-2026-12-01","result":"REVIEW_REQUIRED","required_approval_level":"CONTROLLER"}

event: done
data: {"run_id":"RUN-0001","state":"CLOSE_AWAITING_APPROVAL"}
```

Every `tool_call_start`/`tool_call_result` pair is also written to `trueup_state.db.tool_calls` (`AgentRun` FK) so the trail survives a page reload; the stream replays from that table on reconnect instead of losing history.

## 9. Backend delta and build checklist

Delta against the existing generator (`data/gen/`) and `WORLD_SPEC.md`: the generator changes only so that `world.py` pricing functions, `records.py` invoice and PO builders and `events.py` `release_at` values accept `ScenarioOverride` parameters (`01-scenario-lab-and-mutations.md` section 2), plus the one declared departure of `00-decisions.md` section 1 (`PO-1063.authorized_amount = 415000.00` in `records.py`). `truth.py` and `features.py` keep their logic and are re-run, never hand-edited; no truth file is ever written directly. Everything else below is new code in `trueup/` and `sim/`.

| # | Item | Depends on | Hours |
|---|---|---|---|
| 1 | `sim` FastAPI skeleton: `/sim/health`, `/sim/clock`, `/sim/hash`, `reset()`/`advance_to()` wrapping the existing simulator contract (3.6) | generator as-is | 2 |
| 2 | ScenarioOverride: validators (section 2 of `00-decisions.md`), stage/apply endpoints, `world.py` re-run on apply | 1 | 4 |
| 3 | `sim` outreach, snapshot, fork endpoints (3.5, 3.6) | 1 | 2 |
| 4 | `trueup_state.db` schema (obligations through demo_state) and import of seed `gl_entries.csv` | none | 2 |
| 5 | `trueup_playbook.db` schema (section 1) and seed row `version='1.0', status='FROZEN'` | none | 1 |
| 6 | `/api/lab/*` byte-passthrough proxy to `sim` | 1 | 1 |
| 7 | Close pipeline: playbook loader (section 3) + deterministic estimator + verifier producing `PolicyEvaluation` | 4, 5 | 5 |
| 8 | `POST /api/close/run`, `/api/accrual/approve`, `/api/obligations*`, SSE evidence-trail (section 8) | 7 | 4 |
| 9 | `POST /api/trueup/run`, `/api/investigate` (deterministic match + classifier call) | 8 | 3 |
| 10 | Guard G1, `POST /api/policy/candidate` | 5, 9 | 2 |
| 11 | Replay engine (section 4 procedure) + guard G2, `POST /api/policy/replay` | 7, 10 | 4 |
| 12 | `POST /api/policy/approve`, `/api/policy/reject`, `GET /api/playbook` (section 5) | 11 | 2 |
| 13 | Frozen/Learned runner, `POST /api/transfer/run`, `GET /api/transfer/compare` (section 6) | 3, 12 | 3 |
| 14 | `GET /api/audit/{obligation_id}` audit packet | 8, 9 | 1 |
| 15 | `POST /api/reset/world`, `/api/reset/demo` proxy plus DB wipe/reseed | 2, 5 | 1 |
| 16 | Web page: `#clock-bar`, `#lab-panel`, `#diff-panel`, close/workpaper/outreach/true-up panels, `#evidence-trail`, `#learning-panel`, `#transfer-panel`, `#audit-panel` | 6-15 | 8 |
| 17 | Recorded-run capture at `BASELINE_FIXTURE_HASH`, `RECORDED` badge, live-model fallback to `ESCALATED` (`00-decisions.md` section 5, Live-LLM risk) | 8 | 2 |
| 18 | Leakage tests (3.7 L1-L4) run against the live API instead of the offline harness | 1-15 | 3 |

Total 50 hours; with 4 people in parallel (sim track, close-pipeline track, learning track, UI track) this fits a 24-hour build with roughly 12 hours of slack for integration and the cut-order fallback in `00-decisions.md` section 2 (drop `CTL-CADENCE` first) if items 2-3 run long.


---

# 04 Scenarios and demo flow

Deliverables 7 and 8. Binding on this file: `00-decisions.md` (ids, states, buttons, endpoints, tables) and `WORLD_SPEC.md` (amounts, evidence text, ids). All amounts below are recomputed here, not copied blind; each matches `00-decisions.md` section 4 where that section already gives the row.

Shared notation. `CONTROLLER` = E001 Dana Whitfield. `REVIEWER` = E002 Marcus Oyelaran. Tolerance = `max($500.00, 0.02 x accrued amount)`. Accrual is `Dr <expense> / Cr 2100`, dated the last day of the service month, reversed day 1 of next month. Invoice posts `Dr <expense> / Cr 2000`; true-up posts `Dr <expense> / Cr 2000` for the variance only. Guard G1 blocks a candidate whose predicates leave the section 1.7 whitelist or cite a post-cutoff fact. Guard G2 blocks a candidate with `regressed > 0` or no drop in absolute error.

## 1. SCN-A: learnable failure (DataForge, V001)

**Judge action.** Scenario Lab, vendor V001, control `CTL-ESCALATOR-PCT`, parameter `escalator_pct`. Options 0 / 5 / 8 / 12. 5 is the untouched baseline (`PS-001` CY2 is already $52,500.00), so it produces no visible diff; this walkthrough uses **8**, a genuine judge edit. Judge clicks `btn-apply-mutation`.

**Document diff.** `contracts/pricing_schedules/PS-001.txt`, CY2 row:
```
CY2 | 2026-12-01 | 2027-11-30 | $52,500.00  ->  $54,000.00
```
Hidden records re-derived: `INV-V001-008` amount $52,500.00 -> $54,000.00; `INV-V001-009` (2027-01, not used by this scenario) also re-derived. `world_hash` changes; regeneration budget under 2s.

**What TrueUp sees at close** (`btn-run-close`, period 2026-12, clock 2027-01-04T09:00 to 2027-01-05T15:30). Under policy 1.0 `FIXED_CONTRACT_FEE` requires only `contract, service_period`; `PS-001` is never opened.
Evidence used: `CTR-001` order form ("$50,000.00 per month (Contract Year 1)"), `PO-1029`, `SA-DATAFORGE-2026-12` (service confirmed), `INV-V001-001..007` (seven priors at $50,000.00), `erp/accrual_schedule_prior.csv` (no V001 rows).

**ActionProposal and verifier result:**
```json
{"proposal_id":"PRP-V001-2026-12-01","obligation_id":"OBL-V001-2026-12","action_type":"POST_ACCRUAL","amount":50000.00,
 "accounts":{"debit":"6100","credit":"2100"},"entry_date":"2026-12-31","reversal_date":"2027-01-01",
 "calculation_method":"FIXED_CONTRACT_FEE","evidence_ids":["CTR-001","PO-1029","SA-DATAFORGE-2026-12"],"confidence":0.91,"policy_version":"1.0"}
{"evaluation_id":"PE-V001-2026-12-01","result":"REVIEW_REQUIRED","required_approval_level":"CONTROLLER",
 "checks":[{"invariant":"EVIDENCE_TRACE_COMPLETE","passed":true,"source":"BASE"},{"invariant":"MATERIALITY_APPROVAL","passed":false,"source":"BASE","detail":"50000.00 >= 25000.00"}]}
```

**JE.** `JE-ACR-V001-2026-12` Dr 6100 / Cr 2100 $50,000.00, CC-100, dated 2026-12-31; `JE-REV-V001-2026-12` reversal 2027-01-01. Judge/presenter clicks `btn-approve-accrual` (E001) -> `CLOSE_POSTED`.

**Advance Time.** `btn-advance-time` to 2027-01-12T09:00 releases event `INVOICE_RECEIVED` -> `INV-V001-008`, number DF-2256, dated 2026-12-31, **$54,000.00**.

**Deterministic variance.** $54,000.00 - $50,000.00 = **$4,000.00**. Tolerance = `max($500.00, 0.02 x 50000.00) = $1,000.00`. $4,000.00 > $1,000.00, outside tolerance -> `TRUEUP_COMPUTED`, `btn-investigate` enabled. `JE-INV-V001-008` Dr 6100/Cr 2000 $50,000.00; `JE-TRU-V001-2026-12` Dr 6100/Cr 2000 $4,000.00 dated 2027-01-12.

**Investigation trail** (`btn-investigate`, clock 2027-01-13T09:00, run `RUN-0002`):

| ToolCall | Actor | Call | Quoted source | Locator |
|---|---|---|---|---|
| TC-0002-001 | Reconciliation Agent | `open_document(INV-V001-008)` | "DataForge Platform subscription - December 2026 (Contract Year 2)", $54,000.00 | `line_items[0]` |
| TC-0002-002 | Evidence Agent | `list_contract_documents(CTR-001)` | returns `["CTR-001","PS-001"]` | `contracts/index.json` |
| TC-0002-003 | Evidence Agent | `open_document(PS-001)` | "CY2 \| 2026-12-01 \| 2027-11-30 \| $54,000.00" | table row 2 |
| TC-0002-004 | Evidence Agent | `open_document(CTR-001)` | "$50,000.00 per month (Contract Year 1)" | Order Form |
| TC-0002-005 | Reconciliation Agent | `compute_variance(OBL-V001-2026-12)` | actual 54000.00 - accrued 50000.00 = 4000.00, tolerance 1000.00 | n/a (deterministic) |
| TC-0002-006 | classifier (LLM) | `classify_root_cause([INV-V001-008,PS-001,CTR-001])` | "PS-001 filed_date 2025-11-24, in repository before T0" | PS-001 header |

**Root cause.** `SCHEDULED_PRICE_CHANGE`, `process_cause = PROCEDURE_GAP_REQUIRED_EVIDENCE`. `evidence_existed_at_close = true` -> `CANDIDATE_READY`.

**Candidate policy.** `POL-0001`, `policy_type VERIFY_EFFECTIVE_CONTRACT_PRICE`, scope `{estimator_method: FIXED_CONTRACT_FEE, contract_features.has_scheduled_price_change: true, pricing_structure_in: [SCHEDULED_STEP, ANNIVERSARY_ESCALATOR, VENDOR_NOTIFIED_UPLIFT]}`. No `vendor_id`, vendor name, or `contract_id` anywhere in the record. Guard G1 passes (every field is on the section 1.7 whitelist).

**Replay numbers** (`btn-run-replay`, `RPL-POL-0001`, 35 obligations across 2026-11 and 2026-12): touched = `OBL-V001-2026-12` only, before $50,000.00 / abs_error $4,000.00, after $54,000.00 / abs_error $0.00. `improved = 1, regressed = 0, unchanged = 34`. Guard G2 passes.

**Approve vs Reject.**
- `btn-approve-policy` (judge's second real choice, actor E001): `POLICY_APPROVED`, playbook badge 1.0 -> 1.1 `PROVISIONAL`, `POL-0001.status = ACTIVE_PROVISIONAL`, persisted in `trueup_playbook.db` (survives Reset World). SCN-B's learned arm uses this.
- `btn-reject-policy`: `POLICY_REJECTED`, playbook stays 1.0, `policy_events` row `REJECTED` by E001. SCN-B's learned arm then behaves identically to the frozen arm (no predicate exists to match).

## 2. SCN-B: transfer to an unseen vendor (SignalStack, V018)

Requires SCN-A approved first. Frozen and learned arms fork snapshot `2027-01-open` at 2027-02-01T00:00, so both see one byte-identical visible state.

**Judge action.** Lab, vendor V018 (first time in AP; onboarded 2027-01-08, never handled before), control `CTL-ESCALATOR-PCT`, parameter `production_monthly_fee`. Options 12000 / 24000 / 30000 / 33000; 30000 is baseline. This walkthrough uses **33000**, the judge's own number, so the room cannot mistake the result for a memorized $30,000 slide fact.

**Document diff.** `contracts/pricing_schedules/PS-018.txt`, Production row:
```
Production | 2027-01-01 | 2027-12-31 | $30,000.00  ->  $33,000.00
```
Hidden `INV-V018-001` amount $30,000.00 -> $33,000.00. Pilot months and the two `CARD_EXPENSE` GL rows are untouched.

**What each arm sees at close** (period 2027-01, clock at or after 2027-02-01):
- Frozen (v1.0): reads only `CTR-018` order form ("Pilot Fee $12,000.00 per month") plus `JE-CARD-0001` and `JE-CARD-0002` as corroboration. Never opens `PS-018` (not in the v1.0 required-evidence list).
- Learned (v1.1): same start, then POL-0001 fires because `has_scheduled_price_change = true` for CTR-018.

**Evidence-retrieval trail, learned arm** (run `RUN-0003`):

| ToolCall | Actor | Call | Quoted source | Locator |
|---|---|---|---|---|
| TC-0003-001 | Evidence Agent | `open_document(CTR-018)` | "Pilot Fee $12,000.00 per month" | Order Form |
| TC-0003-002 | Estimation Agent | draft `FIXED_CONTRACT_FEE` $12,000.00 | evidence `[CTR-018, JE-CARD-0001, JE-CARD-0002]` | n/a |
| TC-0003-003 | Verifier Engine | `evaluate(POL-0001)` | result `BLOCK`, "PS-018 exists in contracts/index.json but not attached" | missing_evidence: pricing_schedule_effective |
| TC-0003-004 | Evidence Agent | `list_contract_documents(CTR-018)` | returns `["CTR-018","PS-018"]` | contracts/index.json |
| TC-0003-005 | Evidence Agent | `open_document(PS-018)` | "Production \| 2027-01-01 \| 2027-12-31 \| $33,000.00" | table row 2 |
| TC-0003-006 | Estimation Agent | re-propose `FIXED_CONTRACT_FEE` $33,000.00 | evidence `+= [PS-018]` | n/a |
| TC-0003-007 | Verifier Engine | `evaluate(POL-0001)` | result `REVIEW_REQUIRED`, `required_approval_level CONTROLLER` | source POL-0001 |

Frozen arm makes 1 tool call (`open_document(CTR-018)`) and stops there, by design of v1.0's required-evidence list.

**Frozen Agent vs Learned TrueUp:**

| | Frozen (v1.0) | Learned (v1.1) |
|---|---|---|
| Accrual amount | $12,000.00 | $33,000.00 |
| Price evidence | CTR-018 order form + 2 card charges | PS-018 Production row |
| Verifier result / approval | REVIEW_REQUIRED / REVIEWER (E002) | BLOCK -> REVIEW_REQUIRED / CONTROLLER (E001) |
| JE | Dr 6120 / Cr 2100 $12,000.00, CC-190, 2027-01-31 | Dr 6120 / Cr 2100 $33,000.00, CC-190, 2027-01-31 |
| Hidden `INV-V018-001` | $33,000.00 | $33,000.00 |
| True-up ($33,000.00 - accrual) | $21,000.00 (tolerance max($500,0.02x12000=$240)=$500.00; outside) | $0.00 |

**Predicate-match panel** (`#transfer-panel`): `estimator_method = FIXED_CONTRACT_FEE` matched; `has_scheduled_price_change = true` matched; `pricing_structure = SCHEDULED_STEP` in `pricing_structure_in`; line: "POL-0001 contains no vendor_id, vendor name, or contract_id" next to the serialized policy record.

**Root cause, candidate policy, replay.** No new classification or candidate runs here; this beat consumes `POL-0001` from SCN-A. The frozen arm's miss carries the same `SCHEDULED_PRICE_CHANGE` shape already learned. `forward_scope_preview` from the SCN-A replay report already listed `OBL-V018-2027-01` before this run happened, holding no amount.

**Approve vs Reject (inherited).** If SCN-A was approved, the table above holds. If SCN-A was rejected, the learned arm's verifier never fires POL-0001; both arms read $12,000.00 and both miss by $21,000.00 against a $33,000.00 invoice — the presenter can show this on request to prove the policy, not luck, produced the fix.

Bonus proof of "not memorized" (time permitting): control `CTL-ESCALATOR-DATE`, `production_effective_date = 2027-02-01`. January is then still the **pilot** month. Frozen: $12,000.00 accrued, invoice $12,000.00, variance $0.00. Learned: reads the PS-018 row covering 2027-01-01..2027-01-31 (still Pilot at that date) and books $12,000.00, variance $0.00 too — same predicate match, opposite direction, proving the rule reads the schedule rather than always inflating the number.

## 3. SCN-C: refuse to learn (Brightwork, V006)

**Judge action.** Lab, vendor V006, control `CTL-SURCHARGE`, parameter `surcharge_amount`. Options 0.00 / 900.00 / 2,400.00 / 6,000.00. This walkthrough uses **2,400.00**.

**Document diff.** None, by design of this control. The Lab shows: "This control changes only the hidden invoice; nothing in the visible repository changes before cutoff." `INV-V006-003` total (hidden) becomes $28,670.00; `release_at` is unchanged (2027-01-15).

**What TrueUp sees at close** (`OBL-V006-2026-12`): `evidence/timesheets.csv` shows 68 hours `APPROVED`, 74 hours `PENDING` (weeks ending 2026-12-18 and 2026-12-25, 38 + 36). Verifier returns `OUTREACH_REQUIRED`, fact `SERVICE_RECEIVED`, target E014 (owner). Reply after 20h confirms all 142 hours. `USAGE_X_RATE`: 142 x $185.00 = **$26,270.00**.

**ActionProposal and verifier result:**
```json
{"proposal_id":"PRP-V006-2026-12-01","action_type":"POST_ACCRUAL","amount":26270.00,"accounts":{"debit":"6200","credit":"2100"},
 "entry_date":"2026-12-31","reversal_date":"2027-01-01","calculation_method":"USAGE_X_RATE",
 "evidence_ids":["CTR-006","PO-1042","TS-V006-2026-12-18","TS-V006-2026-12-25"],"policy_version":"1.0"}
{"evaluation_id":"PE-V006-2026-12-01","result":"REVIEW_REQUIRED","required_approval_level":"CONTROLLER"}
```

**JE.** `JE-ACR-V006-2026-12` Dr 6200 / Cr 2100 $26,270.00, CC-140, 2026-12-31; reversal 2027-01-01. Approved by E001.

**Advance Time.** Release to 2027-01-15T09:00 materializes `INV-V006-003`, BW-2221, total **$28,670.00** (two line items: $26,270.00 services, $2,400.00 "Year end expedite premium").

**Deterministic variance.** $28,670.00 - $26,270.00 = **$2,400.00**. Tolerance = `max($500.00, 0.02 x 26270.00 = $525.40) = $525.40`. $2,400.00 > $525.40, outside tolerance -> `btn-investigate` enabled.

**Investigation trail.** SCN-C is run from a fresh `btn-reset-world`, which wipes `agent_runs` and `tool_calls`, so ids restart: the close is `RUN-0001` and the investigation is `RUN-0002`. The rows below belong to this world, not to SCN-A's.

| ToolCall | Actor | Call | Quoted source | Locator |
|---|---|---|---|---|
| TC-0002-001 | Reconciliation Agent | `open_document(INV-V006-003)` | "Year end expedite premium", $2,400.00 | `line_items[1]` |
| TC-0002-002 | Evidence Agent | `list_contract_documents(CTR-006)` | returns `["CTR-006"]`, no pricing exhibit | contracts/index.json |
| TC-0002-003 | Evidence Agent | `open_document(CTR-006)` | "Consultant shall bill actual hours worked at $185.00 per hour. No additional fees apply absent a signed change order." | Fees clause |
| TC-0002-004 | Evidence Agent | `search_change_orders(contract_id=CTR-006)` | none found for December | change_orders.json |
| TC-0002-005 | Evidence Agent | `search_inbox(obligation_id=OBL-V006-2026-12, missing_fact=SCOPE_OR_RATE_CHANGE)` | no thread exists | inbox/messages.jsonl |
| TC-0002-006 | classifier (LLM) | `classify_root_cause([INV-V006-003,CTR-006])` | "no clause, change order, or correspondence supports $2,400.00" | n/a |

**Root cause.** No contractual basis and no pre-cutoff observable feature -> `root_cause = UNKNOWN`, `process_cause = NO_CONTRACTUAL_BASIS` -> `ROOT_CAUSE_UNKNOWN` -> automatic -> `ESCALATED`.

**Why no policy is proposed.** The state machine only reaches `CANDIDATE_READY` from `ROOT_CAUSE_FOUND`. `UNKNOWN` never visits that state, so the Learning Agent is never invoked; there is nothing to scope a predicate against, since no observable pre-cutoff feature explains the $2,400.00. (Contrast: V007 Meridian's baseline miss is `ESTIMATE_JUDGMENT` with `evidence_existed_at_close = false` — evidence exists nowhere, a Controller judgment call, not a procedure gap either — also escalates, also no candidate, for a different reason worth citing if a judge asks for a second example.)

**EscalationNote:**
```json
{"escalation_id":"ESC-V006-2026-12-01","obligation_id":"OBL-V006-2026-12","raised_at":"2027-01-15T12:00:00","raised_by":"TRUEUP",
 "reason_code":"NO_CONTRACTUAL_BASIS","variance_amount":2400.00,"tolerance_amount":525.40,
 "evidence_ids":["INV-V006-003","CTR-006"],"routed_to":"E001","routed_role":"CONTROLLER",
 "summary":"Invoice carries a $2,400.00 line, 'Year end expedite premium', with no supporting clause, change order, or correspondence.",
 "status":"OPEN","controller_decision":null}
```
No scripted inbox reply exists for this note (it is a judge-created fact, not a seeded case), so it stays `OPEN` for the rest of the demo; only `Reset World` / `Reset Demo` clear it.

**Candidate policy / replay / Approve-Reject.** None of the three apply. `btn-approve-policy` and `btn-reject-policy` are never rendered for this obligation; `ESCALATED`'s only enabled buttons are `Reset World` and `Reset Demo`. This absence is the deliverable: TrueUp declines to generalize from one unexplained dollar.

## 4. The three-minute judge-facing flow

Backbone is SCN-A end to end, closing with the SCN-B transfer proof. SCN-C is not in the timed path (its payoff is silence, not a state change) but is one click away if a judge asks "what if it can't explain it" during the wrap.

**GPF (Golden Path Fallback).** Per the Live-LLM risk rule, a mutated world never gets a cached answer. If any live call in a beat below stalls past 5 seconds or errors, the presenter says the fallback line, clicks `btn-reset-world`, and reruns `Run Close` on the override-free baseline world, the one whose `fixture_hash == BASELINE_FIXTURE_HASH` (escalator_pct 5 = baseline, still misses by $2,500.00). That world always has a recording at `runtime/recorded/REC-<hash12>.jsonl`, keyed by the first 12 hex of its `world_hash`; the rest of the table below plays unchanged, just under the `RECORDED` badge instead of `LIVE`.

| # | Sec | Actor | Click | Screen shows | Spoken line | Fallback |
|---|---|---|---|---|---|---|
| 1 | 0-8 | presenter | none | `#clock-bar`: clock 2027-01-04T09:00, `fixture_hash` matches `BASELINE_FIXTURE_HASH`, playbook 1.0 | "Northstar Analytics, reset to a pinned hash. Nothing here is scripted." | none |
| 2 | 8-15 | presenter | hands over laptop | `#lab-panel` open | "Pick a vendor, change one real fact about their contract." | none |
| 3 | 15-30 | judge | select V001, `CTL-ESCALATOR-PCT`, pick a percent | staged `PS-001` diff, no world change yet | "Your number changes the contract, not the invoice." | preset chips for 5/8/12 if free entry is slow |
| 4 | 30-38 | judge | `btn-apply-mutation` | new `world_hash`, "regenerated in 1.4s" | "That just rebuilt a real PDF and the hidden invoice behind it." | GPF |
| 5 | 38-50 | presenter | `btn-run-close` | `#evidence-trail` streaming tool calls; S2 filling in | "Watch it pull the contract, the PO, seven prior invoices, live." | GPF |
| 6 | 50-62 | presenter | none | S2: `PRP-V001-2026-12-01` $50,000.00, `REVIEW_REQUIRED`, routed to Controller | "Fifty thousand, straight off the Year One line. The rule never asked for the price schedule." | GPF |
| 7 | 62-70 | presenter | `btn-approve-accrual` | `JE-ACR-V001-2026-12` posted | "A human signs off only because fifty thousand clears the threshold." | none |
| 8 | 70-80 | presenter | `btn-advance-time` | S4: `INV-V001-008` PDF, amount in red vs accrual | "One click forward, and the real bill lands. Not fifty thousand." | none |
| 9 | 80-85 | (auto) | none | variance card, over tolerance | "That gap is math, not a guess." | none |
| 10 | 85-100 | presenter | `btn-investigate` | `#evidence-trail`: quoted CY2 row, PS-001 locator | "It opens the pricing schedule that was sitting there the whole time." | GPF |
| 11 | 100-108 | (auto) | none | S5: `POL-0001` scope JSON, no vendor id highlighted | "Its fix names a contract feature. It never says DataForge." | GPF |
| 12 | 108-118 | presenter | `btn-run-replay` | replay table: 35 obligations, improved 1, regressed 0 | "Thirty-five past obligations, replayed live, right now. Nothing else moved." | none |
| 13 | 118-128 | judge | `btn-approve-policy` or `btn-reject-policy` | playbook badge 1.0 -> 1.1 | "Your call: approve it, or reject it and it forgets this happened." | none |
| 14 | 128-140 | presenter | `btn-advance-time` then `btn-run-transfer` | fork banner: one visible state, two arms | "Now a vendor it has never touched, a different pricing shape entirely." | GPF (learned arm only) |
| 15 | 140-165 | (auto) | none | `#transfer-panel` split table + predicate-match panel | "Same rule, new vendor: it blocks the guess and gets the right number." | GPF |
| 16 | 165-178 | presenter | open `#audit-panel` | evidence ids, policy version, approver for `OBL-V018-2027-01` | "Every dollar traces to evidence, a policy version, a name." | none |
| 17 | 178-180 | presenter | none | (wrap) | "Reject instead, and it misses by twenty-one thousand, same as today." | none |

Both required judge choices land on screen: the mutation value at beat 3, Approve/Reject at beat 13.

## 5. Sixty-second pairwise expo variant

SCN-A only, compressed, preset buttons instead of free entry, results revealed rather than narrated step by step. Same GPF rule; pre-armed at a 3-second timeout since there is no slack to wait.

| # | Sec | Actor | Click | Screen shows | Spoken line |
|---|---|---|---|---|---|
| 1 | 0-6 | presenter | none | clock-bar, hash pinned | "Live agent, real contract data, one pinned hash." |
| 2 | 6-16 | judge | preset chip "8% escalator" then `btn-apply-mutation` | diff + new hash | "Pick the miss size." |
| 3 | 16-28 | presenter | `btn-run-close` then `btn-approve-accrual` | S2 accrual $50,000.00, `CONTROLLER` | "It accrues fifty thousand off the order form." |
| 4 | 28-38 | presenter | `btn-advance-time` | invoice $54,000.00, variance card | "Real bill: fifty-four. A four-thousand-dollar miss." |
| 5 | 38-48 | presenter | `btn-investigate` (result pre-warmed) | root cause card, `POL-0001` scope | "It finds the missed pricing schedule and drafts a fix, no vendor name." |
| 6 | 48-58 | judge | `btn-approve-policy` | badge 1.0 -> 1.1 | "You approve it; it becomes company memory." |
| 7 | 58-60 | presenter | none | (wrap) | "Next vendor, same rule, no retraining." |

## 6. Pre-demo checklist

1. `POST /sim/reset/demo`; confirm response `fixture_hash == BASELINE_FIXTURE_HASH`.
2. `GET /sim/hash` and `GET /api/state`: confirm `world_hash` matches, playbook version `1.0`, badge `LIVE`.
3. Warm the LLM path once: run SCN-A live at baseline (escalator_pct 5, no Apply Change needed) end to end through `Run Transfer Compare`, so `runtime/recorded/REC-<hash12>.jsonl` exists for `BASELINE_FIXTURE_HASH`. This file is the GPF safety net and is not cleared by `Reset World` or `Reset Demo`.
4. `POST /sim/reset/demo` again to return to `IDLE_BASELINE` with a clean `trueup_state.db` (the recording from step 3 survives; the run itself does not).
5. Stage a dry-run override for each of the three demo-path controls (`CTL-ESCALATOR-PCT`, `CTL-ESCALATOR-DATE`, `CTL-SURCHARGE`) with `POST /sim/overrides/stage`, confirm the diff preview renders in under 2s, then `DELETE /sim/overrides` to clear them unapplied.
6. One throwaway live model call (any beat-02-style evidence citation) to confirm API reachability before judges arrive.
7. Open `GET /` once, confirm `#clock-bar` shows the 12-hex `world_hash` / `BASELINE_FIXTURE_HASH` pair and the `LIVE`/`RECORDED` badge toggles correctly when `TRUEUP_DEMO_MODE` is flipped.
8. Confirm all twelve buttons in `00-decisions.md` section 1.3 render with the correct enabled/disabled state for `IDLE_BASELINE` per the state table in `02-state-machine-and-time.md`.
9. Leave `TRUEUP_DEMO_MODE=live` for the judge session; only flip to `cached` deliberately if GPF is invoked.


---

# 05 Weaknesses a Maximor judge will attack, and the smallest fixes

Deliverable 10. Written from the seat of a finance-automation engineer who has watched many "AI accountant" demos and called a cash-only point solution "very meh".
Every attack is aimed at a named line of the existing design. Every fix is a spec edit or under 2 hours of build on top of the 50 hours in `03-playbook-memory-and-api.md` line 268.
Nothing here changes the product spec. W08 is the one place this specification departs from `WORLD_SPEC.md`, and its spec edits are **applied**: `00-decisions.md` section 1 now pins PO-1063 at $415,000.00 as a declared departure, and `02-state-machine-and-time.md` section 5 now carries leakage test LK11. Every other fix below is still open build work.

## 0. Arithmetic, computed once

| Quantity | Working | Result |
|---|---|---|
| SCN-A tolerance | `max(500.00, 0.02 x 50,000.00 = 1,000.00)` | 1,000.00 |
| SCN-A 8% variance | `50,000.00 x 1.08 = 54,000.00`; `54,000.00 - 50,000.00` | 4,000.00 |
| SCN-A 12% variance | `50,000.00 x 1.12 = 56,000.00`; `56,000.00 - 50,000.00` | 6,000.00 |
| Prior-period Controller trigger | `WORLD_SPEC` 1.5 line 130: `>= 25,000.00`; `6,000.00 < 25,000.00` | no approver today |
| V005 frozen error | `6,752.00 - 6,400.00 = 352.00`; tolerance `max(500.00, 0.02 x 6,400.00 = 128.00) = 500.00` | inside tolerance, still wrong |
| PO-1063 back-solve today | `360,000.00 / 12` (`WORLD_SPEC` line 263) | 30,000.00, the held-out answer |
| PO-1063 pinned cap (applied) | `415,000.00 / 12 = 34,583.33`; nearest offered fee 33,000.00, gap `1,583.33 > 500.00` | no back-solve |
| V018 cap check | `12 x 33,000.00 = 396,000.00 <= 415,000.00` | `VAL-PRODUCTION-FEE` passes |
| Replay coverage today | `1 touched / 35 replayed` (`04` line 50) | 2.86% |

## 1. Ranked attacks

| # | Attack, as the judge says it | Hits | Smallest fix | Cost |
|---|---|---|---|---|
| W01 | "You learned one if-statement." | `00` 2 lines 69-75, `04` 2 | Add the V005 row to `#transfer-panel`: same policy, opposite action | 1.5 h |
| W02 | "The LLM is decorative." | `03` 3 steps 4-6 | Ablation card: classifier vs always-guess vs keyword, over 54 obligations | 1.5 h |
| W03 | "This is still scripted." | `01` 1.2, `02` line 106, `04` line 192 | Free numeric escalator entry, plus leakage test LK7 run live on screen | 2 h |
| W04 | "That policy was hand-written." | `03` 2, `00` 1.7 | Model emits 3 candidate scopes, replay ranks them, show all 3 | 2 h |
| W05 | "One improved obligation out of 35 proves nothing." | `04` line 50 | Replay also over `erp/accrual_schedule_prior.csv`, 2026-05 to 2026-10 | 2 h |
| W06 | "Your true-up posts into a closed period and nobody signs it." | `02` 4, `00` line 144 | `out_of_period` flag, route true-up to the accrual's approver, SUD table | 1.5 h |
| W07 | "Approval is a JSON field." | `03` 5, `03` line 209 | Approver picker with role check, `btn-revoke-policy`, promote/revoke monitor | 1.5 h |
| W08 | "The PO states the answer, and you edited the world to hide it." | `00` line 6 vs `WORLD_SPEC` line 263 | Pin PO-1063 at 415,000.00 not-to-exceed, add leakage test LK11 | **spec applied**, 0.5 h build left |
| W09 | "It is a hard-coded accounting workflow." | `WORLD_SPEC` line 137, `03` 3 | Coverage and autonomy panel over all 54 obligations | 1 h |
| W10 | "It will die live, and the fallback throws away my change." | `04` line 158, `02` line 164 | Focus set of 4 obligations, one retry, GPF keeps the judge's world | 2 h |
| W11 | "The Lab is a cage with four buttons in it." | `01` line 56, `00` line 77 | Allow two stacked overrides, print the reachable-world count | 1 h |
| W12 | "Your GL does not tie to the AP subledger by document." | `WORLD_SPEC` line 366, `02` 4 | AP tie-out line in the audit packet | 0.5 h |

Total 17 hours across the four existing tracks. Cut order: W11, W12, W04, W09. W01, W03, W06 and W10 are never cut.

## 2. The attacks in full

### W01. Only one root cause generalises

- **Attack.** "Every control ends in the same place. `CTL-USAGE-SPIKE` is always correct. Duplicate, terminate and cadence are all labelled 'same' in your own table. Surcharge is always UNKNOWN. The only thing this system can ever learn is POL-0001. That is one if-statement with a review screen on it."
- **Why it lands.** `00-decisions.md` lines 69-75 mark five of nine controls "same" or "identical" for the learned agent. `seeded_root_causes.json` (`WORLD_SPEC` line 791) has three root causes and sets `expected_policy_type` to null on two. SCN-B consumes POL-0001 rather than producing anything (`04` line 99).
- **Smallest fix.** Add a second row to `#transfer-panel`: `OBL-V005-2027-01`, PagerLoop, `pricing_structure = VENDOR_NOTIFIED_UPLIFT`, no pricing exhibit on file. Fixture, truth row and the 9-hour scripted reply already exist (`WORLD_SPEC` line 753). The same POL-0001 predicate matches, and with no document the verifier returns `OUTREACH_REQUIRED`, then `ESCALATE` at cutoff. One policy, three actions: attach the exhibit (V018), cite the footnote clause (V004), ask then escalate (V005).
- **Answer.** "One rule, three vendors, three different actions, and on this one the right answer is to stop and ask rather than book a number."

### W02. The LLM is decorative

- **Attack.** "Your estimator is code, your verifier is code, your matcher is code, your replay is code, and the policy never enters the model context. Delete the model, hard-code `SCHEDULED_PRICE_CHANGE`, and the demo is identical."
- **Why it lands.** `03` section 3 steps 4 to 6 state that the `PolicySet` goes only to the deterministic verifier and that the LLM sees features, evidence and the tool catalogue. In SCN-A the model makes one enum choice from seven values (`WORLD_SPEC` line 343).
- **Smallest fix.** Pre-compute an ablation card for `#audit-panel` from the existing rubric in `WORLD_SPEC` 4.2. Three columns over all 54 obligations: LLM classifier, always-`SCHEDULED_PRICE_CHANGE`, keyword match on the invoice line. Report root-cause accuracy and unnecessary-review rate for each, plus mean tool calls per obligation, frozen 1 (`04` line 84) against learned 7 (`04` lines 76-82, seven trail rows). Run once pre-demo, store the JSON, render it.
- **Answer.** "The model does retrieval and diagnosis, here is the number that says it beats both cheap baselines, and every dollar stays deterministic on purpose because a Controller cannot sign a figure a model invented."

### W03. This is still scripted

- **Attack.** "You gave me four radio buttons on three vendors, your clock jumps to timestamps you hard-coded, and your sixty-second variant literally says 'result pre-warmed'. I picked from your menu."
- **Why it lands.** `01` line 42 is a radio group. `02` line 106 fixes `target_ts` per state and forbids free text. `04` line 192 says pre-warmed. `00` line 267 keeps a recorded run for the baseline hash.
- **Smallest fix.** Two edits. (a) `CTL-ESCALATOR-PCT` on V001 becomes a number input, integer 0 to 25, validated by `VAL-ESCALATOR-PCT`; the four values stay as preset chips for the sixty-second variant only. (b) After `btn-apply-mutation`, run leakage test LK7 (`02` line 236) live against the rebuilt world and print the result in `#diff-panel`: the searched string, the file count scanned, and "found only in `contracts/pricing_schedules/PS-001.txt`". Keep the fixed `target_ts` and label it in the UI as a leakage control, not a script.
- **Answer.** "Type any escalator you like; the number you just typed exists in exactly one file in this company right now, and the agent has not opened it yet."

### W04. The policy is a hand-written rule in disguise

- **Attack.** "POL-0001 is printed verbatim in your spec with a fixed `created_at`. And your two predicates are one predicate: `has_scheduled_price_change` is true if and only if `pricing_structure` is one of those three values. A model deriving that from evidence would not write it twice."
- **Why it lands.** `03` lines 95 to 108 carry the literal record. `WORLD_SPEC` line 370 defines the biconditional. The whitelist is nine fields (`00` line 58), so the search space the model supposedly explored is small and visible.
- **Smallest fix.** `POST /api/policy/candidate` asks the model for three candidate scopes: the exact one, a broader one with `pricing_structure_in` dropped, a narrower one with `has_pricing_exhibit = true` added. Run G1 and the existing replay engine on all three. `#learning-panel` shows three rows with `improved`, `regressed` and `forward_scope_preview` size, chosen row highlighted. The narrow scope drops `OBL-V005-2027-01` from preview, which is the visible reason it loses.
- **Answer.** "It wrote three rules and the replay chose one; here is the one it rejected for being too narrow and the one it rejected for firing on vendors it should not touch."

### W05. Replay on a tiny history proves nothing

- **Attack.** "Thirty-five obligations, one touched, thirty-four unchanged, four not even comparable. Your regression test is n equals one against a world your own generator produced. Of course it improves."
- **Why it lands.** `04` line 50 and `WORLD_SPEC` line 846 give improved 1, regressed 0, unchanged 34. `compared_on_action_only` holds four rows with no actual yet (`WORLD_SPEC` line 838). That is 2.86% of the replay set moving.
- **Smallest fix.** Extend the replay set with `erp/accrual_schedule_prior.csv`, the human team's 2026-05 to 2026-10 rollforward, which already carries `accrued`, `actual` and `variance` per vendor-month, prepared by E004 and reviewed by E002. No new fixture. The replay report prints two denominators: TrueUp obligations (35) and human-prepared prior accruals (count computed at run time), each with feature-matched, would-have-changed and regressed counts. DataForge has no rows there, so the honest headline is "no regression against the accruals a human team actually signed".
- **Answer.** "It replayed against every accrual this close team posted in the last six months, not only against its own."

### W06. Accounting correctness: reversal, true-up posting, cutoff, materiality

- **Attack.** "December closed at 2027-01-05T23:59:59. On 2027-01-12 you post four thousand dollars of December expense into January and nobody approves it. Where is the out-of-period disclosure, and where is the summary of unadjusted differences my auditor asks for?"
- **Why it lands.** `02` lines 189 to 192 date `JE-TRU-` at the invoice `received_date` with no approval step, and `00` line 144 states the convention and stops. At 12% the variance is 6,000.00, below the 25,000.00 prior-period Controller trigger in `WORLD_SPEC` line 130, so nothing routes to a human at all.
- **Smallest fix.** Three additions, all in the workpaper and audit packet. (a) `TrueUpAdjustment` gains `out_of_period: true` plus a rendered line: "prior-period adjustment; 2026-12 expense understated 4,000.00; recorded in 2027-01 because 2026-12 closed 2027-01-05T23:59:59". (b) Any true-up outside tolerance routes to the approver of its own accrual, E001 here, regardless of the 25,000.00 threshold. (c) `#audit-panel` gains a Summary of Unadjusted Differences table: every out-of-period true-up in the period, signed, with a total. The reversal `JE-REV-V001-2026-12` dated 2027-01-01 is already correct and unchanged.
- **Answer.** "The miss lands in January as a prior-period adjustment, it goes back to the same Controller who signed the accrual, and it sits on the unadjusted-differences schedule with everything else."

### W07. Why would a Controller trust this

- **Attack.** "Your approve call takes `actor: E001` in the request body. I can approve as your Controller with curl. The policy goes ACTIVE_PROVISIONAL and nothing ever promotes or revokes it. That is a button, not a control."
- **Why it lands.** `03` section 5 and line 209 check only that a string equals `E001`. `WORLD_SPEC` line 865 says POL-0001 moves to ACTIVE after the January true-ups, and nothing in `00` to `04` implements or shows that step. `REVOKED` exists in the enum (`00` line 54) with no path to it.
- **Smallest fix.** (a) `#learning-panel` renders an approver picker seeded from `org_directory.json`; the server returns `403` for any actor whose `role` is not `CONTROLLER`, and stores the name on the `policy_events` row. (b) Add `btn-revoke-policy` and `POST /api/policy/revoke`, writing `POLICY_REVOKED` and moving the active version pointer back to `1.0`. (c) After the transfer run, print the monitor line: in-scope 2027-01 obligations inside tolerance, with the stated rule that 4 of 4 promotes to ACTIVE and any regression revokes.
- **Answer.** "Only a Controller can approve it, it stays provisional until January proves it, and one button puts the company back on version 1.0 with no code change."

### W08. Leakage through the Lab or the PO amount

- **Attack.** "PO-1063 is 360,000, which is twelve times 30,000, which is your held-out answer. The transfer proof is sitting in a document the agent may read. And you noticed, because `00-decisions.md` quietly changes it to 400,000 in a spec that says the world is frozen."
- **Why it lands.** `WORLD_SPEC` line 263 states the problem in its own words and defends it only with "the v1.0 `FIXED_CONTRACT_FEE` estimator never reads PO amounts", which is a blindfold, not a control. The second half of the attack landed on the first draft of `00` line 6, which moved a frozen fixture value to 400,000.00 with no departure note; that is the worse finding of the two, and it is the part now fixed in place.
- **Smallest fix, applied.** Spec edit in `00-decisions.md` section 1, written as a declared departure with its reason: PO-1063 `authorized_amount` becomes 415,000.00, a not-to-exceed that authorises spend and states no price. `415,000.00 / 12 = 34,583.33`, and the nearest offered fee 33,000.00 sits 1,583.33 away, wider than the 500.00 tolerance on any V018 accrual. Leakage test LK11 is in `02-state-machine-and-time.md` section 5: for every offered parameter value of `CTL-ESCALATOR-PCT` and `CTL-ESCALATOR-DATE`, and for every purchase order linked to the affected obligation, `authorized_amount / 12` must differ from the resulting monthly fee by more than that obligation's tolerance. The scope is those two controls because they are the only ones where the price is a fact the agent must retrieve rather than read off the contract it already has. `VAL-PRODUCTION-FEE` now checks `12 x fee <= 415000.00`. Remaining build: 0.5 h to implement LK11.
- **Answer.** "The PO caps spend and states no price, and a test asserts that no PO in this company divides into a price the agent has not earned."

### W09. It is a hard-coded accounting workflow

- **Attack.** "Five estimator methods, twelve invariants, seven root causes. Bring a vendor that fits none of the five and it escalates. You automated the easy eighty percent a spreadsheet macro already does. This is the cash point solution again."
- **Why it lands.** `WORLD_SPEC` line 137 lists exactly five methods with fixed required evidence, and `03` section 3 runs the same seven-step pipeline for every obligation. The long tail escalates by construction, and the demo never quantifies how large it is.
- **Smallest fix.** Stop hiding it and score it. Add a coverage and autonomy panel above `#close-board`, computed from `GET /api/obligations` across all 54 obligations: count and dollars by `required_approval_level` (`NONE`, `REVIEWER`, `CONTROLLER`), count `ESCALATED`, count `NO_ACCRUAL_DOCUMENTED`, share of dollars posted with no human touch, and unsupported autonomous postings (target 0, `WORLD_SPEC` line 898). Give the escalation count the same visual weight as the automation count.
- **Answer.** "Escalation is the product, not the failure mode; the number we optimise is dollars closed with no human and zero unsupported postings, and both are on this screen."

### W10. Latency and live-demo failure

- **Attack.** "You run a whole close live in twelve seconds. When it stalls, your fallback resets the world and replays a recording of your baseline. So the one thing I care about, my own number, is the first thing you throw away."
- **Why it lands.** `04` line 166 gives beat 5 twelve seconds for a 35-obligation close. `04` line 158 resets to `BASELINE_FIXTURE_HASH` and plays a recording. `02` line 164 calls a Reset Demo hash mismatch "not recoverable live".
- **Smallest fix.** (a) `POST /api/close/run` accepts `obligation_ids[]`; the demo path sends a focus set of four, the judge's obligation plus `OBL-V008-2026-12`, `OBL-V012-2026-11` and `OBL-V019-2026-12`, so the live path is four model paths, not thirty-five; the rest are computed deterministically and rendered as one summary row. (b) On a stall past 5 seconds, retry that single obligation once with a 3-second budget before GPF. (c) GPF keeps the judge's world: the fallback runs the deterministic half and shows the classifier step as `ESCALATED`, `reason = AGENT_RUN_FAILED`, which is already a legal state (`02` line 97).
- **Answer.** "If the model does not answer it escalates to the Controller with your number still on the screen, which is exactly what it should do at two in the morning on close night."

### W11. The Lab is a cage

- **Attack.** "One change per run, nine controls, and six of them are on your own cut list. Real close breakage is two things at once: a price step and a late invoice."
- **Why it lands.** `01` line 56 disables the whole panel after Apply unless `allow_multi=true`, and nothing in the demo flow ever sets it. `00` line 77 puts six of the nine controls in the cut order, leaving three guaranteed.
- **Smallest fix.** Allow exactly two stacked overrides when they target different files, and enable it for the realistic pair `CTL-ESCALATOR-PCT` plus `CTL-INVOICE-DELAY`: the price steps and the bill is late. Invariants INV-1 to INV-10 already run against the rebuilt world, so consistency needs no new code. Print the reachable-world count in `#lab-panel`, computed from the control catalogue at load.
- **Answer.** "Stack a price step and a three-week late invoice if you like; the world rebuilds consistent either way, and the panel shows how many distinct companies you can build from it."

### W12. The GL does not tie to the AP subledger

- **Attack.** "One invoice of 52,500 becomes two journal entries, 50,000 and 2,500, with different entry types. My AP subledger holds one document. Your tie-out breaks on day one."
- **Why it lands.** `WORLD_SPEC` line 366 and `02` lines 189 to 192 create `JE-INV-` and `JE-TRU-` separately so the true-up is visible on screen. That is a presentation choice leaking into the ledger model.
- **Smallest fix.** Keep both entries, because the split is what makes the learning signal auditable, and add a tie-out block to `GET /api/audit/{id}`: `invoice_id`, the `ap_queue.csv` row, both entry ids, their sum, and an equality assertion. Render as one line in `#audit-panel`: "INV-V001-008 52,500.00 = JE-INV 50,000.00 + JE-TRU 2,500.00; account 2000 credited 52,500.00 once".
- **Answer.** "Two entries, one document, one credit to Accounts Payable, and the packet proves it on a single line."


---

