# TrueUp Close: Northstar synthetic world and dataset specification

Status: specification only, no code changed. Builds on the existing generator in `data/gen/` and fixture set in `data/northstar/`.
Product direction is frozen in `trueup_close_team_spec.pdf`. Sections are also kept separately under `data/spec/`.

## 1. Northstar company model and planted cases

Scope: the static company world that every other section builds on. Source of truth in code is `data/gen/world.py`; this section lists what stays, what is added, and what changes. Anything not mentioned here stays as it is today.

Terms used once and then assumed:
- **Accrual**: an expense booked at month-end for service received but not yet invoiced. It auto-reverses on day 1 of the next month.
- **True-up**: the difference between the later actual invoice and the accrual (`actual - accrued`).
- **Cutoff**: the last moment an invoice counts as "on hand" for a period.
- **In arrears / in advance**: invoiced after / before the service period.

### 1.1 Entities, departments and cost centers

| entity_id | name | country | currency |
|---|---|---|---|
| NS-US | Northstar Analytics, Inc. | US | USD |
| NS-UK | Northstar Analytics UK Ltd | GB | USD (books kept in USD; no FX anywhere) |

Cost centers are unchanged (13 rows). Each has exactly one budget owner. No new employees are needed.

| cost_center | department | budget owner | vendors charged here |
|---|---|---|---|
| CC-100 | Data Engineering | E010 Priya Raman | V001 |
| CC-110 | Platform / SRE | E011 Sam Okafor | V002, V005, V013 |
| CC-120 | Customer Support | E012 Maria Santos | V003 |
| CC-130 | Sales | E013 Jordan Blake | V004, **V019** |
| CC-140 | PMO | E014 Nina Petrov | V006 |
| CC-150 | Legal | E015 Rachel Kim | V007 |
| CC-160 | Workplace | E016 Omar Farouk | V008, V014 |
| CC-170 | People / HR | E017 Grace Liu | V009, V011 |
| CC-180 | Security | E018 Victor Hale | V010 |
| CC-190 | Marketing | E019 Elena Rossi | V012, **V018** |
| CC-200 | Business Intelligence | E020 Dev Patel | V015 |
| CC-210 | IT | E021 Chris Novak | V016 |
| CC-300 | UK Operations (NS-UK) | E022 Harriet Cole | V017 |

Requesters (the person who raised the PO) stay: E030 Ben Adler (V001), E031 Yuki Tanaka (V003), E032 Luis Moreno (V006). For every other vendor, including V018 and V019, `requester = operational_owner`.

### 1.2 Finance roles and who approves what

| employee_id | name | role tag | Does | Approves |
|---|---|---|---|---|
| E001 | Dana Whitfield | CONTROLLER | Signs off each close. Owns every ESCALATED item. | Accruals >= $25,000; all ESCALATE decisions; prior-period items >= $25,000; every learned policy |
| E002 | Marcus Oyelaran | ACCOUNTING_MANAGER | Reviews workpapers. | Accruals $10,000.00 to $24,999.99; any accrual with confidence < 0.85 under $25,000 |
| E003 | Sofia Brandt | AP_SPECIALIST | Owns the AP queue, mailbox, duplicate holds, vendor onboarding. | Nothing. Answers `AP_STATUS` outreach. Places and releases `HOLD_DO_NOT_POST`. |
| E004 | Ken Ito | CLOSE_ACCOUNTANT | Prepared all history accruals by hand (`posted_by = E004`). Preparer of `erp/accrual_schedule_prior.csv`. | Nothing. TrueUp takes over his preparer work from 2026-11. |
| E005 | Laila Haddad | FPA | Background only. | Nothing |
| E006 | Tom Reyes | TREASURY | Background only. | Nothing |

Rules: preparer and approver are never the same person. TrueUp is the preparer for 2026-11 onward and writes `posted_by = "TRUEUP"`. The enum for approval level is `NONE | REVIEWER | CONTROLLER`; `REVIEWER` always resolves to E002, `CONTROLLER` to E001.

### 1.3 Chart of accounts (15 rows: existing 14 plus one)

| account | name | type | used by |
|---|---|---|---|
| 1000 | Cash | asset | not posted to; kept for completeness |
| 1300 | Prepaid Expenses | asset | V010 annual prepaid, V015 January portion ($4,200) |
| 2000 | Accounts Payable | liability | credit side of every `INVOICE` entry |
| **2050** | **Corporate Card Payable** | liability | **new**; credit side of `CARD_EXPENSE` entries |
| 2100 | Accrued Expenses | liability | credit side of every `ACCRUAL` entry |
| 6100 | Data Services Expense | expense | V001 |
| 6110 | Cloud Hosting Expense | expense | V002, V013 |
| 6120 | Software Subscriptions | expense | V003, V004, V005, V009, V010, V015, V018, V019 |
| 6200 | Professional Services | expense | V006 |
| 6210 | Legal Fees | expense | V007 |
| 6300 | Rent and Facilities | expense | V008, V017 |
| 6310 | Facilities Maintenance | expense | V014 |
| 6400 | Recruiting Fees | expense | V011 |
| 6500 | Marketing Programs | expense | V012 |
| 6600 | Telecom | expense | V016 |

`gl_entries.csv` keeps its columns and gains one trailing column, `obligation_id` (blank on seed and card rows, required on every `TRUEUP` row). `entry_type` enum becomes: `INVOICE, ACCRUAL, ACCRUAL_CARRYFORWARD, ACCRUAL_REVERSAL, AMORTIZATION, CARD_EXPENSE, TRUE_UP`. `posted_by` is an employee id, `CARD_FEED` or `TRUEUP`.

**CARD_EXPENSE clearing approach.** A corporate-card charge is expensed directly: Dr expense / Cr 2050. It never touches 2000 Accounts Payable, has no invoice, no PO and an empty `vendor_id`. The only vendor clue is the merchant descriptor in `memo`. Settlement of 2050 against cash is not emitted (same as AP payments, which are also not emitted). The two SignalStack pilot entries, exact rows:

```csv
entry_id,line_no,posting_date,period,legal_entity_id,account,cost_center,vendor_id,debit,credit,entry_type,reference,memo,reversal_of,posted_by,obligation_id
JE-CARD-0001,1,2026-11-03,2026-11,NS-US,6120,CC-190,,12000.0,0.0,CARD_EXPENSE,CARD-4417-20261103,Corp card x4417 (E019) SIGNALSTACK INC pilot fee Nov 2026,,CARD_FEED,
JE-CARD-0001,2,2026-11-03,2026-11,NS-US,2050,CC-190,,0.0,12000.0,CARD_EXPENSE,CARD-4417-20261103,Corp card x4417 (E019) SIGNALSTACK INC pilot fee Nov 2026,,CARD_FEED,
JE-CARD-0002,1,2026-12-02,2026-12,NS-US,6120,CC-190,,12000.0,0.0,CARD_EXPENSE,CARD-4417-20261202,Corp card x4417 (E019) SIGNALSTACK INC pilot fee Dec 2026,,CARD_FEED,
JE-CARD-0002,2,2026-12-02,2026-12,NS-US,2050,CC-190,,0.0,12000.0,CARD_EXPENSE,CARD-4417-20261202,Corp card x4417 (E019) SIGNALSTACK INC pilot fee Dec 2026,,CARD_FEED,
```

JE-CARD-0001 is in the T0 seed. JE-CARD-0002 is a future fact released at `2026-12-02T09:00` (event type `EVIDENCE_UPDATE`, target `gl_entries.csv`). There is no card row for January: production service is invoiced. No SignalStack obligation exists for 2026-11 or 2026-12.

### 1.4 Close calendar and period statuses

Period status enum (field `company.json.close_calendar[].status`): `FUTURE` (month still running or not started; postings allowed), `OPEN` (month ended, TrueUp is closing it), `CLOSED` (Controller signed off; no postings allowed). Cutoff is `23:59:59` on the cutoff date. The period goes `CLOSED` at the cutoff instant; all approvals for the period happen on or before the cutoff date.

**Snapshot rule:** an invoice with `received_date` after the cutoff is never booked into the period just cut off. It is booked in the next period and matched to the accrual. This covers the Beacon invoice of 2027-01-07.

| period | type | OPEN from | cutoff date | CLOSED at | policy version in force at cutoff |
|---|---|---|---|---|---|
| 2026-05..2026-10 | history | n/a | n/a | CLOSED at T0 | human process |
| 2026-11 | warm-up | 2026-12-01T00:00 (= T0) | 2026-12-05 | 2026-12-05T23:59:59 | 1.0 |
| 2026-12 | the failure (TRAIN) | 2027-01-01T00:00 | 2027-01-05 | 2027-01-05T23:59:59 | 1.0 |
| 2027-01 | held-out | 2027-02-01T00:00 | 2027-02-05 | 2027-02-05T23:59:59 | 1.1 (learned arm) or 1.0 (frozen arm) |

Each `OPEN from` and `CLOSED at` cell is one `PERIOD_STATUS_CHANGE` event (six events in total; the first fires at T0 and is already applied in the seed). `company.json.close_calendar` at T0:

```json
[{"period":"2026-11","cutoff":"2026-12-05","status":"OPEN"},
 {"period":"2026-12","cutoff":"2027-01-05","status":"FUTURE"},
 {"period":"2027-01","cutoff":"2027-02-05","status":"FUTURE"}]
```

January reveal timeline (all between the December cutoff and the January cutoff):

| when | what |
|---|---|
| 2027-01-07 | Beacon final invoice INV-V019-008 received, $1,838.71 |
| 2027-01-08 | V018 vendor master record created (09:00); CTR-018 and PS-018 filed in the contract repository (10:00); PO-1063 issued ($360,000, 11:00) |
| 2027-01-12 | DataForge INV-V001-008 (DF-2256) received, $52,500; true-up +$2,500, outside tolerance ($1,000) |
| 2027-01-13 | POL-0001 candidate created and replay-tested over all 2026-11 and 2026-12 obligations |
| 2027-01-15 | E001 approves POL-0001; policy version 1.1 provisionally active |
| 2027-01-22 | Meridian INV-V007-006 received, $41,870 (accrued $40,000; +$1,870, outside tolerance of $800, explained as Controller judgement) |
| 2027-02-05 | January cutoff. Invoice missing for: V001, V002, V004, V005, V006, V011, V012, V013, V014, V018 |

### 1.5 Control policy v1.0 (compact)

| rule | value |
|---|---|
| Cutoff day | 5th of the following month |
| Auto-prepare with no human (`NONE`) | amount < $10,000 **and** confidence >= 0.85 |
| Reviewer approval (`REVIEWER`, E002) | $10,000.00 to $24,999.99, or confidence < 0.85 below $25,000 |
| Controller approval (`CONTROLLER`, E001) | amount >= $25,000; any verifier result `ESCALATE`; prior-period item >= $25,000 |
| Threshold basis | absolute accrual amount per obligation, USD |
| True-up tolerance | greater of $500 or 2% of the accrued amount; outside tolerance opens a root-cause review |
| Outreach wait | 48 hours, then next-best owner |
| Accrual reversal | auto-reverse on day 1 of the next period |
| Conflicting evidence or no allowed method | never post; `ESCALATE` to Controller |

Allowed estimation methods and the evidence each one requires in v1.0 (the DataForge gap is the first row):

| method | required evidence (v1.0) | limits |
|---|---|---|
| `FIXED_CONTRACT_FEE` | `contract`, `service_period` | none. **Does not require the pricing schedule.** |
| `USAGE_X_RATE` | `usage_record`, `contract_rate` | rate card must cover the usage tier |
| `PRORATED_FEE` | `contract`, `service_dates` | day-count basis: actual days in month |
| `PO_BASED` | `purchase_order`, `service_receipt` | estimate <= remaining PO balance |
| `HISTORICAL_RUN_RATE` | `prior_invoices_min_3` | amount <= $10,000 and variation <= 10%; confidence capped at 0.70 |

Version 1.1 = version 1.0 plus POL-0001. Nothing else changes.

### 1.6 Vendor master: 19 vendors

`vendors.json` columns after the change: `vendor_id, name, category, spend_type, gl_account, cost_center, legal_entity_id, operational_owner, requester, billing_contact, billing_email, contract_id, po_id, payment_terms, onboarded_date, status, notes`. `status` enum is `ACTIVE | TERMINATED`; every vendor, including V019, is `ACTIVE` in all three periods (procurement never updated Beacon, the same deliberate conflict as the open PO-0962). The `pricing_model` column is **deleted**. `spend_type` enum: `SUBSCRIPTION | USAGE | SERVICES | RENT | OTHER`. `onboarded_date` is new (ISO date). V018 is absent from the seed `vendors.json` and appears through a `VENDOR_ONBOARDED` event on 2027-01-08.

In the table below, **cadence** and **typical monthly** are design facts for the generator and the truth tree only. They are never written to `vendors.json`.

| vendor_id | name | sells | spend_type | entity | CC | owner | GL | cadence (truth only) | contract | PO | typical monthly (truth only) | role in dataset |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| V001 | DataForge Inc. | market data feed | SUBSCRIPTION | NS-US | CC-100 | E010 | 6100 | monthly, arrears; on time in history and 2026-11, ~11 days late for 2026-12 and 2027-01 | CTR-001 + PS-001 | PO-1029 | $50,000 then $52,500 from 2026-12 | **C03** train; Jan precedent |
| V002 | CloudHarbor LLC | cloud compute | USAGE | NS-US | CC-110 | E011 | 6110 | monthly, arrears | CTR-002 | PO-1011 | $36,000 + overage | **C05** |
| V003 | Helpline Desk Co. | support desk seats | SUBSCRIPTION | NS-US | CC-120 | E012 | 6120 | monthly, arrears | CTR-003 | PO-1017 | $10,200 (120 x $85) | background: change order CO-1 |
| V004 | Lumen CRM Corp. | CRM | SUBSCRIPTION | NS-US | CC-130 | E013 | 6120 | monthly, arrears | CTR-004 | PO-1008 | $18,000 then $18,720 | held-out extra (footnote uplift) |
| V005 | PagerLoop Inc. | on-call alerting | SUBSCRIPTION | NS-US | CC-110 | E011 | 6120 | monthly, arrears | CTR-005 | PO-1021 | $6,400 then $6,752 | **C12** |
| V006 | Brightwork Consulting Group | PMO consulting, T&M | SERVICES | NS-US | CC-140 | E014 | 6200 | monthly, arrears, ~15 days late | CTR-006 | PO-1042 | $17,760 to $29,600 | **C09** |
| V007 | Meridian Legal LLP | outside counsel | SERVICES | NS-US | CC-150 | E015 | 6210 | irregular | CTR-007 (engagement letter) | none | $4,100 to $41,870 | **C10** |
| V008 | OfficeNest Properties | HQ rent | RENT | NS-US | CC-160 | E016 | 6300 | monthly, advance | CTR-008 | none | $22,500 | **C01** |
| V009 | PayCircle Inc. | payroll SaaS | SUBSCRIPTION | NS-US | CC-170 | E017 | 6120 | monthly, arrears | CTR-009 | PO-1005 | $4,150 | background: $830 mismatch |
| V010 | SecureLayer Systems | security platform | SUBSCRIPTION | NS-US | CC-180 | E018 | 6120 | annual prepaid | CTR-010 | PO-1033 | $8,000 amortization | background: not an accrual |
| V011 | TalentBridge Partners | contingent recruiting | SERVICES | NS-US | CC-170 | E017 | 6400 | per hire | CTR-011 | none | $0 or 20% of salary | background: unaccrued Oct fee |
| V012 | PrintWorks Studio | print jobs | OTHER | NS-US | CC-190 | E019 | 6500 | per job, one PO per job | CTR-012 | PO-0977, PO-1002, PO-1046, PO-1058 | $0 to $7,850 | **C07** |
| V013 | StreamGrid Networks | CDN egress | USAGE | NS-US | CC-110 | E011 | 6110 | monthly, arrears | CTR-013 | PO-1014 | $8,000 + overage | background: tiered overage |
| V014 | Atlas Facilities Services | janitorial and maintenance | SERVICES | NS-US | CC-160 | E016 | 6310 | quarterly, arrears | CTR-014 | PO-1019 | $4,500 | **C02** |
| V015 | Quantive BI Ltd. | BI tool | SUBSCRIPTION | NS-US | CC-200 | E020 | 6120 | monthly, advance, from the 15th | CTR-015 | PO-1051 | $9,300 | **C08** |
| V016 | Northwind Telecom | voice and internet | OTHER | NS-US | CC-210 | E021 | 6600 | monthly, arrears | CTR-016 | none | $5,350 to $5,520 | **C11** |
| V017 | Thames Workspace Ltd | UK office | RENT | NS-UK | CC-300 | E022 | 6300 | monthly, arrears | CTR-017 | none | $6,900 | background: wrong entity |
| **V018** | **SignalStack Inc.** | product analytics SaaS | SUBSCRIPTION | NS-US | CC-190 | E019 | 6120 | pilot by card; production monthly, arrears | CTR-018 + PS-018 | PO-1063 (2027-01-08) | $12,000 pilot, $30,000 production | **C04** held-out transfer |
| **V019** | **Beacon Survey Tools** | survey SaaS | SUBSCRIPTION | NS-US | CC-130 | E013 | 6120 | monthly, arrears | CTR-019 + TN-019 | PO-0962 | $3,800 | **C06** |

New vendor master records, literal:

```json
{"vendor_id":"V018","name":"SignalStack Inc.","category":"SAAS_OR_DATA","spend_type":"SUBSCRIPTION","gl_account":"6120","cost_center":"CC-190","legal_entity_id":"NS-US","operational_owner":"E019","requester":"E019","billing_contact":"SignalStack Billing","billing_email":"billing@signalstack.example","contract_id":"CTR-018","po_id":"PO-1063","payment_terms":"Net 30","onboarded_date":"2027-01-08","status":"ACTIVE","notes":"Onboarded from corporate card to AP"}
{"vendor_id":"V019","name":"Beacon Survey Tools","category":"SAAS_OR_DATA","spend_type":"SUBSCRIPTION","gl_account":"6120","cost_center":"CC-130","legal_entity_id":"NS-US","operational_owner":"E013","requester":"E013","billing_contact":"Beacon Accounts","billing_email":"accounts@beaconsurvey.example","contract_id":"CTR-019","po_id":"PO-0962","payment_terms":"Net 30","onboarded_date":"2025-03-18","status":"ACTIVE","notes":""}
```

New POs: `PO-1063` V018, blanket, $360,000, issued 2027-01-08, covers 2027-01-01..2027-12-31 (released by a `PO_ISSUED` event). `PO-0962` V019, blanket, $45,600 (12 x $3,800), issued 2026-03-20, covers 2026-04-01..2027-03-31, status `OPEN` and never closed. The open PO is deliberate: it conflicts with TN-019.

Invoice number prefixes for the new vendors: V018 `SS`, V019 `BS`. Beacon invoices: INV-V019-001..006 for history, INV-V019-007 for 2026-11 (BS-2249, dated 2026-11-30, received 2026-12-03, $3,800), INV-V019-008 final (BS-2256, dated 2026-12-31, received 2027-01-07, service 2026-12-01..2026-12-15, $1,838.71).

### 1.7 The twelve planted cases

Obligation key format everywhere: `OBL-{vendor_id}-{period}`. "Frozen" means the v1.0 agent with no learned policy. Spec required-case names are quoted from the product spec section "Required cases"; SC-16 is success criterion 16 ("improves or safely escalates a held-out future case").

| case | obligation | what is planted | files that carry the conflict | expected TrueUp behaviour | spec required case |
|---|---|---|---|---|---|
| C01 | OBL-V008-2026-11, -12, -2027-01 | Rent $22,500, invoiced in advance (ON-2249 received 2026-10-25, ON-2256 2026-11-25, ON-2263 2026-12-25). | none. Invoice, contract CTR-008 and AP row agree. | Match invoice to contract. `ACTUAL_INVOICE`, verifier `PASS`, outcome `CLOSE_READY`. No accrual, no outreach, approval `NONE`. | Exact recurring invoice match |
| C02 | OBL-V014-2026-11 (also -12, -2027-01) | $4,500/month. One quarterly invoice for Nov to Jan arrives 2027-02-08, so all three cutoffs have no invoice. | CTR-014 (quarterly in arrears) vs AP queue (no row) vs `accrual_schedule_prior.csv` (E004 accrued $4,500 monthly with zero variance). | `FIXED_CONTRACT_FEE` $4,500, confidence >= 0.85, approval `NONE`, outcome `ACCRUED`. Dr 6310 / Cr 2100. On 2027-02-08 split the $13,500 invoice three ways; true-up $0 each. | Missing invoice, high-confidence fixed contract |
| C03 | OBL-V001-2026-12 (TRAIN) | Order form says $50,000 "(Contract Year 1)". PS-001 says CY2 from 2026-12-01 is $52,500. v1.0 does not require the pricing schedule. | `contracts/CTR-001` order form vs `contracts/pricing_schedules/PS-001`; PO-1029 and six history invoices all say $50,000. | Outreach to VENDOR_BILLING about timing only (reply after 30 h: invoices go out around Jan 11). Accrue $50,000 Dr 6100 / Cr 2100 dated 2026-12-31, approval `CONTROLLER`, reverse 2027-01-01. On 2027-01-12 match DF-2256, true-up +$2,500, outside tolerance, `root_cause = SCHEDULED_PRICE_CHANGE` with process cause `PROCEDURE_GAP_REQUIRED_EVIDENCE`, propose POL-0001. | DataForge 5% escalator |
| C04 | OBL-V018-2027-01 (HELDOUT) | Order form "Pilot Fee $12,000.00 per month". PS-018: production $30,000 from 2027-01-01. Two $12,000 card charges corroborate the wrong number. Invoice SS-10031 arrives 2027-02-12. | `contracts/CTR-018` order form + GL `CARD_EXPENSE` rows vs `contracts/pricing_schedules/PS-018` + PO-1063 ($360,000 = 12 x $30,000). | Frozen: accrues $12,000, approval `REVIEWER`, error -$18,000. With POL-0001: features show `has_scheduled_price_change = true`, verifier returns `BLOCK` (PS-018 is in the repository but not attached) until PS-018 is attached, then `FIXED_CONTRACT_FEE` $30,000, approval `CONTROLLER`. Dr 6120 / Cr 2100. True-up $0. | SC-16, improves |
| C05 | OBL-V002-2026-12 | 352,000 hours. Correct: $36,000 + 52,000 x $0.15 = $43,800. Shortcut 352,000 x $0.12 = $42,240. Invoice CH-2256 arrives 2027-01-08. | `evidence/usage_daily.csv` vs CTR-002 rate card (commit, included hours, overage rate in separate clauses); prior schedule shows flat $36,000 for six months. | `USAGE_X_RATE` with tiered rate, $43,800, approval `CONTROLLER`, `ACCRUED`. True-up $0. Never uses run rate. | extra (usage-based spend) |
| C06 | OBL-V019-2026-12 and OBL-V019-2027-01 | Service ends 2026-12-15. Final invoice $1,838.71 arrives 2027-01-07. Run rate says $3,800 for both months. | `contracts/notices/TN-019` vs open PO-0962 (through 2027-03-31), vendor master `status = ACTIVE`, seven straight $3,800 invoices, `service_activity.csv` (activity stops 2026-12-15). | Dec: `PRORATED_FEE` 3,800 x 15/31 = $1,838.71, approval `NONE`, `ACCRUED`; true-up $0. Jan: classification `NO_INVOICE_SERVICE_NOT_RECEIVED`, outcome `NO_ACCRUAL_DOCUMENTED`, reason cites TN-019. | extra (termination) |
| C07 | exception on OBL-V012-2026-11 | Invoice 7731 ($7,850, received 2026-12-01) re-sent as 7731-R, dated 2026-12-17, received 2026-12-18. Same PO-1046, amount, service period. | `invoices/` and `ap_queue.csv` hold both; `goods_receipts.csv` has one receipt for PO-1046; PO balance covers one. | 7731: `CLOSE_READY`. 7731-R: `invoice_status = DUPLICATE_SUSPECTED`, exception `EXC-INV-V012-004`, verifier `BLOCK`, status `HOLD_DO_NOT_POST`, notify E003. No second expense, no accrual in December. | Duplicate invoice |
| C08 | OBL-V015-2026-12 and OBL-V015-2027-01 | INV-V015-001 $9,300 covers 2026-12-15..2027-01-14. AP coded the full amount to December. | invoice service period vs `ap_queue.csv` coding (`period = 2026-12`, full $9,300 to 6120). | Allocate by days: 17/31 x 9,300 = $5,100 to December, $4,200 to 1300 Prepaid then January. Flag AP coding, approval `NONE`, `CLOSE_READY` with allocation. January expense = $4,200 + $5,100 (from QB-2214) = $9,300. | Multi-period invoice |
| C09 | OBL-V006-2026-12 | T&M $185/hour. 142 hours = $26,270. Last two weekly timesheets (weeks ending 2026-12-18 and 2026-12-25, 38 + 36 hours) are `PENDING`, not `APPROVED`. Invoice BW-2221 arrives 2027-01-15. | `evidence/timesheets.csv` approved hours (68) vs all logged hours (142); PO-1042 balance. | Verifier `OUTREACH_REQUIRED`, fact `SERVICE_RECEIVED`, target OPERATIONAL_OWNER E014 (reply after 20 h confirms 142 h). Then `USAGE_X_RATE` (142 h x $185) $26,270, approval `CONTROLLER`, `ACCRUED`. True-up $0. | Missing service confirmation |
| C10 | OBL-V007-2026-12 | Owner E015 says $35,000 to $45,000. Vendor WIP report says $58,000 before write-downs. No PO, no rate card, history too volatile for run rate. | inbox reply from E015 vs inbox reply from Meridian billing; CTR-007 engagement letter has no cap. | No amount from TrueUp. Verifier `ESCALATE`, outcome `ESCALATED` to E001 with both figures and sources. Controller decides $40,000; TrueUp records it with `estimator_method = NONE` and the Controller reply (`response_type = DECISION`) as evidence, Dr 6210 / Cr 2100. Invoice $41,870 on 2027-01-22; true-up +$1,870. | Unknown/conflicting evidence |
| C11 | OBL-V016-2026-11 | NT-2249 $5,480, dated 2026-11-30, was sent to retired mailbox `ap-old@northstar.example`. Without outreach it surfaces 2026-12-09, after cutoff. | `ap_queue.csv` (no row) vs vendor reply (invoice sent 2026-11-30, PDF attached). | Outreach VENDOR_BILLING, fact `INVOICE_WHEREABOUTS` (reply after 5 h with the invoice). Book the actual $5,480, `ACTUAL_INVOICE`, `CLOSE_READY`. No estimate. Tell E003 about the mailbox. | Missing invoice response from vendor |
| C12 | OBL-V005-2027-01 (HELDOUT) | CTR-005 allows an annual uplift "as notified by vendor". The rate is in no internal file. Actual 5.5%: $6,400 to $6,752. Invoice PL-2263 arrives 2027-02-09. | CTR-005 clause vs PO-1021 and history ($6,400); no pricing schedule exists. | Frozen: accrues $6,400, error -$352. With POL-0001: `has_scheduled_price_change = true`, evidence missing, `OUTREACH_REQUIRED` to VENDOR_BILLING, fact `SCOPE_OR_RATE_CHANGE` (reply after 9 h: 5.5%). Then $6,752, approval `NONE`. If no reply by cutoff: `ESCALATED` to E001 (the Controller owns every escalation), never a silent $6,400. | SC-16, safely escalates |

Coverage check: all eight spec required cases are hit (C01, C02, C03, C07, C08, C09, C10, C11). C04 and C12 cover success criterion 16. C05 and C06 are extra coverage for the usage and prorated methods. Background scenarios (V003, V004, V009, V010, V011, V013, V017, and DataForge January) keep their existing rows and carry `case_id = ""` in the truth tree.


## 2. Source systems, files and schemas

All paths are relative to `runtime/visible/`. The simulator copies `world/seed/` there at T0 = `2026-12-01T00:00` and then appends rows or adds files as events are released. TrueUp tools get this root only.

Conventions. Types: `str`, `int`, `dec` (number, 2 decimals, USD), `bool`, `date` (`YYYY-MM-DD`), `ym` (`YYYY-MM`), `ts` (`YYYY-MM-DDTHH:MM:SS`, company local time, no offset), `enum`, `[]` = list. CSV blanks mean null. An `evidence_id` is the primary key of a visible record (for example `CTR-001`, `PS-001`, `INV-V001-008`, `SA-DATAFORGE-2026-12`). Files with a composite key use the form given in the table. Existing paths from the first fixture set are kept; only new sources get new folders.

### 2.1 File inventory

| Path | Imitates | Format | Primary key (evidence_id form) | Grows after T0 via |
|---|---|---|---|---|
| `company.json` | ERP setup | JSON object | n/a | `PERIOD_STATUS_CHANGE` rewrites `close_calendar[].status` |
| `org_directory.json` | Org directory / HRIS | JSON object | `employee_id`; contacts `(vendor_id, role)` | `VENDOR_ONBOARDED` adds V018 contact |
| `vendors.json` | Procurement vendor master | JSON list | `vendor_id` | `VENDOR_ONBOARDED` adds V018 on 2027-01-08 |
| `purchase_orders.json` | Procurement | JSON list | `po_id` | `PO_ISSUED` adds PO-1063 on 2027-01-08 |
| `change_orders.json` | Procurement | JSON list | `change_order_id` | `PO_ISSUED` adds CO-1 on 2026-12-10 |
| `contracts/index.json` | Contract repository index | JSON list | `doc_id` | `CONTRACT_DOC_ADDED` |
| `contracts/CTR-0NN.pdf` + `.txt` | Contract repository | PDF + text | `doc_id` = `CTR-0NN` | `CONTRACT_DOC_ADDED` (CTR-018) |
| `contracts/pricing_schedules/PS-0NN.pdf` + `.txt` | Contract repository | PDF + text | `doc_id` = `PS-0NN` | `CONTRACT_DOC_ADDED` (PS-018) |
| `contracts/notices/TN-019.pdf` + `.txt` | Contract repository | PDF + text | `doc_id` = `TN-019` | seed only |
| `invoices/invoices.json`, `invoices/pdf/<invoice_id>.pdf` | AP inbox capture | JSON list + PDF | `invoice_id` | `INVOICE_RECEIVED` |
| `ap_queue.csv` | AP subledger / queue | CSV | `ap_id` | `INVOICE_RECEIVED` (same event as the invoice) |
| `gl_entries.csv` | ERP GL extract | CSV | `(entry_id, line_no)`; evidence_id = `entry_id` | `EVIDENCE_UPDATE` (Dec card row); TrueUp posting tool |
| `erp/accrual_schedule_prior.csv` | Close team spreadsheet | CSV | `(vendor_id, period)`; `ACS-V007-2026-10` | seed only |
| `evidence/usage_daily.csv` | Usage / metering export | CSV | `(vendor_id, date, metric)`; monthly `USG-V002-2026-12` | `USAGE_EXPORT`, whole month at 06:00 on day 1 of next month |
| `evidence/service_activity.csv` | SSO + vendor admin consoles | CSV | `activity_id` | `EVIDENCE_UPDATE`, whole month at 06:00 on day 1 of next month |
| `evidence/seat_snapshots.csv` | Vendor admin console | CSV | `(vendor_id, snapshot_date)`; `SEAT-V003-2026-12-10` | `EVIDENCE_UPDATE` |
| `evidence/timesheets.csv` | PMO timesheet tool | CSV | `(vendor_id, week_ending)`; `TS-V006-2026-12-25` | `EVIDENCE_UPDATE` (new weeks, approvals) |
| `evidence/hr_hires.csv` | HRIS | CSV | `hr_record_id` | `EVIDENCE_UPDATE` |
| `evidence/goods_receipts.csv` | Procurement receiving | CSV | `receipt_id` | `EVIDENCE_UPDATE` |
| `close_policy_manual.md` | Policy manual (prose) | Markdown | section number | new version file on policy activation |
| `policies.json` | Policy manual (data) | JSON object | `policy_version` | rewritten by TrueUp on activation of v1.1 |
| `inbox/messages.jsonl` | Shared close inbox | JSON lines | `message_id` | simulator only: OUTBOUND row when TrueUp calls `send_outreach`, INBOUND row after `delay_hours` |

`inbox/scripted_responses.json` moves to `world/private/inbox/scripted_responses.json` and is never visible. `ground_truth/` is renamed `world/private/truth/`.

### 2.2 Schemas and example records

**company.json** keys: `name` str, `description` str, `base_currency` str, `entities[]` {`entity_id`, `name`, `country`}, `cost_centers[]` {`id`, `name`}, `chart_of_accounts[]` {`account`, `name`, `type` enum asset/liability/expense}, `close_calendar[]` {`period` ym, `cutoff` date, `status` enum FUTURE/OPEN/CLOSED}, `closed_periods[]` ym. Add account `2050 Corporate Card Payable` (liability). Status meaning: FUTURE = month still running or not started (postings allowed), OPEN = month ended and in close, CLOSED = no postings. OPEN starts at 00:00 on day 1 of the next month; CLOSED starts at the cutoff instant (23:59:59 on the cutoff date). The verifier check PERIOD_OPEN passes when status is not CLOSED. At T0: 2026-11 OPEN, 2026-12 and 2027-01 FUTURE.
```json
{"period": "2026-12", "cutoff": "2027-01-05", "status": "FUTURE"}
```

**org_directory.json** `employees[]`: `employee_id` str PK, `name`, `title`, `role` enum (CONTROLLER, ACCOUNTING_MANAGER, AP_SPECIALIST, CLOSE_ACCOUNTANT, BUDGET_OWNER, REQUESTER, FPA, TREASURY), `cost_center` FK company.cost_centers nullable, `legal_entity_id` FK, `email`. `vendor_contacts[]`: `vendor_id` FK vendors, `name`, `email`, `role` enum VENDOR_BILLING/VENDOR_ACCOUNT_MANAGER.
```json
{"employee_id": "E019", "name": "Elena Rossi", "title": "VP Marketing", "role": "BUDGET_OWNER", "cost_center": "CC-190", "legal_entity_id": "NS-US", "email": "elena.rossi@northstar.example"}
```

**vendors.json** columns: `vendor_id` str PK, `name` str, `category` enum (SAAS_OR_DATA, CLOUD_USAGE, CONSULTING, LEGAL, FACILITIES, RENT, RECRUITING, MARKETING, TELECOM; unchanged), `spend_type` enum (SUBSCRIPTION, USAGE, SERVICES, RENT, OTHER), `gl_account` FK chart, `cost_center` FK, `legal_entity_id` FK, `operational_owner` FK employee, `requester` FK employee, `billing_contact` str, `billing_email` str, `contract_id` FK contracts/index nullable, `po_id` FK PO nullable, `payment_terms` str, `onboarded_date` date, `status` enum ACTIVE/TERMINATED, `notes` str. The old `pricing_model` column is deleted. Mapping from the old values: FIXED_MONTHLY, FIXED_MONTHLY_ADVANCE_MIDMONTH, PER_SEAT, ANNUAL_PREPAID -> SUBSCRIPTION; USAGE_TIERED -> USAGE; TIME_AND_MATERIALS, HOURLY_NO_CAP, CONTINGENT_PER_HIRE, FIXED_QUARTERLY_ARREARS -> SERVICES; FIXED_MONTHLY_ADVANCE (OfficeNest) and Thames serviced office (V017) -> RENT; PER_JOB_PO, VARIABLE_MONTHLY -> OTHER. V018 and V019 are SUBSCRIPTION. `notes` must not mention prices, escalators or schedules. `status` is ACTIVE for all 19 vendors in all three periods, including V019 (procurement never updated it; deliberate conflict with TN-019, like the open PO-0962).
```json
{"vendor_id": "V001", "name": "DataForge Inc.", "category": "SAAS_OR_DATA", "spend_type": "SUBSCRIPTION", "gl_account": "6100", "cost_center": "CC-100", "legal_entity_id": "NS-US", "operational_owner": "E010", "requester": "E030", "billing_contact": "Amira Khan", "billing_email": "billing@dataforge.example", "contract_id": "CTR-001", "po_id": "PO-1029", "payment_terms": "Net 30", "onboarded_date": "2025-11-20", "status": "ACTIVE", "notes": ""}
{"vendor_id": "V018", "name": "SignalStack Inc.", "category": "SAAS_OR_DATA", "spend_type": "SUBSCRIPTION", "gl_account": "6120", "cost_center": "CC-190", "legal_entity_id": "NS-US", "operational_owner": "E019", "requester": "E019", "billing_contact": "SignalStack Billing", "billing_email": "billing@signalstack.example", "contract_id": "CTR-018", "po_id": "PO-1063", "payment_terms": "Net 30", "onboarded_date": "2027-01-08", "status": "ACTIVE", "notes": "Onboarded from corporate card to AP"}
```

**purchase_orders.json**: `po_id` PK, `vendor_id` FK, `owner` FK employee, `requester` FK employee, `cost_center` FK, `legal_entity_id` FK, `authorized_amount` dec, `type` enum BLANKET_ANNUAL/PROJECT_TM/ONE_TIME, `valid_from` date, `valid_to` date, `issued_date` date, `status` enum OPEN/CLOSED, `description` str. Blanket POs that ended 2026-12-31 are extended to 2027-12-31 at the same `authorized_amount`, so extended PO amounts never encode a future price. New for Beacon: PO-0962 (V019, BLANKET_ANNUAL, 45600.0, 2026-04-01..2027-03-31, issued 2026-03-20, OPEN). PO-1063 is the one PO whose amount implies a future price (360000 = 12 x 30000); the v1.0 `FIXED_CONTRACT_FEE` estimator never reads PO amounts.
```json
{"po_id": "PO-1063", "vendor_id": "V018", "owner": "E019", "requester": "E019", "cost_center": "CC-190", "legal_entity_id": "NS-US", "authorized_amount": 360000.0, "type": "BLANKET_ANNUAL", "valid_from": "2027-01-01", "valid_to": "2027-12-31", "issued_date": "2027-01-08", "status": "OPEN", "description": "SignalStack product analytics, 2027"}
```

**change_orders.json**: `change_order_id` PK, `po_id` FK, `vendor_id` FK, `effective_date` date, `requested_by` FK, `approved_by` FK, `description` str, `seat_delta` int, `unit_price` dec, `po_increase` dec. Example: existing CO-1 (PO-1017, V003, 2026-12-10, +30 seats at 85.00).

**contracts/index.json**: `doc_id` PK, `doc_type` enum (MSA = every `CTR-0NN` file whatever its contract_type, PRICING_SCHEDULE, TERMINATION_NOTICE, VENDOR_NOTICE = the PagerLoop uplift notice `DOC-PAGERLOOP-UPLIFT-NOTICE`, filed under `inbox/attachments/` when the vendor reply arrives), `contract_id` str (groups documents of one agreement), `counterparty_name` str, `vendor_id` FK vendors nullable (null until the vendor is onboarded), `title` str, `effective_date` date, `filed_date` date, `filed_by` FK employee, `files[]` str, `supersedes` doc_id nullable. The `CTR-0NN` file holds the MSA followed by the Order Form (Exhibit A). The pricing schedule (Exhibit B) is always a separate document. CTR-018 and PS-018 are filed 2027-01-08 with the onboarding paperwork.
```json
{"doc_id": "PS-001", "doc_type": "PRICING_SCHEDULE", "contract_id": "CTR-001", "counterparty_name": "DataForge Inc.", "vendor_id": "V001", "title": "Exhibit B - Pricing Schedule", "effective_date": "2025-12-01", "filed_date": "2025-11-24", "filed_by": "E030", "files": ["contracts/pricing_schedules/PS-001.pdf", "contracts/pricing_schedules/PS-001.txt"], "supersedes": null}
```
Text layout of `PS-001.txt` (PS-018 is identical in form, rows `Pilot | 2026-11-01 | 2026-12-31 | $12,000.00` and `Production | 2027-01-01 | 2027-12-31 | $30,000.00`):
```
PRICING SCHEDULE (EXHIBIT B)   Document ID: PS-001   Contract ID: CTR-001
Contract Year | Start      | End        | Monthly Platform Fee
CY1           | 2025-12-01 | 2026-11-30 | $50,000.00
CY2           | 2026-12-01 | 2027-11-30 | $52,500.00
```
`TN-019.txt` header lines: `Document ID: TN-019`, `Contract ID: CTR-019`, `Notice date: 2026-11-14`, `Termination effective: 2026-12-15`, `Sent by: Jordan Blake (E013)`, then one paragraph citing the 30-day notice clause and "fees prorated to the effective date".

**invoices/invoices.json**: `invoice_id` PK, `invoice_number` str, `vendor_id` FK, `vendor_name`, `bill_to` str, `invoice_date` date, `received_date` date, `service_period_start` date, `service_period_end` date, `po_id` FK nullable, `currency` str, `amount` dec, `line_items[]` {`description`, `quantity` dec, `unit_price` dec, `amount` dec}, `payment_terms`, `received_channel`, `notes`. Number prefixes: add `SS` (V018, numbers start `SS-10031`) and `BS` (V019).
```json
{"invoice_id": "INV-V001-008", "invoice_number": "DF-2256", "vendor_id": "V001", "vendor_name": "DataForge Inc.", "bill_to": "Northstar Analytics, Inc.", "invoice_date": "2026-12-31", "received_date": "2027-01-12", "service_period_start": "2026-12-01", "service_period_end": "2026-12-31", "po_id": "PO-1029", "currency": "USD", "amount": 52500.0, "line_items": [{"description": "DataForge Platform subscription - December 2026 (Contract Year 2)", "quantity": 1, "unit_price": 52500.0, "amount": 52500.0}], "payment_terms": "Net 30", "received_channel": "ap@northstar.example", "notes": ""}
```

**ap_queue.csv**: `ap_id` PK (`AP-V001-008`), `invoice_id` FK, `invoice_number`, `vendor_id` FK, `received_date` date, `received_channel`, `amount` dec, `coded_entity` FK, `coded_account` FK, `coded_cost_center` FK, `po_id` FK nullable, `status` enum PENDING_APPROVAL/APPROVED/ON_HOLD/PAID, `approver` FK employee, `due_date` date, `paid_date` date nullable.
```
AP-V018-001,INV-V018-001,SS-10031,V018,2027-02-12,ap@northstar.example,30000.0,NS-US,6120,CC-190,PO-1063,PENDING_APPROVAL,E019,2027-03-02,
```

**gl_entries.csv**: `entry_id` str, `line_no` int, `posting_date` date, `period` ym, `legal_entity_id` FK, `account` FK, `cost_center` FK, `vendor_id` FK nullable, `debit` dec, `credit` dec, `entry_type` enum (INVOICE, ACCRUAL, ACCRUAL_CARRYFORWARD, ACCRUAL_REVERSAL, AMORTIZATION, CARD_EXPENSE, TRUE_UP), `reference` str, `memo` str, `reversal_of` entry_id nullable, `posted_by` str (employee id, `CARD_FEED`, or `TRUEUP`), `obligation_id` str nullable (new; blank on seed rows, required on every `TRUEUP` row). Seed entry ids are `JE-NNNNN`; card entries are `JE-CARD-0001` (Nov) and `JE-CARD-0002` (Dec, posting_date 2026-12-02, released by `EVIDENCE_UPDATE`); TrueUp entries are `JE-ACR-`, `JE-REV-`, `JE-INV-`, `JE-TRU-` + obligation or invoice suffix. Card rows have blank `vendor_id`; the merchant name appears only in `memo`.
```
JE-CARD-0001,1,2026-11-03,2026-11,NS-US,6120,CC-190,,12000.0,0.0,CARD_EXPENSE,CARD-4417-20261103,Corp card x4417 (E019) SIGNALSTACK INC pilot fee Nov 2026,,CARD_FEED,
JE-CARD-0001,2,2026-11-03,2026-11,NS-US,2050,CC-190,,0.0,12000.0,CARD_EXPENSE,CARD-4417-20261103,Corp card x4417 (E019) SIGNALSTACK INC pilot fee Nov 2026,,CARD_FEED,
JE-ACR-V001-2026-12,1,2026-12-31,2026-12,NS-US,6100,CC-100,V001,50000.0,0.0,ACCRUAL,ACR-V001-2026-12,Accrual DataForge Inc. service 2026-12,,TRUEUP,OBL-V001-2026-12
```

**erp/accrual_schedule_prior.csv** (the human team's rollforward, one row per vendor-month they accrued in 2026-05..2026-10): `vendor_id` FK, `vendor_name`, `period` ym, `gl_account` FK, `cost_center` FK, `basis` str (free text: "commit fee", "owner estimate", "quarterly contract"), `accrued` dec, `actual` dec nullable, `variance` dec nullable (= actual - accrued), `invoice_number` str nullable, `invoice_received` date nullable, `je_ref` FK gl_entries.reference, `preparer` FK employee, `reviewer` FK employee, `note` str. DataForge, SignalStack and Beacon have no rows (never accrued in history). Planted conflict: the V002 note says "accrue at commit, overage immaterial", which is false for 2026-12.
```
V007,Meridian Legal LLP,2026-10,6210,CC-150,owner estimate,12000.0,12750.0,750.0,ML-2228,2026-11-20,ACR-V007-2026-10,E004,E002,Owner estimate low; final bill included filing fees
```

**evidence/usage_daily.csv**: `vendor_id` FK, `date` date, `metric` enum compute_hours/egress_gb, `quantity` int, `source` str. Example: `V002,2026-12-01,compute_hours,11532,usage-export` (December sums to 352,000).

**evidence/service_activity.csv** (one row per application per month): `activity_id` PK (`SA-<APPKEY>-<period>`; APPKEY is the first word of the vendor name in capitals: DATAFORGE, LUMEN, PAGERLOOP, PAYCIRCLE, QUANTIVE, SIGNALSTACK, BEACON), `period` ym, `application` str, `vendor_id` FK nullable (blank when the vendor is not in the vendor master at export time; rows are never patched later, so SignalStack 2026-11 and 2026-12 stay blank), `source_system` str, `active_users` int, `active_days` int, `api_calls` int, `first_activity_date` date nullable, `last_activity_date` date nullable, `service_status` enum ACTIVE/PARTIAL/INACTIVE. Covers V001, V004, V005, V009, V015, V018, V019. Beacon: 2026-12 PARTIAL with `last_activity_date` 2026-12-15; 2027-01 INACTIVE with zeros.
```
SA-DATAFORGE-2026-12,2026-12,DataForge Platform,V001,okta-sso+dataforge-admin-api,41,31,1284000,2026-12-01,2026-12-31,ACTIVE
SA-SIGNALSTACK-2026-11,2026-11,SignalStack,,okta-sso,9,22,0,2026-11-04,2026-11-30,ACTIVE
SA-SIGNALSTACK-2027-01,2027-01,SignalStack,V018,okta-sso,64,31,412000,2027-01-01,2027-01-31,ACTIVE
```

**evidence/seat_snapshots.csv**: `vendor_id`, `snapshot_date` date, `active_seats` int, `source`. **evidence/timesheets.csv**: `vendor_id`, `po_id` FK, `week_ending` date, `service_month` ym, `hours` int, `rate` dec, `approval_status` enum APPROVED/PENDING, `approved_by` FK nullable, `approved_date` date nullable. **evidence/hr_hires.csv**: `vendor_id`, `employee_start_date` date, `role`, `base_salary` int, `source_agency`, `hr_record_id` PK. **evidence/goods_receipts.csv**: `vendor_id`, `po_id` FK, `delivery_date` date, `description`, `received_by` FK, `receipt_id` PK. Unchanged from the first fixture set. Example: `V006,PO-1042,2026-12-25,2026-12,36,185.0,PENDING,,`.

**policies.json**: `policy_version` str, `close_cutoff_day` int, `allowed_methods` {method: required_evidence_key[]}, `historical_run_rate_limits` {`max_amount`, `max_variation_pct`}, `approval_thresholds` {`auto_max` 9999.99, `reviewer_max` 24999.99, `min_auto_confidence` 0.85}, `true_up_tolerance` {`abs` 500.0, `pct` 2.0}, `prior_period_controller_threshold` dec, `outreach_wait_hours` int, `learned_policies[]`. Required-evidence keys: `contract`, `service_period`, `usage_record`, `contract_rate`, `service_dates`, `purchase_order`, `service_receipt`, `prior_invoices_min_3`, and (v1.1 only) `pricing_schedule_effective`. v1.0 line that causes the December miss: `"FIXED_CONTRACT_FEE": ["contract", "service_period"]`.

**inbox/messages.jsonl**: `message_id` PK (`MSG-<outreach_id>-O` outbound, `-R` reply), `thread_id` = `outreach_id`, `obligation_id` FK, `direction` enum OUTBOUND/INBOUND, `from` str, `to` str, `target_role` enum (OPERATIONAL_OWNER, REQUESTER, AP_SPECIALIST, VENDOR_BILLING, ACCOUNTING_MANAGER, CONTROLLER), `missing_fact` enum (SERVICE_RECEIVED, SCOPE_OR_RATE_CHANGE, INVOICE_WHEREABOUTS, AP_STATUS, TREATMENT; these five are the scripted-reply match keys and must not be extended), `sent_at` ts (stamped by the simulator: send time for OUTBOUND, delivery time for INBOUND), `response_type` enum DATA/CONFIRMATION/CONFLICTING/DECISION nullable, `body` str, `structured_facts` object, `attachments[]` evidence_id. Silence produces no row.
```json
{"message_id": "MSG-OUT-V001-2026-12-01-R", "thread_id": "OUT-V001-2026-12-01", "obligation_id": "OBL-V001-2026-12", "direction": "INBOUND", "from": "billing@dataforge.example", "to": "close@northstar.example", "target_role": "VENDOR_BILLING", "missing_fact": "INVOICE_WHEREABOUTS", "sent_at": "2027-01-03T16:00:00", "response_type": "DATA", "body": "We are migrating billing systems, so December invoices will go out around Jan 11. Apologies for the delay.", "structured_facts": {"expected_issue_date": "2027-01-11"}, "attachments": []}
```

### 2.3 Canonical VendorObligation

One record per vendor per service month, id `OBL-<vendor_id>-<ym>`. Stored in the TrueUp state store, not under `runtime/visible/`. Steps refer to product spec section 5.

| Field | Type | Set by step |
|---|---|---|
| `obligation_id`, `vendor_id`, `legal_entity_id`, `service_period_start`, `service_period_end`, `close_period`, `category`, `cost_center` | str, FK, FK, date, date, ym, enum, FK | 1 Discover |
| `contract_id`, `po_id`, `expected_bill_date` | FK nullable, FK nullable, date | 1 Discover; date updated by 6 Outreach |
| `invoice_status` | enum RECEIVED, MISSING, MISMATCHED, DUPLICATE_SUSPECTED, NOT_EXPECTED | 2 Gather; 8 True-up |
| `service_received_status` | enum CONFIRMED, PARTIAL, UNCLEAR, NOT_RECEIVED | 2 Gather; 6 Outreach |
| `evidence_ids` | evidence_id[] (append only) | 2, 6, 8 |
| `classification` (extension) | enum VALID_INVOICE_MATCHES, INVOICE_MISMATCHED, NO_INVOICE_SERVICE_RECEIVED, NO_INVOICE_SERVICE_UNCLEAR, NO_INVOICE_SERVICE_NOT_RECEIVED, INVOICE_SPANS_PERIODS, NO_ACCRUAL_PREPAID | 3 Classify |
| `outcome` (extension) | enum nullable: CLOSE_READY, ACCRUED, RECONCILED, ESCALATED (the four product-spec outcomes) plus NO_ACCRUAL_DOCUMENTED. Truth `ACCRUED_THEN_RECONCILED` = ACCRUED at cutoff, RECONCILED after the invoice | 7 Work product; 8 True-up |
| `estimator_method` | enum FIXED_CONTRACT_FEE, USAGE_X_RATE, PRORATED_FEE, PO_BASED, HISTORICAL_RUN_RATE, ACTUAL_INVOICE, NONE | 4 Estimate |
| `estimated_amount` | dec nullable (from deterministic estimator only) | 4 Estimate |
| `confidence_score`, `risk_score` | float 0..1 | 4 Estimate, 5 Verify |
| `policy_version_used` | str | 5 Verify |
| `approval_history` | Approval[] | 5 Verify / 7 Work product |
| `outreach_history` | OutreachTask[] | 6 Outreach |
| `accrual_entry_id` | FK gl_entries.entry_id nullable | 7 Work product (after approval) |
| `invoice_id`, `true_up_amount`, `root_cause` | FK nullable, dec nullable, enum nullable (SCHEDULED_PRICE_CHANGE, TIERED_OVERAGE_RATE, SCOPE_CHANGE, USAGE_VARIANCE, PRORATION, ESTIMATE_JUDGMENT, TIMING_ONLY) | 8 True-up |
| `status` | enum DISCOVERED, IN_EVIDENCE_GATHERING, INVOICE_VALIDATED, ACCRUAL_CANDIDATE, PENDING_REVIEW, ACCRUED, INVOICE_RECEIVED, MATCHED, TRUE_UP_REQUIRED, RECONCILED, OUTREACH_PENDING, ESCALATED, HOLD_DO_NOT_POST | every step |

OBL-V001-2026-12 right after accrual (2027-01-05, policy 1.0). Times follow the evaluation harness schedule in section 3 (outreach at pass 1, reply 30 hours later, proposal at pass 3); the demo run in section 5 uses its own later send time:
```json
{"obligation_id": "OBL-V001-2026-12", "vendor_id": "V001", "legal_entity_id": "NS-US",
 "service_period_start": "2026-12-01", "service_period_end": "2026-12-31", "close_period": "2026-12",
 "category": "SAAS_OR_DATA", "cost_center": "CC-100", "contract_id": "CTR-001", "po_id": "PO-1029",
 "expected_bill_date": "2027-01-11", "invoice_status": "MISSING", "service_received_status": "CONFIRMED",
 "evidence_ids": ["CTR-001", "PO-1029", "SA-DATAFORGE-2026-12", "INV-V001-007", "MSG-OUT-V001-2026-12-01-R"],
 "classification": "NO_INVOICE_SERVICE_RECEIVED", "estimator_method": "FIXED_CONTRACT_FEE",
 "estimated_amount": 50000.00, "confidence_score": 0.91, "risk_score": 0.30,
 "accrual_entry_id": "JE-ACR-V001-2026-12", "invoice_id": null, "true_up_amount": null, "root_cause": null,
 "status": "ACCRUED", "outcome": "ACCRUED", "policy_version_used": "1.0",
 "approval_history": [{"approval_id": "APR-V001-2026-12-01", "obligation_id": "OBL-V001-2026-12", "proposal_id": "PRP-V001-2026-12-01", "level": "CONTROLLER", "approver_id": "E001", "decision": "APPROVED", "decided_at": "2027-01-05T17:30:00", "comment": "Agrees to order form and November invoice."}],
 "outreach_history": [{"outreach_id": "OUT-V001-2026-12-01", "obligation_id": "OBL-V001-2026-12", "target_role": "VENDOR_BILLING", "target": "billing@dataforge.example", "missing_fact": "INVOICE_WHEREABOUTS", "sent_at": "2027-01-02T10:00:00", "status": "ANSWERED", "response_message_id": "MSG-OUT-V001-2026-12-01-R", "responded_at": "2027-01-03T16:00:00"}]}
```
After reconciliation (2027-01-12). Only these fields change; the rest is identical:
```json
{"invoice_status": "RECEIVED", "invoice_id": "INV-V001-008", "true_up_amount": 2500.00,
 "root_cause": "SCHEDULED_PRICE_CHANGE", "status": "RECONCILED", "outcome": "RECONCILED",
 "evidence_ids": ["CTR-001", "PO-1029", "SA-DATAFORGE-2026-12", "INV-V001-007", "MSG-OUT-V001-2026-12-01-R", "INV-V001-008", "PS-001"]}
```
`policy_version_used` stays `"1.0"`: it records the version that governed the accrual. The accrual auto-reverses on 2027-01-01 (`JE-REV-V001-2026-12`). The invoice posts in 2027-01 as two entries that together credit 2000 Accounts Payable $52,500: `JE-INV-V001-008` Dr 6100 / Cr 2000 $50,000 (the accrued portion, `entry_type = INVOICE`) and `JE-TRU-V001-2026-12` Dr 6100 / Cr 2000 $2,500 (`entry_type = TRUE_UP`, dated 2027-01-12). Net January effect is +$2,500. When the true-up is $0 only the `JE-INV-` entry exists. $2,500 exceeds tolerance (greater of $500 or 2% of $50,000 = $1,000), so the path is INVOICE_RECEIVED -> TRUE_UP_REQUIRED -> RECONCILED.

### 2.4 Observable ContractFeatures

Extracted by the Evidence Agent from repository documents, one record per `contract_id`, re-extracted whenever a document with that `contract_id` is added. Stored in TrueUp state. Learned-policy scopes read only this record and the estimator method. Fields: `contract_id` PK, `vendor_id` FK nullable, `source_doc_ids[]`, `extracted_at` ts, `contract_type` enum (MSA_ORDER_FORM, LEASE, SOW_TM, ENGAGEMENT_LETTER, SERVICE_AGREEMENT), `pricing_structure` enum (FLAT, SCHEDULED_STEP, ANNIVERSARY_ESCALATOR, VENDOR_NOTIFIED_UPLIFT, COMMIT_PLUS_OVERAGE, PER_SEAT, TIME_AND_MATERIALS, CONTINGENT_FEE, PER_JOB), `billing_cadence` enum (MONTHLY_ARREARS, MONTHLY_ADVANCE, QUARTERLY_ARREARS, ANNUAL_ADVANCE, PER_EVENT), `has_scheduled_price_change` bool (true iff pricing_structure is SCHEDULED_STEP, ANNIVERSARY_ESCALATOR or VENDOR_NOTIFIED_UPLIFT), `has_pricing_exhibit` bool, `has_usage_component` bool, `termination_notice_on_file` bool, `termination_effective_date` date nullable, `term_start` date, `term_end` date, `auto_renews` bool, `notice_days` int, `order_form_fee` dec nullable, `citations[]` {`feature`, `doc_id`, `locator`, `quote`}.
```json
{"contract_id": "CTR-001", "vendor_id": "V001", "source_doc_ids": ["CTR-001", "PS-001"], "extracted_at": "2026-12-01T08:00:00",
 "contract_type": "MSA_ORDER_FORM", "pricing_structure": "ANNIVERSARY_ESCALATOR", "billing_cadence": "MONTHLY_ARREARS",
 "has_scheduled_price_change": true, "has_pricing_exhibit": true, "has_usage_component": false, "termination_notice_on_file": false, "termination_effective_date": null,
 "term_start": "2025-12-01", "term_end": "2027-11-30", "auto_renews": false, "notice_days": 30, "order_form_fee": 50000.00,
 "citations": [{"feature": "has_pricing_exhibit", "doc_id": "CTR-001", "locator": "s4.3", "quote": "Fees for each Contract Year are set out in the Pricing Schedule (Exhibit B)."},
               {"feature": "order_form_fee", "doc_id": "CTR-001", "locator": "Order Form", "quote": "$50,000.00 per month (Contract Year 1)"}]}
{"contract_id": "CTR-018", "vendor_id": "V018", "source_doc_ids": ["CTR-018", "PS-018"], "extracted_at": "2027-01-08T14:00:00",
 "contract_type": "MSA_ORDER_FORM", "pricing_structure": "SCHEDULED_STEP", "billing_cadence": "MONTHLY_ARREARS",
 "has_scheduled_price_change": true, "has_pricing_exhibit": true, "has_usage_component": false, "termination_notice_on_file": false, "termination_effective_date": null,
 "term_start": "2026-11-01", "term_end": "2027-12-31", "auto_renews": false, "notice_days": 30, "order_form_fee": 12000.00,
 "citations": [{"feature": "pricing_structure", "doc_id": "PS-018", "locator": "table row 2", "quote": "Production | 2027-01-01 | 2027-12-31 | $30,000.00"},
               {"feature": "order_form_fee", "doc_id": "CTR-018", "locator": "Order Form", "quote": "Pilot Fee $12,000.00 per month"}]}
```
Under v1.0 the features are extracted and stored but no rule reads `has_scheduled_price_change`. That is the procedure gap.

### 2.5 ActionProposal and verifier result (PolicyEvaluation)

ActionProposal fields: `proposal_id` PK (`PRP-<vendor>-<ym>-NN`), `obligation_id` FK, `action_type` enum (POST_ACCRUAL, MARK_CLOSE_READY, POST_INVOICE, ALLOCATE_INVOICE, POST_TRUE_UP, NO_ACCRUAL_DOCUMENTED, HOLD_INVOICE, SEND_OUTREACH, ESCALATE), `period` ym, `amount` dec nullable, `currency` str, `accounts` {`debit` FK, `credit` FK}, `entry_date` date, `reversal_date` date nullable, `calculation_method` enum (same as `estimator_method`), `calculation_trace` {`inputs` object, `formula` str, `result` dec} written by the estimator code, `evidence_ids[]`, `confidence` float, `policy_version` str, `proposed_by` str (agent name), `created_at` ts.
```json
{"proposal_id": "PRP-V001-2026-12-01", "obligation_id": "OBL-V001-2026-12", "action_type": "POST_ACCRUAL", "period": "2026-12",
 "amount": 50000.00, "currency": "USD", "accounts": {"debit": "6100", "credit": "2100"}, "entry_date": "2026-12-31", "reversal_date": "2027-01-01",
 "calculation_method": "FIXED_CONTRACT_FEE", "calculation_trace": {"inputs": {"monthly_fee": 50000.00, "fee_source": "CTR-001 Order Form", "months": 1}, "formula": "monthly_fee * months", "result": 50000.00},
 "evidence_ids": ["CTR-001", "PO-1029", "SA-DATAFORGE-2026-12"], "confidence": 0.91, "policy_version": "1.0", "proposed_by": "estimation_agent", "created_at": "2027-01-05T17:00:00"}
```
PolicyEvaluation fields: `evaluation_id` PK (`PE-<proposal suffix>`), `proposal_id` FK, `obligation_id` FK, `policy_version` str, `result` enum PASS/REVIEW_REQUIRED/OUTREACH_REQUIRED/BLOCK/ESCALATE, `checks[]` {`invariant` enum, `passed` bool, `source` str (`BASE` or a learned policy id), `detail` str}, `missing_evidence[]` required-evidence key, `required_approval_level` enum NONE/REVIEWER/CONTROLLER, `next_action` {`type`, `target_role`, `missing_fact`} nullable, `evaluated_at` ts. Invariants: ENTRY_BALANCES, PERIOD_OPEN, SERVICE_RECEIPT_SUPPORTED, REQUIRED_IDENTIFIERS, NO_DUPLICATE_ACCRUAL, ALLOWED_METHOD, EVIDENCE_TRACE_COMPLETE, ENTITY_ACCOUNT_COMPATIBLE, MATERIALITY_APPROVAL, UNCERTAINTY_CANNOT_POST, NO_SILENT_POLICY_WEAKENING, ACTION_TRACEABLE. Result precedence: ESCALATE > BLOCK > OUTREACH_REQUIRED > REVIEW_REQUIRED > PASS. For `pricing_schedule_effective`: the key is satisfied when `evidence_ids` holds a document that states the price effective for the service period. Accepted sources: a PRICING_SCHEDULE document (PS-001, PS-018), the `CTR-0NN` document when ContractFeatures cites an escalator clause that states the rate (Lumen CTR-004 footnote, 4%), or a VENDOR_NOTICE document (PagerLoop). BLOCK when such a document exists in `contracts/index.json` but is not in `evidence_ids` or the amount does not use it; OUTREACH_REQUIRED (`target_role` VENDOR_BILLING, `missing_fact` SCOPE_OR_RATE_CHANGE) when none exists (PagerLoop before the reply). If no reply is visible at cutoff the result becomes ESCALATE to the Controller.
```json
{"evaluation_id": "PE-V001-2026-12-01", "proposal_id": "PRP-V001-2026-12-01", "obligation_id": "OBL-V001-2026-12", "policy_version": "1.0", "result": "REVIEW_REQUIRED",
 "checks": [{"invariant": "EVIDENCE_TRACE_COMPLETE", "passed": true, "source": "BASE", "detail": "FIXED_CONTRACT_FEE requires contract, service_period; both attached"},
            {"invariant": "MATERIALITY_APPROVAL", "passed": false, "source": "BASE", "detail": "50000.00 >= 25000.00"}],
 "missing_evidence": [], "required_approval_level": "CONTROLLER", "next_action": {"type": "REQUEST_APPROVAL", "target_role": "CONTROLLER", "missing_fact": null}, "evaluated_at": "2027-01-05T17:00:05"}
{"evaluation_id": "PE-V018-2027-01-01", "proposal_id": "PRP-V018-2027-01-01", "obligation_id": "OBL-V018-2027-01", "policy_version": "1.1", "result": "BLOCK",
 "checks": [{"invariant": "EVIDENCE_TRACE_COMPLETE", "passed": false, "source": "POL-0001", "detail": "has_scheduled_price_change=true; PS-018 exists but is not attached"},
            {"invariant": "MATERIALITY_APPROVAL", "passed": false, "source": "BASE", "detail": "12000.00 >= 10000.00"}],
 "missing_evidence": ["pricing_schedule_effective"], "required_approval_level": "REVIEWER", "next_action": {"type": "ATTACH_EVIDENCE", "target_role": null, "missing_fact": null}, "evaluated_at": "2027-02-02T10:00:05"}
```
All 12 checks are always written; the examples show two each for brevity.

### 2.6 Entity relationships: how `obligation_id` flows

Source records never carry `obligation_id` (they come from outside TrueUp). Every TrueUp-created record does.

| Record | Id form | Key to obligation | Other foreign keys |
|---|---|---|---|
| VendorObligation | `OBL-V001-2026-12` | PK | vendor_id, contract_id, po_id, legal_entity_id, cost_center |
| EvidenceFact (extracted fact + citation) | `EVF-V001-2026-12-03` | `obligation_id` | `evidence_id` (source record), `doc locator` |
| ContractFeatures | `CTR-001` | via obligation.contract_id | source_doc_ids |
| ActionProposal | `PRP-V001-2026-12-01` | `obligation_id` | evidence_ids[], policy_version |
| PolicyEvaluation | `PE-V001-2026-12-01` | `obligation_id` | proposal_id, policy_version, learned policy ids |
| AccrualWorkpaper | `WP-V001-2026-12` | `obligation_id` | proposal_id, evaluation_id, evidence_ids[] |
| Approval | `APR-V001-2026-12-01` | `obligation_id` | proposal_id, approver_id |
| OutreachTask / OutreachResponse | `OUT-V001-2026-12-01` / `MSG-...-R` | `obligation_id` | target employee or vendor contact, message_id |
| JournalEntry (gl_entries rows, `posted_by=TRUEUP`) | `JE-ACR-V001-2026-12`, `JE-REV-...`, `JE-INV-V001-008`, `JE-TRU-V001-2026-12` | `obligation_id` column | proposal_id in `reference`, reversal_of |
| InvoiceMatch | `IM-INV-V001-008` | `obligation_id` (one row per obligation for multi-period invoices, with `allocated_amount`) | invoice_id, accrual_entry_id |
| TrueUpAdjustment (the confirmed outcome that starts learning) | `TU-V001-2026-12` | `obligation_id` | invoice_id, accrual_entry_id, true_up_entry_id `JE-TRU-V001-2026-12`, `amount` 2500.00, `within_tolerance` false |
| VarianceExplanation (FP&A; also the root-cause classification record) | `VE-V001-2026-12` | `obligation_id` | true_up_id, root_cause |
| CashForecastLine (Treasury) | `CF-V001-2026-12` | `obligation_id` | invoice_id nullable, `expected_amount`, `due_date` |
| AuditFinding | `AF-V001-2026-12-01` | `obligation_id` | any linked record id |
| Exception (non-obligation items, e.g. C07 duplicate 7731-R) | `EXC-INV-V012-004` | `obligation_id` of the original invoice's obligation (`OBL-V012-2026-11`) | invoice_id, duplicate_of |
| Policy candidate / Replay report / ReplayResult row / policy approval | `POL-0001` / `RPL-POL-0001` / `RPL-POL-0001-OBL-V001-2026-12` / `APR-POL-0001` | `source_obligation_ids[]` / `obligation_id` | policy_id, baseline and replay evaluation_ids |


## 3. Three close periods, visibility timing and leakage prevention

Terms. **Cutoff**: the last moment an invoice counts as "received in time" for a period's close. **Accrual**: an estimated expense booked because the invoice is missing at cutoff. **True-up**: actual invoice minus accrual, computed when the invoice lands.

### 3.1 Clock conventions

| Item | Rule |
|---|---|
| Timestamp format | Naive company-local ISO 8601, `YYYY-MM-DDTHH:MM:SS`. No time zones anywhere. |
| T0 | `2026-12-01T00:00:00`. T_END = `2027-02-15T23:59:59` (last background invoice, Brightwork Jan, lands 2027-02-15). |
| Cutoff instant | `23:59:59` on the cutoff date. A record released on the cutoff date is on time. |
| Seed rule | Generator gives every record a `release_at`. `release_at <= T0` goes to `world/seed/`; everything else becomes one line in `world/private/events.jsonl`. |
| Default release time | INVOICE_RECEIVED 09:00; USAGE_EXPORT and monthly `service_activity` 06:00 on the 1st of the next month; VENDOR_ONBOARDED 09:00, CONTRACT_DOC_ADDED 10:00, PO_ISSUED 11:00; PERIOD_STATUS_CHANGE 00:00:00 on day 1 of the next month (OPEN) and 23:59:59 on the cutoff date (CLOSED). |
| Period status | `FUTURE -> OPEN -> CLOSED`, stored in `company.json.close_calendar[].status`. At T0: 2026-05..2026-10 CLOSED (`closed_periods`), 2026-11 OPEN, 2026-12 and 2027-01 FUTURE. |
| Harness passes per close | P1 = day 2 at 10:00 (detect, send outreach). P2 = day 4 at 10:00 (read replies, escalate). P3 = day 5 at 17:00 (final actions, propose entries). All outreach times below assume this schedule. |

Source column in the timeline: **W** = line in `events.jsonl`, **I** = triggered inbox reply, **T** = TrueUp or harness action (never in `events.jsonl`; shown for ordering only).

### 3.2 Master timeline

| When | Src | Event type | Record id | What becomes visible | Case |
|---|---|---|---|---|---|
| T0 | seed | SEED | - | GL history 2026-05..10; invoices received <= 2026-11-30 incl. INV-V008-007 (Nov rent), INV-V008-008 (Dec rent, received 2026-11-25), INV-V014-002 (Aug-Oct); CTR-001..017, CTR-019; PS-001; TN-019 (filed 2026-11-14); GL `JE-CARD-0001` CARD_EXPENSE $12,000 posted 2026-11-03; `erp/accrual_schedule_prior.csv` (2026-05..10); usage and service_activity through 2026-10 | all |
| 2026-12-01 06:00 | W | USAGE_EXPORT | USG-V002-2026-11 | CloudHarbor Nov daily rows, 296,000 h | C05 |
| 2026-12-01 06:00 | W | EVIDENCE_UPDATE | SVC-2026-11 | `service_activity` Nov rows (V001, V004, V005, V009, V019, plus `SA-SIGNALSTACK-2026-11` with blank `vendor_id`) | C03 C06 |
| 2026-12-01 09:00 | W | INVOICE_RECEIVED | INV-V012-003 | PrintWorks 7731, $7,850 | C07 |
| 2026-12-02 09:00 | W | INVOICE_RECEIVED | INV-V001-007 | DataForge DF-2249, $50,000 (CY1 rate) | C03 |
| 2026-12-02 09:00 | W | EVIDENCE_UPDATE | JE-CARD-0002 | GL CARD_EXPENSE $12,000, Dr 6120 / Cr 2050, memo contains `SIGNALSTACK INC`, `vendor_id` blank | C04 |
| 2026-12-02 10:00 | T | OUTREACH_SENT | - | P1 requests, incl. V016 VENDOR_BILLING INVOICE_WHEREABOUTS | C11 |
| 2026-12-02 15:00 | I | INBOX_REPLY | V016/2026-11 | Northwind reply (+5 h); early-releases INV-V016-007 NT-2249 $5,480 | C11 |
| 2026-12-03 09:00 | W | INVOICE_RECEIVED | INV-V019-007 | Beacon BS-2249, $3,800 (November, full month) | C06 |
| 2026-12-04 09:00 | W | INVOICE_RECEIVED | INV-V005-007 | PagerLoop Nov, $6,400 | C12 |
| 2026-12-05 23:59:59 | W | PERIOD_STATUS_CHANGE | PER-2026-11 | 2026-11 CLOSED; snapshot `2026-11-cutoff` | - |
| 2026-12-08 09:00 | W | INVOICE_RECEIVED | INV-V002-007 | CloudHarbor Nov, $36,000 | C05 |
| 2026-12-09 09:00 | W | INVOICE_RECEIVED | INV-V016-007 | Fallback only; skipped if already early-released | C11 |
| 2026-12-16 09:00 | W | INVOICE_RECEIVED | INV-V015-001 | Quantive $9,300, service 2026-12-15..2027-01-14 | C08 |
| 2026-12-18 09:00 | W | INVOICE_RECEIVED | INV-V012-004 | PrintWorks 7731-R, $7,850, note "Statement copy" | C07 |
| 2026-12-19, 12-26 09:00 | W | EVIDENCE_UPDATE | TS-V006-2026-12-18, TS-V006-2026-12-25 | Brightwork timesheets, `approval_status=PENDING` | C09 |
| 2026-12-25 09:00 | W | INVOICE_RECEIVED | INV-V008-009 | OfficeNest Jan rent $22,500 | C01 |
| 2027-01-01 00:00 | W | PERIOD_STATUS_CHANGE | PER-2026-12 | 2026-12 OPEN | - |
| 2027-01-01 06:00 | W | USAGE_EXPORT | USG-V002-2026-12 | CloudHarbor Dec, 352,000 h | C05 |
| 2027-01-01 06:00 | W | EVIDENCE_UPDATE | SVC-2026-12 | service_activity Dec: V001 active 31 days; V019 PARTIAL, `last_activity_date=2026-12-15`; SignalStack row still with blank `vendor_id` | C03 C06 |
| 2027-01-02 10:00 | T | OUTREACH_SENT | - | P1 requests for V001, V006, V007 | C03 C09 C10 |
| 2027-01-02 16:00 | I | INBOX_REPLY | V006/REQUESTER | E032: 142 h, two sheets unapproved (+6 h) | C09 |
| 2027-01-02 20:00 | I | INBOX_REPLY | V007/OPERATIONAL_OWNER | E015: $35-45k (+10 h) | C10 |
| 2027-01-03 06:00 | I | INBOX_REPLY | V006/OPERATIONAL_OWNER | E014 confirms 142 h (+20 h); early-releases timesheet patch to APPROVED | C09 |
| 2027-01-03 12:00 | I | INBOX_REPLY | V007/VENDOR_BILLING | WIP $58,000 before write-downs (+26 h) | C10 |
| 2027-01-03 16:00 | I | INBOX_REPLY | V001/VENDOR_BILLING | Timing only: invoices go out around Jan 11 (+30 h). No amount | C03 |
| 2027-01-04 10:00 / 14:00 | T / I | OUTREACH_SENT / INBOX_REPLY | V007/CONTROLLER | Escalation; E001 decides $40,000 (+4 h) | C10 |
| 2027-01-05 17:00 | T | ENTRIES_PROPOSED | - | Accruals dated 2026-12-31, reversal 2027-01-01: V001 $50,000 (Controller), V002 $43,800, V014 $4,500, V019 $1,838.71, V006 $26,270, V007 $40,000; V015 $5,100 expense + $4,200 prepaid; INV-V012-004 HOLD_DO_NOT_POST | C02-C10 |
| 2027-01-05 23:59:59 | W | PERIOD_STATUS_CHANGE | PER-2026-12 | 2026-12 CLOSED; snapshot `2026-12-cutoff` | - |
| 2027-01-07 09:00 | W | INVOICE_RECEIVED | INV-V019-008 | Beacon final BS-2256, $1,838.71, service 2026-12-01..12-15 | C06 |
| 2027-01-08 09:00 | W | INVOICE_RECEIVED | INV-V002-008 | CloudHarbor Dec, $43,800 | C05 |
| 2027-01-08 09:00 | W | EVIDENCE_UPDATE | TS-V006-PATCH | Fallback timesheet approval; skipped if early-released | C09 |
| 2027-01-08 09:00 | W | VENDOR_ONBOARDED | V018 | SignalStack row in `vendors.json`, billing contact in `org_directory.json` | C04 |
| 2027-01-08 10:00 | W | CONTRACT_DOC_ADDED | CTR-018, PS-018 | MSA + order form ("Pilot Fee $12,000.00 per month"); pricing schedule as separate PRICING_SCHEDULE doc | C04 |
| 2027-01-08 11:00 | W | PO_ISSUED | PO-1063 | $360,000, valid 2027-01-01..2027-12-31 | C04 |
| 2027-01-12 09:00 | W | INVOICE_RECEIVED | INV-V001-008 | DataForge DF-2256, dated 2026-12-31, $52,500 | C03 |
| 2027-01-12 09:05 | T | TRUE_UP | OBL-V001-2026-12 | $2,500 variance; tolerance is max($500, 2% x $50,000) = $1,000; exceeds | C03 |
| 2027-01-13 | T | POLICY_CANDIDATE, REPLAY | POL-0001 | Candidate, then replay over 2026-11 and 2026-12 obligations | loop |
| 2027-01-15 09:00 | W | INVOICE_RECEIVED | INV-V006-003 | Brightwork Dec, $26,270 | C09 |
| 2027-01-15 10:00 | T | POLICY_APPROVED | POL-0001 | Harness acts as E001; policy version 1.1 provisionally active | loop |
| 2027-01-16 09:00 | W | INVOICE_RECEIVED | INV-V015-002 | Quantive $9,300, service 2027-01-15..02-14 | C08 |
| 2027-01-22 09:00 | W | INVOICE_RECEIVED | INV-V007-006 | Meridian Dec, $41,870 | C10 |
| 2027-02-01 00:00 | W | PERIOD_STATUS_CHANGE | PER-2027-01 | 2027-01 OPEN; snapshot `2027-01-open` (fork point, 3.7 L4) | - |
| 2027-02-01 06:00 | W | USAGE_EXPORT, EVIDENCE_UPDATE | USG-V002-2027-01, SVC-2027-01 | CloudHarbor 310,000 h; service_activity Jan: `SA-SIGNALSTACK-2027-01` (first row with `vendor_id` V018) and V001 ACTIVE, V019 INACTIVE with zeros | C04 C05 C06 |
| 2027-02-02 10:00 / 19:00 | T / I | OUTREACH_SENT / INBOX_REPLY | V005/VENDOR_BILLING | Reply (+9 h): 5.5%, $6,752; early-releases DOC-PAGERLOOP-UPLIFT-NOTICE | C12 |
| 2027-02-05 23:59:59 | W | PERIOD_STATUS_CHANGE | PER-2027-01 | 2027-01 CLOSED; snapshot `2027-01-cutoff` | - |
| 2027-02-08 09:00 | W | INVOICE_RECEIVED | INV-V014-003, INV-V002-009 | Atlas Nov-Jan $13,500 (3 x $4,500); CloudHarbor Jan $37,500 | C02 C05 |
| 2027-02-09 09:00 | W | INVOICE_RECEIVED | INV-V005-009 | PagerLoop Jan, $6,752 | C12 |
| 2027-02-10 09:00 | W | INVOICE_RECEIVED | INV-V001-009 | DataForge DF-2263, $52,500 | C03 |
| 2027-02-11 09:00 | W | INVOICE_RECEIVED | INV-V004-009 | Lumen Jan, $18,720 | bg |
| 2027-02-12 09:00 | W | INVOICE_RECEIVED | INV-V018-001 | SignalStack SS-10031, dated 2027-01-31, $30,000 | C04 |

### 3.3 Snapshots

**A. November cutoff (2026-12-05T23:59:59).** Visible: seed plus rows above through 2026-12-05.

| Case | Visible evidence | Missing | Expected state |
|---|---|---|---|
| C01 | INV-V008-007 | - | CLOSE_READY. INV-V008-008 is December rent; not a November expense |
| C02 | CTR-014, INV-V014-002 | Nov invoice | Accrue $4,500, FIXED_CONTRACT_FEE |
| C03 | INV-V001-007 $50,000, PS-001 | - | CLOSE_READY |
| C04 | Two CARD_EXPENSE rows, `SA-SIGNALSTACK-2026-11` (blank `vendor_id`) | vendor, contract, PO | No obligation exists. The string `V018` is not in any file |
| C05 | 296,000 h (under 300,000) | INV-V002-007 | Accrue $36,000 |
| C06 | INV-V019-007, TN-019 | - | CLOSE_READY $3,800 |
| C11 | INV-V016-007 only if outreach was sent | - | CLOSE_READY at actual $5,480; without outreach a run-rate accrual is the wrong action |

**B. December cutoff (2027-01-05T23:59:59).** Added since A: rows 2026-12-08..2027-01-05. Not yet visible: INV-V001-008, INV-V002-008, INV-V019-008, INV-V006-003, INV-V007-006, INV-V014-003, every V018 record except the two card rows and the SignalStack service_activity rows (blank `vendor_id`). PS-001 has been visible since T0, so the $52,500 rate is discoverable at close; policy v1.0 does not require it.

**C. Revealed 2027-01-06..2027-02-04 (the "January reveal").** INV-V019-008 (01-07), INV-V002-008 (01-08), V018 vendor record + CTR-018 + PS-018 + PO-1063 (01-08), INV-V001-008 (01-12), INV-V006-003 (01-15), INV-V015-002 (01-16), INV-V007-006 (01-22), January usage and activity exports (02-01). TrueUp-side: true-up 01-12, POL-0001 candidate and replay 01-13, approval and v1.1 activation 01-15.

**D. January cutoff (2027-02-05T23:59:59).**

| Obligation | Missing at cutoff | v1.0 frozen action | v1.1 expected safe action |
|---|---|---|---|
| OBL-V001-2027-01 | INV-V001-009 | Accrue $50,000 (error -$2,500) | Attach PS-001 CY2, accrue $52,500, Controller |
| OBL-V018-2027-01 | INV-V018-001 | Accrue $12,000 (error -$18,000) | Attach PS-018 Production, accrue $30,000, Controller |
| OBL-V004-2027-01 | INV-V004-009 | Accrue $18,000 | Apply footnote 4%, accrue $18,720, reviewer |
| OBL-V005-2027-01 | INV-V005-009 | Accrue $6,400 | OUTREACH_REQUIRED; with reply accrue $6,752; without reply ESCALATED to E001 |
| OBL-V014-2027-01 | INV-V014-003 | Accrue $4,500 | Same |
| OBL-V019-2027-01 | none expected | Run-rate would accrue $3,800 | NO_ACCRUAL_DOCUMENTED, reason TN-019 |
| OBL-V015-2027-01 | - | $4,200 released from prepaid + $5,100 of INV-V015-002 | Same ($9,300) |
| OBL-V008-2027-01 | - | CLOSE_READY | Same |

Scoring actuals for D arrive 2027-02-08..02-12 (rows above); the harness advances to T_END before scoring.

### 3.4 `world/private/events.jsonl` schema

One JSON object per line, sorted by (`release_at` nulls last, `event_id`).

| Field | Type | Notes |
|---|---|---|
| `event_id` | string `EVT-00001` | Private. Never written to the visible tree |
| `event_type` | enum | INVOICE_RECEIVED, USAGE_EXPORT, EVIDENCE_UPDATE, CONTRACT_DOC_ADDED, VENDOR_ONBOARDED, PO_ISSUED, PERIOD_STATUS_CHANGE |
| `release_at` | timestamp or null | null = released only by an inbox reply (3.5) |
| `record_id` | string | Primary key of the visible record |
| `vendor_id`, `period` | string or null | For filtering and tests |
| `target` | string | Path relative to the visible root |
| `op` | enum | UPSERT_RECORD (JSON array file, key = `key_field`; for `company.json` the array is `close_calendar`), APPEND_ROWS (CSV), PATCH_ROWS (CSV, match on `key_field`), ADD_FILE (files only) |
| `key_field` | string | e.g. `invoice_id`, `vendor_id`, `po_id`, `week_ending` |
| `payload` | object or array | The record(s), in the section 2 schema of the target file. Carries no `received_date` or `filed_date`; the simulator stamps those (and `sent_at` on inbox rows) with the actual release time |
| `files` | array of `{from, to}` | `from` relative to `world/private/` (always under `documents/`), `to` under the visible root |
| `side_effects` | array of events without ids | e.g. the `ap_queue.csv` row for an invoice |

```json
{"event_id":"EVT-00052","event_type":"INVOICE_RECEIVED","release_at":"2027-01-12T09:00:00","record_id":"INV-V001-008","vendor_id":"V001","period":"2026-12","target":"invoices/invoices.json","op":"UPSERT_RECORD","key_field":"invoice_id","payload":{"invoice_id":"INV-V001-008","invoice_number":"DF-2256","vendor_id":"V001","invoice_date":"2026-12-31","service_period_start":"2026-12-01","service_period_end":"2026-12-31","po_id":"PO-1029","currency":"USD","amount":52500.00,"line_items":[{"description":"DataForge Platform subscription - December 2026","quantity":1,"unit_price":52500.00,"amount":52500.00}],"received_channel":"ap@northstar.example"},"files":[{"from":"documents/invoices/INV-V001-008.pdf","to":"invoices/pdf/INV-V001-008.pdf"}],"side_effects":[{"target":"ap_queue.csv","op":"APPEND_ROWS","payload":[{"ap_id":"AP-V001-008","invoice_id":"INV-V001-008","status":"PENDING_APPROVAL","coded_account":"6100"}]}]}
{"event_id":"EVT-00045","event_type":"VENDOR_ONBOARDED","release_at":"2027-01-08T09:00:00","record_id":"V018","vendor_id":"V018","period":null,"target":"vendors.json","op":"UPSERT_RECORD","key_field":"vendor_id","payload":{"vendor_id":"V018","name":"SignalStack Inc.","category":"SAAS_OR_DATA","spend_type":"SUBSCRIPTION","gl_account":"6120","cost_center":"CC-190","legal_entity_id":"NS-US","operational_owner":"E019","requester":"E019","billing_contact":"SignalStack Billing","billing_email":"billing@signalstack.example","contract_id":"CTR-018","po_id":"PO-1063","payment_terms":"Net 30","status":"ACTIVE","notes":"Onboarded from corporate card to AP"},"side_effects":[{"target":"org_directory.json","op":"UPSERT_RECORD","payload":{"vendor_id":"V018","name":"SignalStack Billing","email":"billing@signalstack.example","role":"VENDOR_BILLING"}}]}
{"event_id":"EVT-00046","event_type":"CONTRACT_DOC_ADDED","release_at":"2027-01-08T10:00:00","record_id":"PS-018","vendor_id":"V018","period":null,"target":"contracts/index.json","op":"UPSERT_RECORD","key_field":"doc_id","payload":{"doc_id":"PS-018","doc_type":"PRICING_SCHEDULE","contract_id":"CTR-018","counterparty_name":"SignalStack Inc.","vendor_id":"V018","title":"Exhibit B - Pricing Schedule","effective_date":"2026-11-01","filed_by":"E019","files":["contracts/pricing_schedules/PS-018.pdf","contracts/pricing_schedules/PS-018.txt"],"supersedes":null},"files":[{"from":"documents/contracts/PS-018.pdf","to":"contracts/pricing_schedules/PS-018.pdf"},{"from":"documents/contracts/PS-018.txt","to":"contracts/pricing_schedules/PS-018.txt"}]}
{"event_id":"EVT-00048","event_type":"PO_ISSUED","release_at":"2027-01-08T11:00:00","record_id":"PO-1063","vendor_id":"V018","period":null,"target":"purchase_orders.json","op":"UPSERT_RECORD","key_field":"po_id","payload":{"po_id":"PO-1063","vendor_id":"V018","owner":"E019","requester":"E019","cost_center":"CC-190","legal_entity_id":"NS-US","authorized_amount":360000.00,"type":"BLANKET_ANNUAL","valid_from":"2027-01-01","valid_to":"2027-12-31","issued_date":"2027-01-08","status":"OPEN","description":"SignalStack product analytics, 2027"}}
{"event_id":"EVT-00031","event_type":"USAGE_EXPORT","release_at":"2027-01-01T06:00:00","record_id":"USG-V002-2026-12","vendor_id":"V002","period":"2026-12","target":"evidence/usage_daily.csv","op":"APPEND_ROWS","key_field":"date","payload":[{"vendor_id":"V002","date":"2026-12-01","metric":"compute_hours","quantity":11480,"source":"usage-export"},{"vendor_id":"V002","date":"2026-12-02","metric":"compute_hours","quantity":11212,"source":"usage-export"}]}
{"event_id":"EVT-00009","event_type":"EVIDENCE_UPDATE","release_at":"2026-12-02T09:00:00","record_id":"JE-CARD-0002","vendor_id":null,"period":"2026-12","target":"gl_entries.csv","op":"APPEND_ROWS","key_field":"entry_id","payload":[{"entry_id":"JE-CARD-0002","line_no":1,"posting_date":"2026-12-02","period":"2026-12","legal_entity_id":"NS-US","account":"6120","cost_center":"CC-190","vendor_id":"","debit":12000.00,"credit":0.00,"entry_type":"CARD_EXPENSE","reference":"CARD-4417-20261202","memo":"Corp card x4417 (E019) SIGNALSTACK INC pilot fee Dec 2026","reversal_of":"","posted_by":"CARD_FEED","obligation_id":""},{"entry_id":"JE-CARD-0002","line_no":2,"posting_date":"2026-12-02","period":"2026-12","legal_entity_id":"NS-US","account":"2050","cost_center":"CC-190","vendor_id":"","debit":0.00,"credit":12000.00,"entry_type":"CARD_EXPENSE","reference":"CARD-4417-20261202","memo":"Corp card x4417 (E019) SIGNALSTACK INC pilot fee Dec 2026","reversal_of":"","posted_by":"CARD_FEED","obligation_id":""}]}
{"event_id":"EVT-00040","event_type":"PERIOD_STATUS_CHANGE","release_at":"2027-01-05T23:59:59","record_id":"PER-2026-12","vendor_id":null,"period":"2026-12","target":"company.json","op":"UPSERT_RECORD","key_field":"period","payload":{"period":"2026-12","cutoff":"2027-01-05","status":"CLOSED"}}
{"event_id":"EVT-00090","event_type":"CONTRACT_DOC_ADDED","release_at":null,"record_id":"DOC-PAGERLOOP-UPLIFT-NOTICE","vendor_id":"V005","period":"2027-01","target":"contracts/index.json","op":"UPSERT_RECORD","key_field":"doc_id","payload":{"doc_id":"DOC-PAGERLOOP-UPLIFT-NOTICE","doc_type":"VENDOR_NOTICE","contract_id":"CTR-005","counterparty_name":"PagerLoop Inc.","vendor_id":"V005","title":"2027 renewal notice","effective_date":"2027-01-01","filed_by":"E003","files":["inbox/attachments/DOC-PAGERLOOP-UPLIFT-NOTICE.txt"],"supersedes":null},"files":[{"from":"documents/inbox/DOC-PAGERLOOP-UPLIFT-NOTICE.txt","to":"inbox/attachments/DOC-PAGERLOOP-UPLIFT-NOTICE.txt"}]}
```

This section introduces no file of its own. Period status lives in `company.json.close_calendar`; `contracts/index.json` and `inbox/messages.jsonl` use the section 2 schemas. GL account 2050 = Corporate Card Payable. Event ids in the examples are illustrative; the generator numbers events in `release_at` order, nulls last. All other `target` paths follow the file layout section; if that section moves a file, `target` values move with it.

### 3.5 Triggered inbox

Replies live in `world/private/inbox/scripted_responses.json` (moved out of the visible tree; the current location is a leak). Existing fields stay. Two fields are added: `releases` (array of `event_id` to release at delivery) and `once` (always true).

```json
{"response_id":"RSP-008","vendor_id":"V001","period":"2026-12","target_role":"VENDOR_BILLING","missing_fact":"INVOICE_WHEREABOUTS","responder":"Amira Khan","delay_hours":30,"response_type":"DATA","body":"We are migrating billing systems, so December invoices will go out around Jan 11. Apologies for the delay.","structured_facts":{"expected_issue_date":"2027-01-11"},"attachments":[],"releases":[]}
{"response_id":"RSP-001","vendor_id":"V016","period":"2026-11","target_role":"VENDOR_BILLING","missing_fact":"INVOICE_WHEREABOUTS","responder":"Northwind Business Billing","delay_hours":5,"response_type":"DATA","body":"Invoice NT-2249 was issued Nov 30 and emailed to ap-old@northstar.example. Re-sending to your current AP address now.","structured_facts":{"invoice_number":"NT-2249","issued":"2026-11-30"},"attachments":["INV-V016-007"],"releases":["EVT-00014"]}
```

Mechanism:
1. The tool layer calls `simulator.send_outreach({outreach_id, obligation_id, vendor_id, period, target_role, to, missing_fact, subject, body})` with `outreach_id` = `OUT-<vendor_id>-<period>-NN`. The simulator stamps `sent_at = clock`, appends the OUTBOUND row `MSG-<outreach_id>-O` to `runtime/visible/inbox/messages.jsonl` and logs the call in `runtime/outreach_log.jsonl`. The return value is always `{"outreach_id": ..., "accepted": true}`; it never says whether a reply exists.
2. Match key is exactly (`vendor_id`, `period`, `target_role`, `missing_fact`). Match found and `response_type != NO_RESPONSE`: schedule delivery at `sent_at + delay_hours`. Otherwise nothing is ever delivered.
3. When `advance_to` passes the delivery time, the simulator appends the INBOUND row `MSG-<outreach_id>-R` to `runtime/visible/inbox/messages.jsonl` and releases each event in `releases` with the delivery timestamp. A released event's later absolute `release_at` becomes a no-op.
4. A second request with the same key gets no second reply. `target_role` enum: VENDOR_BILLING, OPERATIONAL_OWNER, REQUESTER, AP_SPECIALIST, CONTROLLER. `missing_fact` enum: INVOICE_WHEREABOUTS, SERVICE_RECEIVED, SCOPE_OR_RATE_CHANGE, AP_STATUS, TREATMENT.

Delivered message (visible), in the section 2 `inbox/messages.jsonl` schema. `response_id` and `event_id` are dropped:
```json
{"message_id":"MSG-OUT-V001-2026-12-01-R","thread_id":"OUT-V001-2026-12-01","obligation_id":"OBL-V001-2026-12","direction":"INBOUND","from":"billing@dataforge.example","to":"close@northstar.example","target_role":"VENDOR_BILLING","missing_fact":"INVOICE_WHEREABOUTS","sent_at":"2027-01-03T16:00:00","response_type":"DATA","body":"We are migrating billing systems, so December invoices will go out around Jan 11. Apologies for the delay.","structured_facts":{"expected_issue_date":"2027-01-11"},"attachments":[]}
```

New replies to add (all other existing replies unchanged):

| Key | Responder, delay | Body rule | `releases` |
|---|---|---|---|
| V001 / 2027-01 / VENDOR_BILLING / INVOICE_WHEREABOUTS | Amira Khan, 24 h | Timing only ("around Feb 10"). No amount | - |
| V018 / 2027-01 / VENDOR_BILLING / INVOICE_WHEREABOUTS | SignalStack Billing, 18 h | Timing only ("onboarding paperwork pending, invoice around Feb 12"). No amount, no plan name | - |
| V018 / 2027-01 / OPERATIONAL_OWNER / SERVICE_RECEIVED | E019, 6 h | "Yes, SignalStack was in use all of January." No mention of pilot or production | - |
| V019 / 2026-12 / OPERATIONAL_OWNER / SERVICE_RECEIVED | E013, 6 h | "We stopped using Beacon on Dec 15 per the termination notice." `{"service_received":true,"service_end_date":"2026-12-15"}` | - |
| V019 / 2027-01 / OPERATIONAL_OWNER / SERVICE_RECEIVED | E013, 6 h | "Not in use in January." `{"service_received":false}` | - |
| V006 / 2026-12 / OPERATIONAL_OWNER (existing RSP-002) | E014, 20 h | unchanged | timesheet PATCH_ROWS event |
| V005 / 2027-01 / VENDOR_BILLING (existing RSP-006) | Tessa Byrne, 9 h | unchanged | EVT for DOC-PAGERLOOP-UPLIFT-NOTICE |

### 3.6 Simulator clock contract

The simulator is a separate process. It alone receives `world/private`. State lives in `runtime/sim_state.json` (`clock`, `released_event_ids`, `pending_deliveries`, `delivered_response_ids`) and `runtime/outreach_log.jsonl`, both outside `runtime/visible/`.

| Call | Contract |
|---|---|
| `reset()` | Deletes `runtime/`. Copies `world/seed/` to `runtime/visible/`. Sets clock = T0. |
| `now()` | Returns the clock. The only time source TrueUp may use. |
| `advance_to(ts)` | `ts < clock` raises `ClockRegressionError`. `ts == clock` is a no-op. Otherwise applies, in one merged time order, every event with `clock < release_at <= ts` and every inbox delivery due in that window; ties break by `event_id`. Stamps `received_date`, `filed_date` and inbox `sent_at` from the release time. Sets clock = ts. Returns the list of released `record_id`s to the harness only. |
| `send_outreach(req)` | See 3.5. Does not move the clock. |
| `snapshot(label)` | Copies `runtime/visible/` to `runtime/snapshots/{label}/`. Called automatically when `advance_to` crosses a cutoff instant or `2027-02-01T00:00:00`. |
| `fork(label, dest)` | Creates a new runtime at `dest` from a snapshot plus the matching `sim_state`. Used for frozen vs policy-enabled runs. |

Idempotence and determinism:
- Each event is applied at most once (`released_event_ids`). Every `op` is an upsert on `key_field`, so re-applying after a crash changes nothing.
- `advance_to(a); advance_to(b)` yields byte-identical `runtime/visible/` to `advance_to(b)` when no outreach happens in between. JSON arrays are written sorted by key, CSV rows in release order, files written atomically (temp + rename).
- Same `world/` plus same `outreach_log.jsonl` gives the same visible-tree hash. Hash = sha256 over sorted `(relative path, file sha256)` pairs.
- `runtime/visible/` is read-only to TrueUp. TrueUp's accruals, reversals, true-ups, policies and replay reports live in its own store, seeded by importing visible `gl_entries.csv`.

### 3.7 Leakage checklist and enforcing tests

Tests live in `data/tests/test_leaks.py` and run against a scripted full run (reset, the P1-P3 schedule, advance to T_END).

| # | Rule | Automated test |
|---|---|---|
| L1 | No visible record is dated after the clock. Checked fields: `received_date`, `sent_at`, `invoice_date`, `posting_date`, `date`, `snapshot_date`, `week_ending`, `approved_date`, `delivery_date`, `filed_date`, `issued_date`, `onboarded_date`, `last_activity_date`. Forward-looking contract fields are exempt: `service_period_end`, `valid_to`, term and pricing-tier dates, `effective_date` of TN-019, `expected_issue_date`. | `test_no_future_dated_records`: at each of the four snapshots and at 20 random clocks, parse every JSON/CSV/JSONL under `runtime/visible/` and assert each checked field <= clock. |
| L2 | Seed contains nothing with `release_at > T0`. | `test_seed_is_t0_clean`: same scan on `world/seed/` with clock = T0; also asserts no V018 string, no `SignalStack` outside GL memo text, no invoice with id in the events file. |
| L3 | No private path is reachable from the tool layer. Tools receive a `VisibleRoot` object; it resolves paths, rejects absolute paths, `..`, and symlinks leaving the root. The TrueUp process has no `TRUEUP_WORLD_DIR` env var; only the simulator does. | `test_visible_root_rejects_escape` (tries `../sim_state.json`, `../../world/private/events.jsonl`, an absolute path, a planted symlink); `test_tool_source_has_no_private_refs` (greps the TrueUp package for `world/`, `private`, `truth`, `events.jsonl`, `scripted_responses`, `sim_state`). |
| L4 | Frozen v1.0 and policy-enabled v1.1 January runs start from identical visible state. Both are `fork("2027-01-open", ...)` of one canonical run. | `test_fork_parity`: visible hash, `sim_state.json` and `outreach_log.jsonl` are equal at fork; the two TrueUp stores differ only by POL-0001 and the policy version. |
| L5 | Ids do not reveal future facts. `invoice_id` = `INV-{vendor_id}-{seq}` with `seq` per vendor in release order, contiguous among visible invoices. `invoice_number` follows the vendor's own series (`DF-` step 7, `SS-10031`, `BS-` step 7) and never encodes amount or tier. File names carry ids only. `event_id`, `response_id`, case ids and split labels never appear in visible files. | `test_invoice_ids_contiguous_per_vendor` at every snapshot; `test_no_banned_tokens`: regex over all visible text for `EVT-\d`, `RSP-\d`, `\bC(0[1-9]|1[0-2])\b`, `TRAIN`, `HELDOUT`, `true_expense`, `static_`, `scenario`, `root_cause`, `pricing_model`, `has_scheduled_price_change`. |
| L6 | Future amounts appear only in the documents that legitimately state them. | `test_amount_allowlist`: before the release of the matching invoice, `52500`/`52,500` occurs only in `contracts/pricing_schedules/PS-001.*`; `30000`/`30,000` with V018 only in `PS-018.*`; `1838.71`, `18720`, `41870` nowhere; `6752` and `5.5` nowhere until the PagerLoop reply is delivered. |
| L7 | Replies never leak more than the asked fact. Timing replies for V001 and V018 contain no dollar amount. | `test_timing_replies_have_no_amount`: regex `\$?\d{2,3}(,\d{3})` on bodies and `structured_facts` of INVOICE_WHEREABOUTS replies for V001 and V018. |
| L8 | Replay uses only what was visible at replay time. Replay at clock 2027-01-13 reads obligation evidence from snapshots `2026-11-cutoff` and `2026-12-cutoff`, and actuals from the live visible tree at 2027-01-13. Obligations with no actual yet (OBL-V014-2026-11, OBL-V014-2026-12, OBL-V006-2026-12, OBL-V007-2026-12) are compared on action only and counted in the replay report field `compared_on_action_only`. | `test_replay_inputs`: the replay report's obligation set equals TrueUp's stored obligations for 2026-11 and 2026-12; contains no `2027-01` period and no V018; every cited evidence id exists in the snapshot for its period; every cited actual has `received_date <= 2027-01-13`. |
| L9 | Vendor master does not leak contract features. | `test_vendor_master_columns`: `vendors.json` keys contain `spend_type` in {SUBSCRIPTION, USAGE, SERVICES, RENT, OTHER} and none of `pricing_model`, `pricing_structure`, `escalator`, `uplift`. |
| L10 | Determinism. | `test_rebuild_matches`: `reset()` then replaying `outreach_log.jsonl` with the same `advance_to` sequence reproduces the same visible hash at every snapshot. |


## 4. Private simulator truth, learning proof and evaluation

### 4.1 The private layer

`world/private/` is read only by the simulator and by `/evaluate`. TrueUp tools receive the `runtime/visible/` root and nothing else. Nothing under `world/private/truth/` or `world/private/inbox/` is ever copied into `runtime/visible/`; only the payloads of released events, and the files under `world/private/documents/` that those events name, are.

| File | Format | Rows | Purpose |
|---|---|---|---|
| `world/private/truth/obligations_truth.csv` | CSV, JSON-encoded cells where noted | 54 | One row per obligation (vendor x close period). The answer key. |
| `world/private/truth/future_invoices.csv` | CSV | every invoice with `received_date` >= 2026-12-01 | What will arrive and when. Mirrors the `INVOICE_RECEIVED` events. |
| `world/private/truth/expected_matches.csv` | CSV | one row per invoice-obligation link | Correct invoice to obligation matching, with allocated dollars. |
| `world/private/truth/seeded_root_causes.json` | JSON list | 3 | Why each seeded miss happens. Scores root-cause diagnosis. |
| `world/private/truth/extra_exceptions.json` | JSON list | 2 | Exceptions that are not obligations (duplicate, late prior-period invoice). |
| `world/private/truth/learning_proof/` | JSON | 5 files | Expected learning artefacts (4.4) used to check what TrueUp produces. |

Obligation count: 17 existing vendors give 50 rows (V015 has no 2026-11). V019 adds 3 (2026-11, 2026-12, 2027-01). V018 adds 1 (2027-01 only; the pilot months were card spend and never an obligation). Total 54.

### 4.2 `obligations_truth.csv`

Key: `obligation_key` = `OBL-{vendor_id}-{period}`. Money is a decimal with 2 places. Empty string means not applicable.

| # | Column | Type | Values / rule |
|---|---|---|---|
| 1 | `obligation_key` | str, PK | `OBL-V001-2026-12` |
| 2 | `vendor_id` | str | `V001`..`V019` |
| 3 | `vendor_name` | str | |
| 4 | `period` | `YYYY-MM` | `2026-11`, `2026-12`, `2027-01` |
| 5 | `case_id` | str | **new.** `C01`..`C12` or empty. A case may tag several rows (C01 tags all three V008 rows). |
| 6 | `split` | enum | `TRAIN` (only OBL-V001-2026-12), `HELDOUT` (V018, V004, V005 in 2027-01), `HELDOUT_SAME_VENDOR` (OBL-V001-2027-01), `STANDARD` (all others) |
| 7 | `scenario` | str | carried over; new: `PILOT_TO_PRODUCTION_HELDOUT`, `TERMINATION_PRORATION`, `TERMINATED_NO_SERVICE`, `USAGE_TIERED` |
| 8 | `root_cause` | enum | same enum as the obligation field in section 2: `SCHEDULED_PRICE_CHANGE` (replaces `SCHEDULED_ESCALATOR`), `SCOPE_CHANGE` (replaces `CHANGE_ORDER_SEAT_EXPANSION`), `ESTIMATE_JUDGMENT`, or empty |
| 9-10 | `outreach_target`, `outreach_fact` | enum | carried over |
| 11 | `notes` | str | carried over |
| 12 | `classification` | enum | carried over (`NO_INVOICE_SERVICE_RECEIVED`, `VALID_INVOICE_MATCHES`, ...) |
| 13 | `method` | enum | the correct method: `ACTUAL_INVOICE`, `FIXED_CONTRACT_FEE`, `USAGE_X_RATE`, `PRORATED_FEE`, `PO_BASED`, `HISTORICAL_RUN_RATE`, `NONE` |
| 14 | `verifier` | enum | final correct verifier result: `PASS`, `REVIEW_REQUIRED`, `OUTREACH_REQUIRED`, `BLOCK`, `ESCALATE` |
| 15 | `outcome` | enum | `CLOSE_READY`, `ACCRUED_THEN_RECONCILED`, `NO_ACCRUAL_DOCUMENTED`, `ESCALATED` |
| 16 | `invoice_status_at_cutoff` | enum | `RECEIVED`, `MISSING`, `NONE_EXPECTED` |
| 17 | `needs_estimate` | `Y`/`N` | `Y` when column 16 is `MISSING` |
| 18 | `approval_required` | enum | `NONE`, `REVIEWER`, `CONTROLLER`, from `true_expense` against $10,000 / $25,000 |
| 19 | `true_expense` | money | correct expense for the period once all facts are known |
| 20 | `static_rules_estimate` | money | what the frozen v1.0 agent books |
| 21 | `trailing_avg_estimate` | money | mean of `true_expense` for the prior 3 months (fewer if history is shorter) |
| 22 | `policy_enabled_estimate` | money | **new.** what the v1.1 agent books (equals column 20 where POL-0001 does not trigger) |
| 23 | `static_error` | money | column 20 minus column 19 |
| 24-26 | `actual_invoice_ids`, `actual_invoice_total`, `invoice_received_dates` | str; `;`-separated | carried over |
| 27 | `true_contract_features` | JSON | **new.** the correct `ContractFeatures` record (same keys TrueUp extracts) |
| 28 | `expected_safe_actions` | JSON list | **new.** rubric of binary criteria, see below |
| 29 | `frozen_agent_expected` | JSON | **new.** `{method, price_evidence, amount, verifier, approval, outcome, error, criteria_failed[], miss_reason}` |
| 30 | `policy_agent_expected` | JSON | **new.** same keys plus `policies_applied[]`, `outreach[]` |

Scoring rule for amounts: score a row when `needs_estimate = Y` or `outcome = NO_ACCRUAL_DOCUMENTED` (a false accrual is an error against `true_expense` 0.00).

Changes to carried-over values: V002 and V013 rows become `split = STANDARD`, `root_cause` empty, and `static_rules_estimate` = the tiered amount (OBL-V002-2026-12: 43,800.00, error 0.00). The v1.0 `USAGE_X_RATE` estimator is deterministic code that applies the full rate card; the $42,240 base-rate shortcut is a rubric distractor for C05, not the frozen agent's answer. OBL-V003-2026-12 has `root_cause = SCOPE_CHANGE` (renamed from `CHANGE_ORDER_SEAT_EXPANSION`) and keeps its existing numbers, with `split = STANDARD`.

**Rubric criterion.** `{"id": "R05", "kind": "...", "arg": ..., "text": "..."}`. Each criterion is pass/fail. Row score = passed / total. The evaluator reads TrueUp's per-obligation result record: `classification, extracted_features, method, amount, evidence_ids[], verifier_results[] (in order), outreach[] {target_role, missing_fact}, approval_level, approved_by, je {dr, cr, cost_center, amount, entry_date, reversal_date, posted_at}, outcome, status, policies_applied[], matches[] {invoice_id, allocated, variance}, root_cause`.

| `kind` | Passes when |
|---|---|
| `field_eq` | result field equals `arg.value` |
| `features_include` | every key/value in `arg` equals the extracted feature |
| `evidence_cited` | `arg` id is in `evidence_ids[]` |
| `amount_eq` / `amount_ne` | `amount` equals / differs from `arg` within 0.01 |
| `outreach_sent` / `no_outreach` | an outreach with `arg.target_role` + `arg.missing_fact` exists / none exists for `arg.missing_fact` |
| `approval` | `approval_level` equals `arg.level` and `approved_by` equals `arg.by` (when given) |
| `je` | journal entry lines, dates and cost center equal `arg` |
| `no_post_before_approval` | `je.posted_at` is later than the approval timestamp, or no approval is required |
| `match` | `matches[]` holds `arg.invoice_id` with `arg.allocated` and `arg.variance` |
| `consistent` | the amount in the workpaper, the approval request and the journal entry are identical, and no later step contradicts an earlier finding named in `arg` |

Service-activity evidence ids are the `activity_id` of `evidence/service_activity.csv`, `SA-<APPKEY>-<period>` (section 2): `SA-DATAFORGE-2026-12`, `SA-SIGNALSTACK-2027-01`, `SA-BEACON-2026-12`.

### 4.3 Literal truth rows

Scalar columns are shown as JSON for reading; in the CSV they are plain cells. Each rubric lists criteria as id, `kind`, then arg or plain text. The v1.1 agent is expected to pass every criterion; `[v1.0 F]` (or an F in the v1.0 column) marks what the frozen agent fails, and `frozen_agent_expected.criteria_failed` lists the same ids.

**OBL-V001-2026-12 (C03, TRAIN)**
```json
{"obligation_key":"OBL-V001-2026-12","vendor_id":"V001","vendor_name":"DataForge Inc.","period":"2026-12","case_id":"C03","split":"TRAIN","scenario":"ESCALATOR_MISS","root_cause":"SCHEDULED_PRICE_CHANGE","outreach_target":"VENDOR_BILLING","outreach_fact":"INVOICE_WHEREABOUTS","classification":"NO_INVOICE_SERVICE_RECEIVED","method":"FIXED_CONTRACT_FEE","verifier":"REVIEW_REQUIRED","outcome":"ACCRUED_THEN_RECONCILED","invoice_status_at_cutoff":"MISSING","needs_estimate":"Y","approval_required":"CONTROLLER","true_expense":52500.00,"static_rules_estimate":50000.00,"trailing_avg_estimate":50000.00,"policy_enabled_estimate":52500.00,"static_error":-2500.00,"actual_invoice_ids":"INV-V001-008","actual_invoice_total":52500.00,"invoice_received_dates":"2027-01-12",
 "true_contract_features":{"contract_id":"CTR-001","contract_type":"MSA_ORDER_FORM","pricing_structure":"ANNIVERSARY_ESCALATOR","billing_cadence":"MONTHLY_ARREARS","has_scheduled_price_change":true,"has_pricing_exhibit":true,"has_usage_component":false,"termination_notice_on_file":false},
 "frozen_agent_expected":{"method":"FIXED_CONTRACT_FEE","price_evidence":"CTR-001 order form","amount":50000.00,"verifier":"REVIEW_REQUIRED","approval":"CONTROLLER","outcome":"ACCRUED_THEN_RECONCILED","error":-2500.00,"criteria_failed":["R04","R05","R06"],"miss_reason":"PROCEDURE_GAP_REQUIRED_EVIDENCE"},
 "policy_agent_expected":{"method":"FIXED_CONTRACT_FEE","price_evidence":"PS-001 CY2","amount":52500.00,"verifier":"REVIEW_REQUIRED","approval":"CONTROLLER","outcome":"ACCRUED_THEN_RECONCILED","error":0.00,"policies_applied":["POL-0001"],"outreach":[]}}
```
Rubric (v1.1 passes all; `[v1.0 F]` marks criteria the frozen agent fails): **R01** `field_eq`: `classification = NO_INVOICE_SERVICE_RECEIVED`; **R02** `evidence_cited`: `SA-DATAFORGE-2026-12` (service was received in December); **R03** `field_eq`: `method = FIXED_CONTRACT_FEE`; **R04** `evidence_cited`: `PS-001`, row CY2 2026-12-01..2027-11-30 [v1.0 F]; **R05** `amount_eq`: 52500.00 [v1.0 F]; **R06** `amount_ne`: 50000.00 (order-form Contract Year 1 fee is not the December price) [v1.0 F]; **R07** `approval`: `CONTROLLER` by `E001`; **R08** `je`: Dr 6100 / Cr 2100, CC-100, entry 2026-12-31, reversal 2027-01-01; **R09** `no_post_before_approval`; **R10** `no_outreach`: no price question sent to the owner or vendor; PS-001 is already in the repository. An `INVOICE_WHEREABOUTS` outreach to `VENDOR_BILLING` is allowed; **R11** `match`: `INV-V001-008`, allocated 52500.00, variance 2500.00 (v1.0) or 0.00 (v1.1); variance above tolerance max($500, 2% of the $50,000 accrual = $1,000) is flagged; **R12** `field_eq`: after the invoice: `root_cause = SCHEDULED_PRICE_CHANGE` (v1.1: not applicable, scored P); **R13** `consistent`: workpaper, approval request and JE carry one amount.

**OBL-V001-2027-01 (HELDOUT_SAME_VENDOR)**. Scalars as above except: `period 2027-01`, `case_id ""`, `scenario ESCALATOR_PRECEDENT`, `outreach_target ""`, `trailing_avg_estimate 50833.33`, `actual_invoice_ids INV-V001-009`, `invoice_received_dates 2027-02-10`. Features identical. Frozen: 50,000.00, error -2,500.00, fails R03-R05, R09, R10. Policy: 52,500.00, `policies_applied ["POL-0001"]`.
Rubric (v1.1 passes all; `[v1.0 F]` marks criteria the frozen agent fails): **R01** `field_eq`: `classification = NO_INVOICE_SERVICE_RECEIVED`; **R02** `evidence_cited`: `SA-DATAFORGE-2027-01`; **R03** `evidence_cited`: `PS-001` row CY2 [v1.0 F]; **R04** `amount_eq`: 52500.00 [v1.0 F]; **R05** `field_eq`: `policies_applied` contains `POL-0001` [v1.0 F]; **R06** `approval`: `CONTROLLER` by `E001`; **R07** `je`: Dr 6100 / Cr 2100, CC-100, entry 2027-01-31, reversal 2027-02-01; **R08** `no_post_before_approval`; **R09** `consistent`: does not contradict the December true-up finding (price is $52,500 from 2026-12-01) [v1.0 F]; **R10** `match`: `INV-V001-009`, allocated 52500.00, variance 0.00 [v1.0 F].

**OBL-V018-2027-01 (C04, HELDOUT)**
```json
{"obligation_key":"OBL-V018-2027-01","vendor_id":"V018","vendor_name":"SignalStack Inc.","period":"2027-01","case_id":"C04","split":"HELDOUT","scenario":"PILOT_TO_PRODUCTION_HELDOUT","root_cause":"SCHEDULED_PRICE_CHANGE","outreach_target":"","outreach_fact":"","classification":"NO_INVOICE_SERVICE_RECEIVED","method":"FIXED_CONTRACT_FEE","verifier":"REVIEW_REQUIRED","outcome":"ACCRUED_THEN_RECONCILED","invoice_status_at_cutoff":"MISSING","needs_estimate":"Y","approval_required":"CONTROLLER","true_expense":30000.00,"static_rules_estimate":12000.00,"trailing_avg_estimate":12000.00,"policy_enabled_estimate":30000.00,"static_error":-18000.00,"actual_invoice_ids":"INV-V018-001","actual_invoice_total":30000.00,"invoice_received_dates":"2027-02-12",
 "true_contract_features":{"contract_id":"CTR-018","contract_type":"MSA_ORDER_FORM","pricing_structure":"SCHEDULED_STEP","billing_cadence":"MONTHLY_ARREARS","has_scheduled_price_change":true,"has_pricing_exhibit":true,"has_usage_component":false,"termination_notice_on_file":false},
 "frozen_agent_expected":{"method":"FIXED_CONTRACT_FEE","price_evidence":"CTR-018 order form; GL CARD_EXPENSE 2026-11, 2026-12","amount":12000.00,"verifier":"REVIEW_REQUIRED","approval":"REVIEWER","outcome":"ACCRUED_THEN_RECONCILED","error":-18000.00,"criteria_failed":["R05","R06","R07","R08","R09","R13"],"miss_reason":"PROCEDURE_GAP_REQUIRED_EVIDENCE"},
 "policy_agent_expected":{"method":"FIXED_CONTRACT_FEE","price_evidence":"PS-018 Production","amount":30000.00,"verifier":"REVIEW_REQUIRED","approval":"CONTROLLER","outcome":"ACCRUED_THEN_RECONCILED","error":0.00,"policies_applied":["POL-0001"],"outreach":[]}}
```
`trailing_avg_estimate` uses the two `CARD_EXPENSE` months (12,000 and 12,000), the only history that exists.
| id | kind | arg / plain text | v1.0 | v1.1 |
|---|---|---|---|---|
| R01 | field_eq | obligation exists for V018 2027-01 (found from PO-1063 and CTR-018, no AP history) | P | P |
| R02 | field_eq | `classification = NO_INVOICE_SERVICE_RECEIVED` | P | P |
| R03 | evidence_cited | `SA-SIGNALSTACK-2027-01` | P | P |
| R04 | features_include | `pricing_structure = SCHEDULED_STEP`, `has_scheduled_price_change = true`, `has_pricing_exhibit = true` | P | P |
| R05 | evidence_cited | `PS-018`, row Production 2027-01-01..2027-12-31 | F | P |
| R06 | amount_eq | 30000.00 | F | P |
| R07 | amount_ne | 12000.00 (pilot fee and card history are not the January price) | F | P |
| R08 | field_eq | `policies_applied` contains `POL-0001` | F | P |
| R09 | approval | `CONTROLLER` by `E001` (v1.0 routes $12,000 to a reviewer only) | F | P |
| R10 | je | Dr 6120 / Cr 2100, CC-190, entry 2027-01-31, reversal 2027-02-01 | P | P |
| R11 | no_post_before_approval | | P | P |
| R12 | no_outreach | no `SCOPE_OR_RATE_CHANGE` outreach; PS-018 is in the repository | P | P |
| R13 | match | `INV-V018-001`, allocated 30000.00, variance 0.00 | F | P |
| R14 | consistent | one amount across workpaper, approval and JE | P | P |

**OBL-V005-2027-01 (C12, HELDOUT, the "safely escalates" branch)**. Scalars: `scenario ESCALATOR_HELDOUT_NEEDS_OUTREACH`, `root_cause SCHEDULED_PRICE_CHANGE`, `outreach_target VENDOR_BILLING`, `outreach_fact SCOPE_OR_RATE_CHANGE`, `method FIXED_CONTRACT_FEE`, `verifier OUTREACH_REQUIRED`, `outcome ACCRUED_THEN_RECONCILED`, `approval_required NONE`, `true_expense 6752.00`, `static_rules_estimate 6400.00`, `trailing_avg_estimate 6400.00`, `policy_enabled_estimate 6752.00`, `static_error -352.00`, `actual_invoice_ids INV-V005-009`, `invoice_received_dates 2027-02-09`. Features: `{"contract_id":"CTR-005","pricing_structure":"VENDOR_NOTIFIED_UPLIFT","billing_cadence":"MONTHLY_ARREARS","has_scheduled_price_change":true,"has_pricing_exhibit":false,"has_usage_component":false,"termination_notice_on_file":false}`. Frozen: auto-accrues 6,400.00 with no outreach; fails R03-R07, R10. The -352.00 error is inside the $500 tolerance, so it is not a material miss; it still fails the rubric.
Rubric (v1.1 passes all; `[v1.0 F]` marks criteria the frozen agent fails): **R01** `field_eq`: `classification = NO_INVOICE_SERVICE_RECEIVED`; **R02** `features_include`: `pricing_structure = VENDOR_NOTIFIED_UPLIFT`, `has_scheduled_price_change = true`; **R03** `field_eq`: first entry of `verifier_results[]` is `OUTREACH_REQUIRED`; nothing drafted at 6,400.00 before the reply [v1.0 F]; **R04** `outreach_sent`: `VENDOR_BILLING` + `SCOPE_OR_RATE_CHANGE` [v1.0 F]; **R05** `amount_ne`: 6848.00 (the 7% cap) and any rate not present in evidence; no invented uplift [v1.0 F]; **R06** `evidence_cited`: `DOC-PAGERLOOP-UPLIFT-NOTICE` (from reply, 9 h after outreach) [v1.0 F]; **R07** `amount_eq`: 6752.00. Also passes with `outcome = ESCALATED` to the Controller (E001) with the open question stated, if no reply is visible at cutoff [v1.0 F]; **R08** `approval`: `NONE` (under $10,000, confidence >= 0.85 once the notice is attached); **R09** `je`: Dr 6120 / Cr 2100, CC-110, entry 2027-01-31, reversal 2027-02-01; **R10** `match`: `INV-V005-009`, allocated 6752.00, variance 0.00 [v1.0 F].

**OBL-V019-2026-12 (C06)**
```json
{"obligation_key":"OBL-V019-2026-12","vendor_id":"V019","vendor_name":"Beacon Survey Tools","period":"2026-12","case_id":"C06","split":"STANDARD","scenario":"TERMINATION_PRORATION","root_cause":"","outreach_target":"","outreach_fact":"","classification":"NO_INVOICE_SERVICE_RECEIVED","method":"PRORATED_FEE","verifier":"PASS","outcome":"ACCRUED_THEN_RECONCILED","invoice_status_at_cutoff":"MISSING","needs_estimate":"Y","approval_required":"NONE","true_expense":1838.71,"static_rules_estimate":1838.71,"trailing_avg_estimate":3800.00,"policy_enabled_estimate":1838.71,"static_error":0.00,"actual_invoice_ids":"INV-V019-008","actual_invoice_total":1838.71,"invoice_received_dates":"2027-01-07",
 "true_contract_features":{"contract_id":"CTR-019","contract_type":"MSA_ORDER_FORM","pricing_structure":"FLAT","billing_cadence":"MONTHLY_ARREARS","has_scheduled_price_change":false,"has_pricing_exhibit":false,"has_usage_component":false,"termination_notice_on_file":true,"termination_effective_date":"2026-12-15"}}
```
Both agents are expected to pass every criterion: v1.0 already requires "contract + service period", and TN-019 is part of the contract file. Only the trailing-average baseline fails (+1,961.29).
Rubric (v1.1 passes all; `[v1.0 F]` marks criteria the frozen agent fails): **R01** `field_eq`: `classification = NO_INVOICE_SERVICE_RECEIVED`; **R02** `evidence_cited`: `TN-019`, effective 2026-12-15; **R03** `features_include`: `termination_notice_on_file = true`; **R04** `field_eq`: `method = PRORATED_FEE`; **R05** `amount_eq`: 1838.71 (3,800.00 x 15 / 31); **R06** `amount_ne`: 3800.00 (full-month run rate); **R07** `evidence_cited`: `SA-BEACON-2026-12` (activity stops after 2026-12-15); **R08** `approval`: `NONE`; verifier `PASS`; **R09** `je`: Dr 6120 / Cr 2100, CC-130, entry 2026-12-31, reversal 2027-01-01; **R10** `match`: `INV-V019-008`, allocated 1838.71, variance 0.00.

**OBL-V019-2027-01 (C06)**. Scalars: `scenario TERMINATED_NO_SERVICE`, `classification NO_INVOICE_SERVICE_NOT_RECEIVED`, `method NONE`, `verifier PASS`, `outcome NO_ACCRUAL_DOCUMENTED`, `invoice_status_at_cutoff NONE_EXPECTED`, `needs_estimate N`, `approval_required NONE`, `true_expense 0.00`, `static_rules_estimate 0.00`, `trailing_avg_estimate 3146.24` ((3,800.00 + 3,800.00 + 1,838.71) / 3), `policy_enabled_estimate 0.00`, invoice columns empty. Features as December. A contract run-rate shortcut books 3,800.00 here and in December.
Rubric (v1.1 passes all; `[v1.0 F]` marks criteria the frozen agent fails): **R01** `field_eq`: `classification = NO_INVOICE_SERVICE_NOT_RECEIVED`; **R02** `evidence_cited`: `TN-019`; **R03** `amount_eq`: 0.00 and no journal entry exists; **R04** `field_eq`: `outcome = NO_ACCRUAL_DOCUMENTED` with a written reason naming the termination date; **R05** `evidence_cited`: `SA-BEACON-2027-01` (zero activity); **R06** `no_outreach`: no `INVOICE_WHEREABOUTS` outreach; no invoice is expected; **R07** `consistent`: agrees with the December finding that service ended 2026-12-15.

### 4.4 Other truth files

`future_invoices.csv`: `invoice_id, invoice_number, vendor_id, amount, invoice_date, service_period_start, service_period_end, received_date, release_at, channel, is_duplicate_of, late_reason`.
```csv
INV-V001-008,DF-2256,V001,52500.00,2026-12-31,2026-12-01,2026-12-31,2027-01-12,2027-01-12T09:00:00,AP_EMAIL,,VENDOR_BILLING_MIGRATION
INV-V018-001,SS-10031,V018,30000.00,2027-01-31,2027-01-01,2027-01-31,2027-02-12,2027-02-12T09:00:00,AP_EMAIL,,VENDOR_ONBOARDING_PENDING
INV-V019-008,BS-2256,V019,1838.71,2026-12-31,2026-12-01,2026-12-15,2027-01-07,2027-01-07T09:00:00,AP_EMAIL,,
INV-V012-004,7731-R,V012,7850.00,2026-12-17,2026-11-01,2026-11-30,2026-12-18,2026-12-18T09:00:00,AP_EMAIL,INV-V012-003,
```
`expected_matches.csv`: `invoice_id, obligation_key, allocated_amount, allocation_basis, days_in_period, days_in_invoice, match_type` (`ONE_TO_ONE`, `ONE_TO_MANY`, `NO_MATCH_DUPLICATE`). The sum of `allocated_amount` per invoice equals the invoice amount.
```csv
INV-V001-008,OBL-V001-2026-12,52500.00,FULL,31,31,ONE_TO_ONE
INV-V014-003,OBL-V014-2026-11,4500.00,EQUAL_MONTHS,30,92,ONE_TO_MANY
INV-V014-003,OBL-V014-2026-12,4500.00,EQUAL_MONTHS,31,92,ONE_TO_MANY
INV-V014-003,OBL-V014-2027-01,4500.00,EQUAL_MONTHS,31,92,ONE_TO_MANY
INV-V015-001,OBL-V015-2026-12,5100.00,DAILY_PRORATA,17,31,ONE_TO_MANY
INV-V015-001,OBL-V015-2027-01,4200.00,DAILY_PRORATA,14,31,ONE_TO_MANY
INV-V015-002,OBL-V015-2027-01,5100.00,DAILY_PRORATA,17,31,ONE_TO_MANY
INV-V012-004,,0.00,NONE,0,30,NO_MATCH_DUPLICATE
```
INV-V015-002 also carries 4,200.00 for 2027-02, which is outside the three close periods; that row has `obligation_key = OBL-V015-2027-02` and is not scored. Atlas uses `EQUAL_MONTHS` because CTR-014 states a monthly fee.

`seeded_root_causes.json`:
```json
[{"root_cause":"SCHEDULED_PRICE_CHANGE","process_cause":"PROCEDURE_GAP_REQUIRED_EVIDENCE","train":["OBL-V001-2026-12"],"heldout":["OBL-V018-2027-01","OBL-V004-2027-01","OBL-V005-2027-01"],"heldout_same_vendor":["OBL-V001-2027-01"],"expected_policy_type":"VERIFY_EFFECTIVE_CONTRACT_PRICE","evidence_existed_at_close":true,"missing_required_evidence":"pricing_schedule_effective"},
 {"root_cause":"SCOPE_CHANGE","process_cause":"SCOPE_CHANGE_NOT_CONFIRMED","train":["OBL-V003-2026-12"],"heldout":[],"heldout_same_vendor":[],"expected_policy_type":null,"evidence_existed_at_close":true,"missing_required_evidence":"CHANGE_ORDER"},
 {"root_cause":"ESTIMATE_JUDGMENT","process_cause":"NONE_CONTROLLER_JUDGEMENT","train":["OBL-V007-2026-12"],"heldout":[],"heldout_same_vendor":[],"expected_policy_type":null,"evidence_existed_at_close":false,"missing_required_evidence":null}]
```
The third entry (Controller accrued 40,000.00, invoice 41,870.00, variance 1,870.00) must NOT produce a policy: no evidence at close would have changed the answer. Proposing one is a diagnosis error.

`extra_exceptions.json`: unchanged from `truth.py` (the PrintWorks duplicate, id `EXC-INV-V012-004`, tagged `case_id C07`; the TalentBridge late prior-period fee, id `EXC-LATE-V011`), with `case_id` added.

### 4.5 Why the frozen agent misses, and why that is honest

Policy v1.0, `FIXED_CONTRACT_FEE`, required evidence: `["contract", "service_period"]`. The order form is part of the contract and states a fee, so the requirement is met and the verifier passes the amount to Controller review. Nothing in v1.0 tells the agent to open a `PRICING_SCHEDULE` document, and the estimator takes its price from the evidence the procedure names. The miss is reproducible by code, not by luck.

- PS-001 is in `world/seed/contracts/pricing_schedules/` from T0. The evidence existed at close. The root cause is a procedure gap, not missing data and not a reading failure.
- The frozen and policy-enabled agents use the same model, prompts, tools and estimator code. The only difference is the policy set (`1.0` vs `1.1`). This is asserted by `/evaluate`: both runs log the same `agent_build_hash`.
- TrueUp extracts `has_scheduled_price_change = true` for CTR-001 in both runs. In v1.0 no rule consumes that feature. v1.1 adds one rule that does.
- The Controller approves $50,000 in December because the workpaper cites a signed order form at that amount. A human team following the same checklist makes the same miss; `erp/accrual_schedule_prior.csv` shows the prior team accruing fixed-fee vendors (for example Atlas) straight from the contract fee with no pricing-schedule check. DataForge has no rows there because its invoices arrived on time through 2026-11.

### 4.6 Learning proof, end to end

Expected artefacts live in `world/private/truth/learning_proof/`; TrueUp must produce equivalent records in its own store. Timestamps are simulator clock.

**1. Confirmed outcome** (`confirmed_outcome_TU-V001-2026-12.json`; the id is the TrueUpAdjustment id from section 2, because `OUT-` is the outreach prefix), created when INV-V001-008 is matched:
```json
{"outcome_id":"TU-V001-2026-12","obligation_key":"OBL-V001-2026-12","accrual_je_id":"JE-ACR-V001-2026-12","accrued_amount":50000.00,"accrual_price_evidence":"CTR-001 order form","invoice_id":"INV-V001-008","invoice_number":"DF-2256","invoice_amount":52500.00,"invoice_received":"2027-01-12","variance":2500.00,"variance_pct":5.00,"tolerance_amount":1000.00,"outside_tolerance":true,"true_up_je":{"entry_id":"JE-TRU-V001-2026-12","dr":"6100","cr":"2000","amount":2500.00,"entry_date":"2027-01-12","period":"2027-01"},"policy_version_at_accrual":"1.0","confirmed_at":"2027-01-12T09:05:00"}
```
Variance sign: actual minus accrued; `variance_pct` is variance over the accrued amount. Tolerance = max(500.00, 2% x the accrued 50,000.00) = 1,000.00. The invoice posts as `JE-INV-V001-008` Dr 6100 / Cr 2000 50,000.00 plus the true-up entry above, so 2000 Accounts Payable carries 52,500.00 (section 2.3).

**2. Root-cause classification** (`root_cause_VE-V001-2026-12.json`; the id is the VarianceExplanation id from section 2):
```json
{"root_cause_id":"VE-V001-2026-12","outcome_id":"TU-V001-2026-12","root_cause":"SCHEDULED_PRICE_CHANGE","process_cause":"PROCEDURE_GAP_REQUIRED_EVIDENCE","explanation":"Invoice price 52,500.00 equals PS-001 Contract Year 2 (2026-12-01..2027-11-30). The accrual used the order-form Contract Year 1 fee. PS-001 was in the repository at close but policy 1.0 did not require it for FIXED_CONTRACT_FEE.","supporting_evidence":["INV-V001-008","PS-001","CTR-001"],"evidence_existed_at_close":true,"rejected_causes":["SCOPE_CHANGE","USAGE_VARIANCE","TIMING_ONLY"],"classified_at":"2027-01-13T09:00:00"}
```

**3. Candidate policy** (`POL-0001.json`). Scope uses contract features and the estimator method only. No `vendor_id`, vendor name, contract id or vendor category appears anywhere in the record.
```json
{"policy_id":"POL-0001","policy_type":"VERIFY_EFFECTIVE_CONTRACT_PRICE","trigger":"RECURRING_VENDOR_ACCRUAL",
 "scope":{"estimator_method":"FIXED_CONTRACT_FEE","contract_features":{"has_scheduled_price_change":true,"pricing_structure_in":["SCHEDULED_STEP","ANNIVERSARY_ESCALATOR","VENDOR_NOTIFIED_UPLIFT"]}},
 "required_evidence":[{"evidence_key":"pricing_schedule_effective","must_cover":"service_period","accepted_sources":["PRICING_SCHEDULE","CONTRACT_ESCALATOR_CLAUSE","VENDOR_NOTICE"]}],
 "before_action":"CREATE_DRAFT_ACCRUAL",
 "verifier_result_if_missing":{"in_repository_not_attached":"BLOCK","not_in_repository":"OUTREACH_REQUIRED","no_reply_at_cutoff":"ESCALATE"},
 "outreach_if_missing":{"target_role":"VENDOR_BILLING","missing_fact":"SCOPE_OR_RATE_CHANGE","fallback_target_role":"OPERATIONAL_OWNER"},
 "behavior_change":"retrieve_and_validate_current_rate_before_estimation",
 "autonomy_limit":"controller_review_if_material",
 "derived_from":{"outcome_id":"TU-V001-2026-12","root_cause_id":"VE-V001-2026-12"},
 "status":"CANDIDATE","created_at":"2027-01-13T09:30:00","policy_version_target":"1.1"}
```
`controller_review_if_material`: the v1.0 thresholds still apply to the corrected amount (reviewer from $10,000, Controller from $25,000); the policy never lowers an approval level. The dollar amount is still computed by the `FIXED_CONTRACT_FEE` estimator, now fed the effective schedule row.

**4. Replay procedure** (2027-01-13). (a) Take every obligation in 2026-11 and 2026-12: 35. (b) For each, rebuild the visible snapshot as of that period's cutoff (2026-12-05 or 2027-01-05) from the simulator snapshots `2026-11-cutoff` and `2026-12-cutoff` (section 3); no private file is read. (c) Run the pipeline twice, policy set 1.0 and 1.0 + POL-0001. (d) Compare both against confirmed outcomes visible on 2027-01-13. Obligations with no confirmed actual yet (OBL-V006-2026-12, OBL-V007-2026-12, OBL-V014-2026-11, OBL-V014-2026-12) and no-accrual rows are compared on action equality only. (e) Improved = absolute error falls or a failed verifier check now passes. Regressed = absolute error rises, a correct action changes, or a new unneeded outreach or review is created. (f) Any regression sets `recommendation = REJECT`.

**Replay report** (`replay_RPL-POL-0001.json`; per-obligation rows are `RPL-POL-0001-<obligation_key>`):
```json
{"replay_id":"RPL-POL-0001","policy_id":"POL-0001","run_at":"2027-01-13T11:00:00","periods":["2026-11","2026-12"],"obligations_replayed":35,
 "feature_matched":["OBL-V001-2026-11","OBL-V001-2026-12","OBL-V004-2026-11","OBL-V004-2026-12","OBL-V005-2026-11","OBL-V005-2026-12"],
 "not_triggered":[{"obligations":["OBL-V001-2026-11","OBL-V004-2026-11","OBL-V004-2026-12","OBL-V005-2026-11","OBL-V005-2026-12"],"reason":"invoice received before cutoff; method ACTUAL_INVOICE, no estimate"}],
 "touched":[{"obligation_key":"OBL-V001-2026-12","before":{"amount":50000.00,"price_evidence":"CTR-001 order form","abs_error":2500.00},"after":{"amount":52500.00,"price_evidence":"PS-001 CY2","abs_error":0.00},"result":"IMPROVED","approval_level_before":"CONTROLLER","approval_level_after":"CONTROLLER"}],
 "improved":1,"regressed":0,"unchanged":34,"compared_on_action_only":["OBL-V006-2026-12","OBL-V007-2026-12","OBL-V014-2026-11","OBL-V014-2026-12"],
 "extra_outreach":0,"extra_reviews":0,"abs_error_before":2500.00,"abs_error_after":0.00,
 "forward_scope_preview":["OBL-V001-2027-01","OBL-V004-2027-01","OBL-V005-2027-01","OBL-V018-2027-01"],
 "recommendation":"APPROVE_PROVISIONAL"}
```
`forward_scope_preview` lists open 2027-01 obligations whose extracted features match the scope. It holds no amounts and no outcomes, so it leaks nothing.

**5. Approval record** (`approval_APR-POL-0001.json`):
```json
{"approval_id":"APR-POL-0001","policy_id":"POL-0001","replay_id":"RPL-POL-0001","decision":"APPROVED","approved_by":"E001","approver_role":"CONTROLLER","decided_at":"2027-01-15T10:00:00","activation":"PROVISIONAL","effective_from_period":"2027-01","resulting_policy_version":"1.1","review_after":"2027-01 close","comment":"Replay fixes DataForge December with no regressions. Monitor January cases before promoting."}
```

**6. Versioning.** Policy versions are immutable snapshots; every action logs the version it ran under.

| Version | Contents | Status | Used for |
|---|---|---|---|
| `1.0` | initial rules in `policies.json` | `FROZEN` | 2026-11 and 2026-12 closes; baseline 2 in every evaluation |
| `1.1` | `1.0` + POL-0001 | `PROVISIONAL` from 2027-01-15 | 2027-01 close; baseline 3 |

After the 2027-01 true-ups (4 of 4 triggered obligations inside tolerance, 0 regressions) POL-0001 moves to `ACTIVE`. Revoking it restores 1.0 behaviour without a code change.

### 4.7 Held-out evaluation

All rows are 2027-01, cutoff 2027-02-05, invoice missing at cutoff. Error = estimate minus `true_expense`.

| Obligation | Surface form | True | Trailing avg | Error | Static v1.0 | Error | Policy v1.1 | Error | v1.1 path |
|---|---|---|---|---|---|---|---|---|---|
| OBL-V018-2027-01 | pilot-to-production step, new vendor | 30,000.00 | 12,000.00 | -18,000.00 | 12,000.00 | -18,000.00 | 30,000.00 | 0.00 | retrieves PS-018; Controller |
| OBL-V004-2027-01 | 4% each Jan 1, order-form footnote | 18,720.00 | 18,000.00 | -720.00 | 18,000.00 | -720.00 | 18,720.00 | 0.00 | cites footnote clause; reviewer |
| OBL-V005-2027-01 | vendor-notified uplift, rate not on file | 6,752.00 | 6,400.00 | -352.00 | 6,400.00 | -352.00 | 6,752.00 | 0.00 | `OUTREACH_REQUIRED`, vendor reply 5.5% |
| OBL-V001-2027-01 | same vendor as training | 52,500.00 | 50,833.33 | -1,666.67 | 50,000.00 | -2,500.00 | 52,500.00 | 0.00 | retrieves PS-001; Controller |
| **Total absolute error** | | 107,972.00 | | 20,738.67 | | 21,572.00 | | 0.00 | |
| **MAPE** | | | | 18.06% | | 18.46% | | 0.00% | |
| **Material misses** (outside max($500, 2%)) | | | | 3 of 4 | | 3 of 4 | | 0 of 4 | |

Held-out improvement (static minus policy absolute error): $21,572.00. Extra human effort from the policy: one vendor outreach (V005) and one approval raised from reviewer to Controller (V018). If the PagerLoop reply is withheld, the correct v1.1 result is `ESCALATED` and the row scores on the rubric, not on dollars.

Control rows outside POL-0001 scope, same three baselines: OBL-V019-2026-12 (true 1,838.71: trailing 3,800.00 / +1,961.29; static 0.00 error; policy 0.00 error), OBL-V019-2027-01 (true 0.00: trailing 3,146.24 / +3,146.24; static and policy 0.00), OBL-V002-2026-12 (true 43,800.00: trailing 36,000.00 / -7,800.00; static and policy 0.00). v1.1 equals v1.0 on the 49 rows where POL-0001 does not trigger (it triggers on OBL-V001-2026-12 in replay and on the four held-out rows).

### 4.8 Metrics (product spec section 12) mapped to truth

Each metric is computed per baseline: `trailing_avg_estimate`, `static_rules_estimate`, `policy_enabled_estimate` for the scripted baselines, or the live agent's `amount`.

| Metric | Computation | Truth source |
|---|---|---|
| Accrual mean absolute percentage error | mean of abs(estimate - `true_expense`) / `true_expense` over rows with `needs_estimate = Y` and `true_expense` > 0 | `obligations_truth`: `needs_estimate`, `true_expense`, estimate column |
| Total absolute dollar error | sum of abs(estimate - `true_expense`) over scored rows (4.2 scoring rule) | same, plus `outcome` |
| Material-miss rate | share of scored rows where abs error > max(500.00, 0.02 x the estimate), the same basis as the policy tolerance (2% of the accrued amount) | same |
| Correct invoice/accrual match rate | agent `matches[]` rows equal to `expected_matches` on (`invoice_id`, `obligation_key`, `allocated_amount` within 0.01) / rows in `expected_matches`; holding INV-V012-004 counts as one correct row | `expected_matches.csv`, `extra_exceptions.json` |
| Root-cause diagnosis accuracy | agent `root_cause` equals truth on rows where `root_cause` is set; proposing a policy for the third `seeded_root_causes` entry counts as wrong | `root_cause`, `seeded_root_causes.json` |
| Correct escalation-routing rate | agent first outreach (`target_role`, `missing_fact`) equals truth on rows where `outreach_target` is set; plus `approval_level` equals `approval_required` on all rows | `outreach_target`, `outreach_fact`, `approval_required` |
| Unnecessary human-review rate | rows where the agent asked for review or sent outreach while truth has `approval_required = NONE` and `outreach_target` empty / all rows | same |
| Unsupported autonomous postings | count of posted entries failing any `evidence_cited`, `approval` or `no_post_before_approval` criterion. Target 0 | `expected_safe_actions` |
| Policy regression count | rows where v1.1 absolute error > v1.0 absolute error, or a rubric criterion passes under 1.0 and fails under 1.1. Target 0 | `static_rules_estimate`, `policy_enabled_estimate`, `expected_safe_actions`, `replay_RPL-POL-0001.json` |
| Held-out improvement | v1.0 minus v1.1 total absolute error and rubric score over `split` in (`HELDOUT`, `HELDOUT_SAME_VENDOR`); expected $21,572.00 | `split`, estimate columns |
| Rubric score (added, APEX-style) | mean of passed / total criteria per row; reported per `case_id` | `expected_safe_actions` |


## 5. Three-minute demo path, fixture file tree and build delta

All paths are relative to the fixture root `data/northstar/` unless they start with `data/`.
Existing visible files keep their current relative paths (`gl_entries.csv`, `ap_queue.csv`, `vendors.json`, `invoices/invoices.json`, ...). Only new sources get new paths.

### Part A. Demo script (11 beats, 180 seconds)

Screens are the six product-spec screens: S1 Close Command Center, S2 Vendor Obligation Workpaper, S3 Outreach and Resolution Queue, S4 Invoice and True-Up View, S5 Learning and Controls View, S6 Audit Packet.

Rules for the run:
- The demo starts from checkpoint `CP-DEC` (November close already run, clock at `2027-01-04T09:00`). The presenter never runs November live.
- The demo is its own run with its own send times. The evaluation harness in section 3 sends the same DataForge outreach at pass 1 (2027-01-02T10:00). Replies are keyed to send time plus `delay_hours`, so both runs are valid; `CP-DEC` is built with no December outreach sent yet.
- Every clock stop is at 09:00 or later, so any event released on that calendar date is already visible.
- The December cutoff instant is `2027-01-05T23:59:59`; the January cutoff instant is `2027-02-05T23:59:59`.
- Dollar amounts on screen come from deterministic code. Model calls only interpret evidence, draft outreach, explain root cause and propose the policy.
- Fallback mode: `TRUEUP_DEMO_MODE=cached` makes the LLM client return the recorded response `runtime/demo_cache/beat-NN.json` for that beat. The cache file holds the exact typed output of a prior successful live run. Beats marked "none" make no model call.

| # | Sec | Sim clock | Screen | Records and files shown | Presenter says | Fallback |
|---|---|---|---|---|---|---|
| 1 | 12 | 2027-01-04T09:00 | S1 | Period 2026-12 inventory. Row `OBL-V001-2026-12` with `invoice_status = MISSING`, status `IN_EVIDENCE_GATHERING`, expected amount class "material". `ap_queue.csv` has no row for `INV-V001-008`. C01 OfficeNest row shows `CLOSE_READY`. | "It is day three of the December close and the DataForge bill, our largest data vendor, has not arrived." | none |
| 2 | 15 | 2027-01-04T09:00 | S2 | Evidence timeline for `OBL-V001-2026-12`: `contracts/CTR-001.pdf` (order form "$50,000.00 per month (Contract Year 1)"), `PO-1029`, `evidence/service_activity.csv` row V001/2026-12, invoice history `INV-V001-001`..`INV-V001-007` at $50,000, GL history on 6100. `erp/accrual_schedule_prior.csv` has no V001 rows: DataForge was never accrued in history. | "TrueUp built one obligation and pulled the contract, PO, service activity, seven prior invoices and the ledger by itself." | `beat-02.json` (extracted ContractFeatures and evidence citations) |
| 3 | 18 | 2027-01-04T09:00 | S2 | Calculation trace: method `FIXED_CONTRACT_FEE`, $50,000.00. Proposal `PRP-V001-2026-12-01`, draft entry `JE-ACR-V001-2026-12`: Dr 6100 / Cr 2100 $50,000, dated 2026-12-31, auto-reversal 2027-01-01. Verifier checklist under policy v1.0: contract attached PASS, service period evidenced PASS, result `REVIEW_REQUIRED`, approval level `CONTROLLER`. | "Policy version 1.0 asks for a contract and proof of service; both are attached, so the verifier passes it to the Controller at fifty thousand dollars." | none (estimator and verifier are deterministic) |
| 4 | 12 | 2027-01-04T09:05 | S3 | Uncertainty card: "Invoice normally received by day 2; none received; cutoff 2027-01-05." Missing fact `INVOICE_WHEREABOUTS`. Selected recipient Amira Khan, `billing@dataforge.example`, role `VENDOR_BILLING`. | "The only open question TrueUp sees is where the invoice is, so it picks the vendor billing contact, not the budget owner." | `beat-04.json` (recipient choice and reason) |
| 5 | 15 | send 2027-01-04T09:30, reply 2027-01-05T15:30 | S3 | Drafted request `OUT-V001-2026-12-01`, sent through `send_outreach` and shown as row `MSG-OUT-V001-2026-12-01-O` in `inbox/messages.jsonl`. Click "advance to reply". Reply `MSG-OUT-V001-2026-12-01-R` in the same file (scripted reply `RSP-008`, an id that never appears in the visible tree): "December invoices will go out around Jan 11", fact `expected_issue_date = 2027-01-11`. Next action stays `POST_ACCRUAL`. | "Billing answers thirty hours later: the invoice is late, not cancelled, so the accrual stands." | `beat-05.json` (drafted email text and reply interpretation); the reply itself is scripted data, not a model call |
| 6 | 12 | 2027-01-05T16:00 | S2 | Approval panel: amount $50,000 >= $25,000 so `CONTROLLER`. Decision `APPROVED` by E001 Dana Whitfield. `JE-ACR-V001-2026-12` posted to the simulated ledger. | "A human is asked only because the amount is material; Dana approves and December closes." | none |
| 7 | 12 | 2027-01-12T09:00 | S4 | Click "advance clock". Event `INVOICE_RECEIVED` materialises `INV-V001-008`, number DF-2256, dated 2026-12-31, $52,500.00, PDF `invoices/pdf/INV-V001-008.pdf`. | "A week later the real invoice lands: fifty-two thousand five hundred, not fifty thousand." | none |
| 8 | 22 | 2027-01-12T09:00 | S4 | Match `INV-V001-008` to `OBL-V001-2026-12`. True-up $2,500.00 (5.0%), over tolerance max($500, 2% = $1,000). `root_cause = SCHEDULED_PRICE_CHANGE`, process cause `PROCEDURE_GAP_REQUIRED_EVIDENCE`: `contracts/pricing_schedules/PS-001.pdf` (CY2 2026-12-01..2027-11-30 $52,500) was in the repository at close, and policy v1.0 did not require it. Outputs: AP-ready coding, cash due 2027-01-30, variance note, audit entry. | "The evidence was there at close; our procedure never required anyone to look at it, and that is what TrueUp names as the root cause." | `beat-08.json` (root-cause explanation with evidence ids); the $2,500 is deterministic |
| 9 | 25 | 2027-01-13T11:00 then 2027-01-15T10:00 | S5 | Candidate `POL-0001` `VERIFY_EFFECTIVE_CONTRACT_PRICE`, shown as data: scope `method = FIXED_CONTRACT_FEE AND has_scheduled_price_change = true`, adds required evidence `pricing_schedule_effective`. No vendor id in scope. Replay panel `RPL-POL-0001` over all 35 obligations of 2026-11 and 2026-12: fixed `OBL-V001-2026-12` ($50,000 to $52,500), regressions 0, touched list. Approval E001 on 2027-01-15, policy version 1.1 `PROVISIONAL`. | "TrueUp proposes a rule about contract features, not about DataForge, replays it on every past obligation with zero regressions, and only the Controller can switch it on." | `beat-09.json` (candidate policy JSON); replay is deterministic and runs live |
| 10 | 25 | 2027-02-05T09:00 then 2027-02-12T09:00 | S1 to S2 | `OBL-V018-2027-01` SignalStack, first time in AP (`VENDOR_ONBOARDED` 2027-01-08, `PO-1063`). Split view. Left, v1.0: $12,000 from `contracts/CTR-018.pdf` order form, corroborated by two `CARD_EXPENSE` GL rows. Right, v1.1: verifier `BLOCK` "pricing schedule effective for the service period not attached", agent attaches `contracts/pricing_schedules/PS-018.pdf` (Production 2027-01-01..2027-12-31 $30,000), accrual $30,000, `CONTROLLER` approval. Advance to 2027-02-12: `INV-V018-001` SS-10031 $30,000. Errors: -$18,000 vs $0. | "Here is a vendor TrueUp has never seen with a pilot-to-production step, not an anniversary percentage, and the learned rule blocks the twelve-thousand-dollar guess until the right schedule is attached." | `beat-10.json` (ContractFeatures for CTR-018 and the evidence-retrieval action); both dollar amounts are deterministic |
| 11 | 12 | 2027-02-12T12:00 | S5 then S6 | Held-out price-change rows, static v1.0 vs policy v1.1 absolute error: V018 $18,000 to $0, V001 Jan $2,500 to $0, V004 $720 to $0, V005 $352 to $0 after safe escalation to vendor billing (C12). Total $21,572 to $0. Regressions 0. Unsupported autonomous postings 0. Then the audit packet for `OBL-V018-2027-01`: evidence ids, policy version 1.1, verifier result, approval by E001. | "Twenty-one thousand dollars of held-out error goes to zero, nothing regressed, and every action carries its evidence, policy version and approver." | none (metrics read from the run log) |

Beat times sum to 180 (12+15+18+12+15+12+12+22+25+25+12).

Demo checkpoints (created by `data/simulate.py checkpoint`, restored by `data/simulate.py restore`):

| Checkpoint | Clock | State | Used when |
|---|---|---|---|
| `CP-DEC` | 2027-01-04T09:00 | November close complete under v1.0 | Demo start |
| `CP-REVEAL` | 2027-01-12T09:00 | December closed, `JE-ACR-V001-2026-12` posted, `INV-V001-008` visible | Beats 1-6 overran; jump to beat 7 |
| `CP-JAN` | 2027-02-05T09:00 | `POL-0001` active as v1.1, January obligations discovered | Beat 9 overran; jump to beat 10 |

### Part B. File tree

```
data/
  README.md                       data dictionary; rewritten after the build delta lands
  generate.py                     entry point: builds world/, then runs leak tests, exits non-zero on a leak
  simulate.py                     CLI over the section 3.6 API: init = reset(), advance --to = advance_to(), checkpoint, restore
  spec/                           these specification files (01..05)
  gen/
    __init__.py
    world.py                      company, employees, 19 vendors, fees, pricing schedules, termination, T0 constant
    features.py                   NEW. true ContractFeatures per contract; imported only by truth.py
    records.py                    invoices, POs, change orders, usage, seats, timesheets, hires, deliveries, service_activity
    ledger.py                     gl_entries (incl. CARD_EXPENSE), ap_queue, accrual_schedule_prior
    docs.py                       contract text, pricing schedules, notices, policy manual, policies.json, PDF rendering
    truth.py                      obligations truth, case rubrics, policy replay expectation, scripted inbox
    events.py                     NEW. splits every dated record at T0 into seed rows or events.jsonl rows
    simulator.py                  NEW. owns the clock; materialises released events and inbox replies into runtime/visible
    leakcheck.py                  NEW. static checks that seed and visible trees contain no private fact
  tests/
    test_leaks.py                 the L1-L10 tests of section 3.7; runs leakcheck against a fresh build and against runtime/visible at each snapshot
    test_demo_path.py             asserts every id, amount and date in Part A exists at the stated clock time
  northstar/
    world/
      seed/                       everything visible at T0 = 2026-12-01T00:00
        company.json              entities, cost centers, chart of accounts, close calendar
        org_directory.json        employees and vendor billing contacts (no V018 contact at T0)
        vendors.json              18 vendors at T0 (V001-V017, V019; V018 absent); spend_type, no pricing_model
        purchase_orders.json      POs issued before T0, incl. Beacon PO-0962 (PO-1063 absent)
        change_orders.json        change orders dated before T0 (CO-1 absent)
        policies.json             policy v1.0 as data
        close_policy_manual.md    policy v1.0 in prose
        gl_entries.csv            history 2026-05..2026-10 plus rows posted before T0, incl. SignalStack card entry JE-CARD-0001 of 2026-11-03
        ap_queue.csv              AP rows with received_date before T0
        erp/
          accrual_schedule_prior.csv   human team's accrual rollforward for 2026-05..2026-10
        contracts/
          CTR-001..CTR-017, CTR-019 (.pdf, .txt)   MSAs and order forms (CTR-018 absent at T0)
          pricing_schedules/
            PS-001.pdf, PS-001.txt     DataForge Exhibit B, doc_type PRICING_SCHEDULE
          notices/
            TN-019.pdf, TN-019.txt     Beacon termination notice sent 2026-11-14
          index.json                   one row per document, section 2 schema (doc_id, doc_type, contract_id, ..., filed_date, files[])
        invoices/
          invoices.json           invoices with received_date before T0
          pdf/                    one PDF per seed invoice
        evidence/
          usage_daily.csv         rows dated before T0
          seat_snapshots.csv      rows dated before T0
          timesheets.csv          rows with approval state as of T0
          hr_hires.csv            rows dated before T0
          goods_receipts.csv      rows dated before T0
          service_activity.csv    monthly platform activity per application, periods 2026-05..2026-10 (no SignalStack row in seed)
      private/                    never mounted into TrueUp
        events.jsonl              every fact after T0, one JSON object per line, sorted by release_at
        documents/                files that events copy into visible: contracts/ (CTR-018, PS-018), invoices/ (later invoice PDFs), inbox/ (PagerLoop notice)
        inbox/
          scripted_responses.json replies keyed by vendor_id + period + target_role + missing_fact, with delay_hours
        truth/                    file set and schemas are defined in section 4
          obligations_truth.csv   answer key, one row per obligation; features, rubric and expected agent results are JSON cells
          future_invoices.csv     every invoice received on or after 2026-12-01
          expected_matches.csv    correct invoice-to-obligation links with allocated dollars
          seeded_root_causes.json why each seeded miss happens
          extra_exceptions.json   PrintWorks duplicate, TalentBridge prior-period fee
          learning_proof/         TU-V001-2026-12, VE-V001-2026-12, POL-0001, RPL-POL-0001, APR-POL-0001 (one JSON each)
    runtime/                      git-ignored; created by simulate.py init
      sim_state.json              clock, released_event_ids, pending_deliveries (section 3.6); written only by the simulator
      outreach_log.jsonl          every send_outreach call; written only by the simulator
      visible/                    copy of world/seed plus materialised events; the only root TrueUp tools receive; read-only to TrueUp
        inbox/messages.jsonl      OUTBOUND and INBOUND rows, both written by the simulator (section 2 schema)
        inbox/attachments/        reply attachments copied from private/documents
      snapshots/                  2026-11-cutoff, 2026-12-cutoff, 2027-01-open, 2027-01-cutoff (copies of visible/, section 3.6)
      checkpoints/CP-DEC|CP-REVEAL|CP-JAN/   demo only: copy of sim_state.json, outreach_log.jsonl, visible/ and the TrueUp SQLite file
      demo_cache/beat-NN.json     recorded model outputs for fallback mode
```

`contracts/index.json` literal rows (section 2 schema; every `CTR-0NN` file has `doc_type = MSA`):

```json
{"doc_id": "PS-001", "doc_type": "PRICING_SCHEDULE", "contract_id": "CTR-001", "counterparty_name": "DataForge Inc.", "vendor_id": "V001", "title": "Exhibit B - Pricing Schedule", "effective_date": "2025-12-01", "filed_date": "2025-11-24", "filed_by": "E030", "files": ["contracts/pricing_schedules/PS-001.pdf", "contracts/pricing_schedules/PS-001.txt"], "supersedes": null}
{"doc_id": "TN-019", "doc_type": "TERMINATION_NOTICE", "contract_id": "CTR-019", "counterparty_name": "Beacon Survey Tools", "vendor_id": "V019", "title": "Notice of termination", "effective_date": "2026-12-15", "filed_date": "2026-11-14", "filed_by": "E013", "files": ["contracts/notices/TN-019.pdf", "contracts/notices/TN-019.txt"], "supersedes": null}
```

### Part C. Build delta (ordered checklist)

Steps 1-9 make the DataForge-to-SignalStack demo work. Steps 10-12 add the other planted cases. Steps 13-15 are background and hardening. Each step leaves `python3 data/generate.py` passing.

| # | Module | Change | Acceptance check |
|---|---|---|---|
| 1 | `generate.py` | Write to `northstar/world/seed/` and `northstar/world/private/`. Move `ground_truth/` to `world/private/truth/`. Move `inbox/scripted_responses.json` and `inbox/attachments/DOC-PAGERLOOP-UPLIFT-NOTICE.txt` to `world/private/inbox/` and `world/private/documents/`. Delete the stray `northstar/invoices 2/` folder on rebuild. Add `northstar/runtime/` to `.gitignore`. | `find world/seed -name '*truth*' -o -name 'scripted_responses.json'` returns nothing. |
| 2 | `world.py` | Add `T0 = datetime(2026, 12, 1, 0, 0)`. In `_v(...)` replace `pricing_model` with `spend_type` using the map below. Blank the `notes` field of V007. Keep the old fine-grained value in a module dict `PRICING_MODEL_TRUE` that only `truth.py` and `records.py` read. | `grep -c pricing_model world/seed/vendors.json` is 0; every vendor has `spend_type` in {SUBSCRIPTION, USAGE, SERVICES, RENT, OTHER}. |
| 3 | `world.py` | Add V018 SignalStack Inc. (6120, CC-190, owner E019, requester E019, CTR-018, PO-1063, billing contact "SignalStack Billing", `billing@signalstack.example`, Net 30, `onboarded_date = 2027-01-08`, `status = ACTIVE`). Add `onboarded_date` and `status` to every vendor. Add `PRICING_SCHEDULES = {"PS-001": [("2025-12-01","2026-11-30",50000.0),("2026-12-01","2027-11-30",52500.0)], "PS-018": [("2026-11-01","2026-12-31",12000.0),("2027-01-01","2027-12-31",30000.0)]}`. Add `FIXED_FEES["V018"] = [("2026-11",12000.0),("2027-01",30000.0)]`. | `len(VENDORS) == 19` after step 10; `PRICING_SCHEDULES["PS-001"][1][2] == FIXED_FEES["V001"][1][1]`. |
| 4 | `docs.py` | CTR-001 text: order form line "$50,000.00 per month (Contract Year 1)"; s4.3 "Fees for each Contract Year are set out in the Pricing Schedule (Exhibit B)"; remove any 5% wording from the MSA body. New `pricing_schedule_text(ps_id)` renders PS-001 and PS-018 as `.txt` and `.pdf`. CTR-018 text: order form "Pilot Fee $12,000.00 per month", same s4.3 sentence. Emit `contracts/index.json`. | `grep -c "52,500" CTR-001.txt` is 0 and `grep -c "52,500" PS-001.txt` is 1; `grep -c "30,000" CTR-018.txt` is 0. |
| 5 | `records.py` | `build_invoices()`: add V018 with `PREFIX["V018"] = "SS"`, one invoice only: `INV-V018-001`, number SS-10031, dated 2027-01-31, received 2027-02-12, $30,000, PO-1063. No V018 invoices for 2026-11 or 2026-12. `build_pos()`: add PO-1063, $360,000, `issued_date` 2027-01-08. Add `issued_date` to every PO. | Invoice count for V018 is 1; `INV-V001-008` unchanged (DF-2256, 2027-01-12, 52500.0). |
| 6 | `ledger.py` | `build_gl()`: add account 2050 Corporate Card Payable, the trailing `obligation_id` column and two balanced `CARD_EXPENSE` entries `JE-CARD-0001` and `JE-CARD-0002`: Dr 6120 / Cr 2050 (never touches 2000 AP), CC-190, `vendor_id` empty, references `CARD-4417-20261103` and `CARD-4417-20261202`, memo `Corp card x4417 (E019) SIGNALSTACK INC pilot fee Nov 2026` / `... Dec 2026`, $12,000 each, posting dates 2026-11-03 and 2026-12-02, `posted_by` `CARD_FEED`. `build_ap_queue()`: no V018 row before 2027-02-12. | GL still balances per `entry_id`; exactly 4 GL lines have `entry_type = CARD_EXPENSE`, all with blank `vendor_id` and memo containing `SIGNALSTACK`; every credit line is on 2050. |
| 7 | `records.py` | New `build_service_activity()` writing `evidence/service_activity.csv` with the section 2 columns (`activity_id, period, application, vendor_id, source_system, active_users, active_days, api_calls, first_activity_date, last_activity_date, service_status`). One row per application per month for V001, V004, V005, V009, V015, V018, V019. SignalStack rows exist from 2026-11; `vendor_id` is blank on the 2026-11 and 2026-12 rows and `V018` from 2027-01. | V001 has 9 rows (2026-05..2027-01); V019 2026-12 is PARTIAL with `last_activity_date` 2026-12-15 and 2027-01 is INACTIVE with zeros; example row `SA-DATAFORGE-2026-12,2026-12,DataForge Platform,V001,okta-sso+dataforge-admin-api,41,31,1284000,2026-12-01,2026-12-31,ACTIVE`. |
| 8 | `events.py` (new), `generate.py` | `split(records, date_field)` sends rows dated before `T0` to seed and the rest to `events.jsonl` in the section 3.4 schema (`event_id, event_type, release_at, record_id, vendor_id, period, target, op, key_field, payload, files, side_effects`). Event types: INVOICE_RECEIVED (invoice + ap_queue row + PDF), USAGE_EXPORT, EVIDENCE_UPDATE (seats, timesheets, hires, receipts, service_activity, GL rows posted after T0 incl. `JE-CARD-0002`), CONTRACT_DOC_ADDED (CTR-018, PS-018 at 2027-01-08), VENDOR_ONBOARDED (V018 vendor record and billing contact at 2027-01-08), PO_ISSUED (PO-1063, CO-1), PERIOD_STATUS_CHANGE (target `company.json`). Event ids are `EVT-` plus a five-digit sequence in `release_at` order. | Seed `invoices.json` max `received_date` < 2026-12-01; seed + events invoice count equals the pre-split count; no seed file contains the string `V018` or `SignalStack` except the 2026-11-03 card memo. |
| 9 | `simulator.py` (new), `simulate.py` | `init` copies seed to `runtime/visible/` and sets clock to T0. `advance --to ISO` appends every event with `release_at <= now` into the matching visible file, idempotently. `send_outreach` (section 3.5) appends the OUTBOUND row to `visible/inbox/messages.jsonl`, matches `world/private/inbox/scripted_responses.json` on (`vendor_id`, `period`, `target_role`, `missing_fact`), and appends the INBOUND row once `now >= sent_at + delay_hours`. No match means no reply. The clock never moves backward except through `restore`. `checkpoint NAME` and `restore NAME` as in Part A. | `test_demo_path.py`: at 2027-01-05T23:59:59 `INV-V001-008` is not visible; at 2027-01-12T09:00 it is; outreach sent 2027-01-04T09:30 yields `MSG-OUT-V001-2026-12-01-R` at 2027-01-05T15:30 and not one minute earlier; at 2027-02-05T23:59:59 `INV-V018-001` is not visible and `PS-018` is. |
| 10 | `world.py`, `docs.py`, `records.py` | Add V019 Beacon Survey Tools (6120, CC-130, owner E013, requester E013, CTR-019, PO-0962 ($45,600, 2026-04-01..2027-03-31, left `OPEN`), `accounts@beaconsurvey.example`, Net 30, invoice prefix `BS`, vendor `status` stays `ACTIVE`). `FIXED_FEES["V019"] = [("2025-04",3800.0)]`, `TERMINATION["V019"] = {"notice_id":"TN-019","sent":"2026-11-14","effective":"2026-12-15"}`. `docs.py` renders TN-019. Invoices: history and 2026-11 at $3,800 on time; final `INV-V019-008` (BS-2256) for 2026-12-01..2026-12-15 at $1,838.71, received 2027-01-07; none for 2027-01. | `round(3800*15/31, 2) == 1838.71` equals the invoice amount; no V019 invoice has a service period after 2026-12-15. |
| 11 | `ledger.py` | New `build_accrual_schedule_prior()` writing `erp/accrual_schedule_prior.csv` with the section 2 columns (`vendor_id, vendor_name, period, gl_account, cost_center, basis, accrued, actual, variance, invoice_number, invoice_received, je_ref, preparer, reviewer, note`). No rows for V001, V018 or V019. Derived from the same history accrual logic as `build_gl()` (including `HIST_ACCRUAL_OVERRIDE`), so the spreadsheet and the GL agree. Two planted conflicts live in the notes: the V002 rows say "accrue at commit, overage immaterial" (false for 2026-12), and the V011 2026-10 row shows `accrued = 0` with note "no fee expected" while `hr_hires.csv` shows an October hire. Preparer is E004 and reviewer E002 for all rows. | For every (vendor, period) in history, `accrued` equals the GL `ACCRUAL` credit to 2100; the V002 and V011 2026-10 notes are the only notes that conflict with evidence. Example: `V007,Meridian Legal LLP,2026-10,6210,CC-150,owner estimate,12000.0,12750.0,750.0,ML-2228,2026-11-20,ACR-V007-2026-10,E004,E002,Owner estimate low; final bill included filing fees`. |
| 12 | `truth.py`, `features.py` (new) | `features.py` holds true ContractFeatures for CTR-001..CTR-019. `truth.py`: obligations for V018 (2027-01 only) and V019 (2026-11, 2026-12, 2027-01). Add the section 4 columns `case_id` (C01-C12 or blank), `policy_enabled_estimate`, `true_contract_features`, `expected_safe_actions`, `frozen_agent_expected`, `policy_agent_expected`. Rename `root_cause` value `SCHEDULED_ESCALATOR` to `SCHEDULED_PRICE_CHANGE` and `CHANGE_ORDER_SEAT_EXPANSION` to `SCOPE_CHANGE`; the process cause `PROCEDURE_GAP_REQUIRED_EVIDENCE` lives in `seeded_root_causes.json`. Rows: `OBL-V018-2027-01` split `HELDOUT`, static 12000.0, policy-enabled 30000.0, true 30000.0; `OBL-V019-2026-12` method `PRORATED_FEE`, true 1838.71, static 1838.71, trailing 3800.0; `OBL-V019-2027-01` `needs_estimate = N`, true 0.0, static 0.0, trailing 3146.24 (v1.0 gets Beacon right; only the run-rate baseline fails). Write `future_invoices.csv`, `expected_matches.csv`, `seeded_root_causes.json` and the five `learning_proof/` files. Append new scripted replies after RSP-062 so ids RSP-001..RSP-062 do not change. | 12 distinct non-blank `case_id` values; obligation count is 54 (50 + 1 + 3); `learning_proof/replay_RPL-POL-0001.json` has one `touched` row (`OBL-V001-2026-12`, `IMPROVED`), `"improved": 1` and `"regressed": 0`. |
| 13 | `leakcheck.py` (new), `tests/test_leaks.py` | Checks: (a) no path under `world/seed` or `runtime/visible` contains `truth`, `private` or `scripted_responses`; (b) no visible JSON or CSV has a key named `pricing_model`, `pricing_structure`, `has_scheduled_price_change`, `split`, `scenario`, `root_cause`, `case_id` or `true_expense`; (c) no seed text file contains `52,500`, `52500` outside `contracts/pricing_schedules/PS-001.*`; (d) no seed file contains `30,000`/`30000` on a line mentioning SignalStack; (e) the rate `5.5` does not appear in any seed file mentioning PagerLoop; (f) `simulator.py` is the only module that opens `world/private`. `generate.py` runs (a)-(e) and exits 1 on failure. | `python3 data/generate.py` prints `leaks=0`; planting `"pricing_model"` in `vendors.json` makes the build fail. |
| 14 | `truth.py`, `records.py` | Background rows unchanged in substance: StreamGrid, Helpline change order, PayCircle mismatch, Thames wrong entity, SecureLayer prepaid, TalentBridge, Lumen. Only re-verify that their invoices, replies and evidence pass through the seed/event split with correct `release_at`. | For each background vendor, `true_expense`, `static_rules_estimate` and `actual_invoice_total` in the new truth file equal the values in the current `obligations_truth.csv`. |
| 15 | `README.md`, `simulate.py` | Rewrite the data dictionary for the three trees. Record `demo_cache/beat-02,04,05,08,09,10.json` from one clean live run. Create `CP-DEC`, `CP-REVEAL`, `CP-JAN`. | `TRUEUP_DEMO_MODE=cached` runs Part A end to end with the network off in under 180 seconds. |

`spend_type` map for step 2:

| spend_type | Vendors |
|---|---|
| SUBSCRIPTION | V001, V003, V004, V005, V009, V010, V015, V018, V019 |
| USAGE | V002, V013 |
| SERVICES | V006, V007, V011, V014 |
| RENT | V008, V017 |
| OTHER | V012, V016 |

Literal `vendors.json` record after step 3 (materialised by `VENDOR_ONBOARDED` on 2027-01-08, not in seed):

```json
{"vendor_id": "V018", "name": "SignalStack Inc.", "category": "SAAS_OR_DATA", "gl_account": "6120", "cost_center": "CC-190", "legal_entity_id": "NS-US", "operational_owner": "E019", "requester": "E019", "billing_contact": "SignalStack Billing", "billing_email": "billing@signalstack.example", "spend_type": "SUBSCRIPTION", "contract_id": "CTR-018", "po_id": "PO-1063", "payment_terms": "Net 30", "onboarded_date": "2027-01-08", "status": "ACTIVE", "notes": "Onboarded from corporate card to AP"}
```

Literal `events.jsonl` rows the demo depends on:

```json
{"event_id": "EVT-00045", "event_type": "VENDOR_ONBOARDED", "release_at": "2027-01-08T09:00:00", "record_id": "V018", "target": "vendors.json", "op": "UPSERT_RECORD", "key_field": "vendor_id"}
{"event_id": "EVT-00046", "event_type": "CONTRACT_DOC_ADDED", "release_at": "2027-01-08T10:00:00", "record_id": "PS-018", "target": "contracts/index.json", "op": "UPSERT_RECORD", "key_field": "doc_id"}
{"event_id": "EVT-00047", "event_type": "CONTRACT_DOC_ADDED", "release_at": "2027-01-08T10:00:00", "record_id": "CTR-018", "target": "contracts/index.json", "op": "UPSERT_RECORD", "key_field": "doc_id"}
{"event_id": "EVT-00048", "event_type": "PO_ISSUED", "release_at": "2027-01-08T11:00:00", "record_id": "PO-1063", "target": "purchase_orders.json", "op": "UPSERT_RECORD", "key_field": "po_id"}
{"event_id": "EVT-00052", "event_type": "INVOICE_RECEIVED", "release_at": "2027-01-12T09:00:00", "record_id": "INV-V001-008", "target": "invoices/invoices.json", "op": "UPSERT_RECORD", "key_field": "invoice_id"}
{"event_id": "EVT-00088", "event_type": "INVOICE_RECEIVED", "release_at": "2027-02-12T09:00:00", "record_id": "INV-V018-001", "target": "invoices/invoices.json", "op": "UPSERT_RECORD", "key_field": "invoice_id"}
```

Rows are abbreviated: `vendor_id`, `period`, `payload`, `files` and `side_effects` are as in section 3.4. The `EVT-` sequence numbers above are illustrative; the generator assigns them in `release_at` order. All other ids, amounts and dates are exact.


